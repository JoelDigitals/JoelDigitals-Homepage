﻿function Invoke-HoneypotSetup {
    param([hashtable]$Config)

    $hp = $Config.honeypot
    if (-not $hp.enabled) { Write-JDSLog "WARN" "Honeypot module is disabled"; return }

    Write-JDSLog "INFO" "Setting up honeypot system..."

    try {
        $honeypotDir = "C:\Honeypot"
        if (-not (Test-Path $honeypotDir)) {
            New-Item -ItemType Directory -Path $honeypotDir -Force | Out-Null
        }

        foreach ($fakeFile in $hp.fake_files) {
            if (-not (Test-Path $fakeFile)) {
                $parent = Split-Path $fakeFile -Parent
                if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }

                $fakeContent = @"
Username,Password,Role,Access Level
admin,S3cur3P@ssw0rd!2024,Administrator,Full
admin_backup,B@ckupAdm1n2024,BackupAdmin,ReadWrite
service_acc,Serv1ce@cc2024,ServiceAccount,Limited
db_admin,DB@dm1nP@ss2024,DatabaseAdmin,Full
"@
                Set-Content -Path $fakeFile -Value $fakeContent -Force
                $acl = Get-Acl $fakeFile
                $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
                    "BUILTIN\Benutzer", "Read", "Allow"
                )
                $acl.SetAccessRule($accessRule)
                Set-Acl -Path $fakeFile -AclObject $acl -ErrorAction SilentlyContinue

                Write-JDSLog "INFO" "Created honeypot file: $fakeFile"
            }
        }

        $watchScript = @"
param([string]`$WatchPath)
`$watcher = New-Object System.IO.FileSystemWatcher
`$watcher.Path = (Split-Path `$WatchPath -Parent)
`$watcher.Filter = (Split-Path `$WatchPath -Leaf)
`$watcher.IncludeSubdirectories = `$true
`$watcher.EnableRaisingEvents = `$true
`$action = {
    `$path = `$Event.SourceEventArgs.FullPath
    `$changeType = `$Event.SourceEventArgs.ChangeType
    `$logEntry = "[HONEYPOT] $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - `$changeType`: `$path | User: $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"
    `$logEntry | Out-File -FilePath "$($PSScriptRoot)\..\logs\honeypot-access.log" -Append
    Write-Host "`$logEntry"
}
`$handlers = .{Register-ObjectEvent `$watcher "Changed" -Action `$action; Register-ObjectEvent `$watcher "Created" -Action `$action; Register-ObjectEvent `$watcher "Deleted" -Action `$action}
Write-Host "Monitoring honeypot files... Press Ctrl+C to exit."
while (`$true) { Start-Sleep -Seconds 5 }
"@

        $watchScriptPath = "$PSScriptRoot\..\tools\honeypot-watcher.ps1"
        # Script is generated inline below

        Write-JDSLog "INFO" "Honeypot setup completed - $($hp.fake_files.Count) fake files created"

        Invoke-HoneypotPortListener -Config $Config

        $alerts = @{
            type = "Info"
            title = "Honeypot aktiv"
            message = "Honeypot-System wurde eingerichtet"
        }
        Send-JDSAlert $Config $alerts

    } catch {
        Write-JDSLog "ERROR" "Honeypot setup failed: $_"
        throw
    }
}

function Invoke-HoneypotPortListener {
    param([hashtable]$Config)

    $hp = $Config.honeypot
    Write-JDSLog "INFO" "Setting up honeypot port listeners..."

    try {
        $scriptPath = "$PSScriptRoot\..\tools\honeypot-listener.ps1"
        $ports = $hp.ports -join ','

        $listenerScript = @"
# JDS-Secure Honeypot Port Listener
# Ports: $ports

`$ports = @($ports)
`$logFile = Join-Path `$PSScriptRoot "..\logs\honeypot-port.log"

foreach (`$port in `$ports) {
    try {
        `$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Any, `$port)
        `$listener.Start()
        `$entry = '[HONEYPOT] ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' - Listening on port ' + `$port
        `$entry | Out-File -FilePath `$logFile -Append

        Start-Job -ScriptBlock {
            param(`$p, `$l, `$lf)
            `$bannerString = '220 JDS-Server FTP ready'
            while (`$true) {
                if (`$l.Pending()) {
                    `$client = `$l.AcceptTcpClient()
                    `$remote = `$client.Client.RemoteEndPoint.ToString()
                    `$entry = '[HONEYPOT] ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' - Connection on port ' + `$p + ' from ' + `$remote
                    `$entry | Out-File -FilePath `$lf -Append
                    try {
                        `$stream = `$client.GetStream()
                        `$bytes = [System.Text.Encoding]::ASCII.GetBytes(`$bannerString)
                        `$stream.Write(`$bytes, 0, `$bytes.Length)
                    } catch {}
                    `$client.Close()
                }
                Start-Sleep -Milliseconds 100
            }
        } -ArgumentList `$port, `$listener, `$logFile | Out-Null
    } catch {
        `$entry = '[HONEYPOT] ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' - Failed to listen on port ' + `$port + ': ' + `$_
        `$entry | Out-File -FilePath `$logFile -Append
    }
}

Write-Host "Honeypot port listeners started on ports: `$ports"
while (`$true) { Start-Sleep -Seconds 60 }
"@
        Set-Content -Path $scriptPath -Value $listenerScript -Force
        Write-JDSLog "INFO" "Honeypot port listener script created for ports: $($hp.ports -join ', ')"

    } catch {
        Write-JDSLog "ERROR" "Failed to setup honeypot port listeners: $_"
    }
}

function Invoke-HoneypotMonitor {
    param([hashtable]$Config)

    $hp = $Config.honeypot
    $logFile = "$PSScriptRoot\..\logs\honeypot-access.log"

    if (-not (Test-Path $logFile)) {
        Write-JDSLog "INFO" "No honeypot access log found"
        return @()
    }

    try {
        $entries = Get-Content $logFile -Tail 100 -ErrorAction SilentlyContinue
        $recentEntries = $entries | Where-Object { $_ -match "\[HONEYPOT\]" }

        $alerts = @()
        foreach ($entry in $recentEntries) {
            if ($entry -match "(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})") {
                $entryTime = Get-Date $Matches[1]
                if ((Get-Date) - $entryTime -lt [TimeSpan]::FromHours(1)) {
                    Write-JDSLog "WARN" "Honeypot alert: $entry"

                    if ($hp.alert_on_access) {
                        $alerts += @{
                            type = "Warning"
                            title = "Honeypot-Zugriff"
                            message = $entry
                        }
                    }
                }
            }
        }

        foreach ($alert in $alerts) {
            Send-JDSAlert $Config $alert
        }

        return $alerts
    } catch {
        Write-JDSLog "ERROR" "Honeypot monitoring failed: $_"
        return @()
    }
}

function Invoke-HoneypotShares {
    param([hashtable]$Config)

    $hp = $Config.honeypot

    Write-JDSLog "INFO" "Creating honeypot network shares..."

    $shareRoot = "C:\HoneypotShares"
    if (-not (Test-Path $shareRoot)) {
        New-Item -ItemType Directory -Path $shareRoot -Force | Out-Null
    }

    foreach ($shareName in $hp.fake_shares) {
        $sharePath = Join-Path $shareRoot $shareName
        if (-not (Test-Path $sharePath)) {
            New-Item -ItemType Directory -Path $sharePath -Force | Out-Null
        }

        $fakeContent = @"
WICHTIGE UNTERNEHMENSDATEN - NICHT LOESCHEN
Kundenliste 2024 - Stand: $(Get-Date -Format 'dd.MM.yyyy')
Umsatzzahlen Q1-Q4
Mitarbeitergehaelter vertraulich
"@
        Set-Content -Path "$sharePath\README.txt" -Value $fakeContent -Force

        try {
            $existingShare = Get-SmbShare -Name $shareName -ErrorAction SilentlyContinue
            if (-not $existingShare) {
                New-SmbShare -Name $shareName -Path $sharePath -Description "JDS Honeypot - Ueberwachte Freigabe" -ReadAccess "Jeder" -ErrorAction SilentlyContinue
                Write-JDSLog "INFO" "Created honeypot share: $shareName"
            }
        } catch {
            Write-JDSLog "WARN" "Could not create SMB share $shareName`: $_"
        }

        $acl = Get-Acl $sharePath
        $everyone = New-Object System.Security.Principal.NTAccount("Jeder")
        $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $everyone, "Read", "ContainerInherit,ObjectInherit", "None", "Allow"
        )
        $acl.SetAccessRule($accessRule)
        Set-Acl -Path $sharePath -AclObject $acl -ErrorAction SilentlyContinue
    }

    Write-JDSLog "INFO" "Created $($hp.fake_shares.Count) honeypot shares"
}


