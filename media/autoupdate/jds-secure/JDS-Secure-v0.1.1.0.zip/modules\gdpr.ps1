﻿function Initialize-GDPR {
    param([hashtable]$Config)
    $cfg = $Config.gdpr
    if (-not $cfg.enabled) { return }

    $gdprPath = Join-Path $Config.general.data_path "gdpr"
    if (-not (Test-Path $gdprPath)) { New-Item -ItemType Directory -Path $gdprPath -Force | Out-Null }

    $breachPath = Join-Path $gdprPath "breaches"
    if (-not (Test-Path $breachPath)) { New-Item -ItemType Directory -Path $breachPath -Force | Out-Null }

    $retentionPath = Join-Path $gdprPath "retention"
    if (-not (Test-Path $retentionPath)) { New-Item -ItemType Directory -Path $retentionPath -Force | Out-Null }

    $docsPath = Join-Path $gdprPath "docs"
    if (-not (Test-Path $docsPath)) { New-Item -ItemType Directory -Path $docsPath -Force | Out-Null }

    $script:GDPRBreachLog = @()
    $breachLogFile = Join-Path $breachPath "breach-log.json"
    if (Test-Path $breachLogFile) {
        try { $script:GDPRBreachLog = Get-Content $breachLogFile -Raw -Encoding UTF8 | ConvertFrom-Json } catch { }
    }
    if (-not $script:GDPRBreachLog -or $script:GDPRBreachLog -isnot [array]) { $script:GDPRBreachLog = @() }

    $policiesPath = Join-Path $retentionPath "retention-policies.json"
    $script:GDPRRetentionPolicies = @()
    if (Test-Path $policiesPath) {
        try { $script:GDPRRetentionPolicies = Get-Content $policiesPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { }
    }
    if (-not $script:GDPRRetentionPolicies -or $script:GDPRRetentionPolicies -isnot [array]) {
        $script:GDPRRetentionPolicies = @(
            @{ name = "System-Logs (Audit)"; path = "$($Config.general.data_path)\logs\*.log"; retention_days = 3650; mandatory = $true; auto_delete = $false }
            @{ name = "Backup-Dateien"; path = "$($Config.general.data_path)\backups\*"; retention_days = 365; mandatory = $false; auto_delete = $true }
            @{ name = "Quarantaene"; path = "$($Config.general.data_path)\quarantine\*"; retention_days = 90; mandatory = $false; auto_delete = $true }
            @{ name = "Security-Reports"; path = "$($Config.general.data_path)\logs\security-report_*.html"; retention_days = 365; mandatory = $true; auto_delete = $false }
            @{ name = "Windows-Temporaere Dateien"; path = "$env:TEMP\*"; retention_days = 7; mandatory = $false; auto_delete = $true }
        )
    }
    $script:GDPRRetentionPath = $retentionPath
    $script:GDPRBreachPath = $breachPath
    $script:GDPRDocsPath = $docsPath
    $script:GDPRBreachLogFile = $breachLogFile
    $script:GDPRPoliciesFile = $policiesPath

    return @{
        breach_log = $script:GDPRBreachLog.Count
        retention_policies = $script:GDPRRetentionPolicies.Count
    }
}

function New-GDPRBreachNotification {
    param(
        [hashtable]$Config,
        [string]$IncidentId,
        [string]$Description,
        [string]$AffectedData,
        [string]$AffectedPersons = "Unbekannt",
        [string]$Measures = "",
        [string]$NotificationEmail = ""
    )
    $cfg = $Config.gdpr
    if (-not $cfg.enabled) { return @{ success = $false; reason = "DSGVO deaktiviert" } }

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $breachId = "DSGVO-$(Get-Date -Format 'yyyyMMdd')-$([System.Guid]::NewGuid().ToString('N').Substring(0,6))"
    $deadline = (Get-Date).AddHours(72).ToString("yyyy-MM-dd HH:mm:ss")

    $record = @{
        breach_id = $breachId
        incident_id = $IncidentId
        timestamp = $timestamp
        deadline = $deadline
        status = "open"
        description = $Description
        affected_data = $AffectedData
        affected_persons = $AffectedPersons
        measures = $Measures
        notified_email = $NotificationEmail
        notified_at = $null
        closed_at = $null
    }

    $script:GDPRBreachLog += $record
    Save-GDPRBreachLog

    $reportPath = Join-Path $script:GDPRBreachPath "meldung_${breachId}.html"
    $html = Generate-GDPRBreachHTML -Config $Config -Record $record
    Set-Content -Path $reportPath -Value $html -Encoding UTF8 -Force

    Write-JDSLog "CRITICAL" "DSGVO: Datenschutzverletzung dokumentiert - $breachId (Frist: 72h bis $deadline)"
    Write-JDSLog "INFO" "DSGVO: Melde-Export: $reportPath"

    if ($NotificationEmail -and $Config.audit.smtp_server) {
        $null = Send-GDPRBreachEmail -Config $Config -Record $record
    }

    return @{
        success = $true
        breach_id = $breachId
        deadline = $deadline
        report_path = $reportPath
    }
}

function ConvertTo-JDSHTMLEscape {
    param([string]$InputText)
    if (-not $InputText) { return "" }
    return $InputText.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace('"', "&quot;").Replace("'", "&#39;")
}

function Generate-GDPRBreachHTML {
    param([hashtable]$Config, [hashtable]$Record)
    $company = $Config.general.company_name
    if (-not $company) { $company = "Nicht angegeben" }
    $now = Get-Date -Format "dd.MM.yyyy HH:mm:ss"
    $desc = ConvertTo-JDSHTMLEscape $Record.description
    $data = ConvertTo-JDSHTMLEscape $Record.affected_data
    $persons = ConvertTo-JDSHTMLEscape $Record.affected_persons
    $measures = ConvertTo-JDSHTMLEscape $Record.measures
    $id = ConvertTo-JDSHTMLEscape $Record.breach_id
    $inc = ConvertTo-JDSHTMLEscape $Record.incident_id
    $status = $Record.status
    $ts = $Record.timestamp
    $dl = $Record.deadline
    $style = @"
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'Segoe UI',Arial,sans-serif; background:#0a0e17; color:#e0e0e0; padding:40px; }
    .container { max-width:1000px; margin:0 auto; }
    .header { text-align:center; padding:30px; background:linear-gradient(135deg,#0d1b2a,#1b2838); border-radius:15px; margin-bottom:30px; border:1px solid #1e3a5f; }
    .header h1 { color:#00d4ff; font-size:24px; }
    .card { background:#111927; border-radius:12px; padding:25px; margin-bottom:20px; border:1px solid #1e3a5f; }
    .card h2 { color:#00d4ff; margin-bottom:15px; font-size:18px; border-bottom:1px solid #1e3a5f; padding-bottom:10px; }
    .card p { line-height:1.8; color:#ccd; }
    .label { color:#8899aa; font-size:11px; text-transform:uppercase; letter-spacing:1px; }
    .value { color:#00d4ff; font-size:16px; font-weight:600; }
    .critical { color:#ff1744; font-weight:700; }
    .footer { text-align:center; color:#556677; margin-top:30px; font-size:12px; }
    .legal { background:#1a0a0a; border:1px solid #5f1e1e; border-radius:12px; padding:20px; margin-bottom:20px; }
    .legal h2 { color:#ff6b6b; }
    .legal p { color:#cc9999; font-size:11px; line-height:1.6; }
"@
    return @"
<!DOCTYPE html>
<html lang="de">
<head><meta charset="UTF-8"><title>DSGVO-Meldung $id - $company</title><style>$style</style></head>
<body>
<div class="container">
    <div class="header"><h1>Meldung einer Datenschutzverletzung</h1><p>$company | $now</p></div>
    <div class="card">
        <h2>Meldeinformationen</h2>
        <p><span class="label">Meldungs-ID:</span> <span class="value">$id</span></p>
        <p><span class="label">Incident-ID:</span> <span class="value">$inc</span></p>
        <p><span class="label">Status:</span> <span class="value $status">$status</span></p>
        <p><span class="label">Gemeldet am:</span> <span class="value">$ts</span></p>
        <p><span class="label">Meldefrist (72h):</span> <span class="value critical">$dl</span></p>
    </div>
    <div class="card">
        <h2>Beschreibung des Vorfalls</h2>
        <p>$desc</p>
    </div>
    <div class="card">
        <h2>Betroffene Daten</h2>
        <p>$data</p>
    </div>
    <div class="card">
        <h2>Betroffene Personen</h2>
        <p>$persons</p>
    </div>
    <div class="card">
        <h2>Ergriffene Massnahmen</h2>
        <p>$measures</p>
    </div>
    <div class="legal">
        <h2>Rechtlicher Hinweis / Haftungsausschluss</h2>
        <p>Dieser Bericht wurde automatisch durch JDS Secure generiert und dient der Unterstutzung bei der Einhaltung von DSGVO-Meldepflichten. Er ersetzt keine rechtliche Prufung durch einen Datenschutzbeauftragten oder Rechtsanwalt. Der Entwickler ubernimmt keine Haftung fur die Vollstandigkeit oder Richtigkeit der Angaben. Der Betreiber ist fur die fristgerechte Meldung (72h) gemass Art. 33 DSGVO eigenverantwortlich.</p>
        <p>This report was auto-generated by JDS Secure to assist with GDPR breach notification obligations. It does not replace legal review by a data protection officer or attorney. The author assumes no liability for completeness or accuracy. The operator is solely responsible for timely notification (72h) per Art. 33 GDPR.</p>
    </div>
    <div class="footer"><p>Generiert von JDS-Secure v$script:JDSVersion | $now</p></div>
</div></body></html>
"@
}

function Complete-GDPRBreach {
    param(
        [hashtable]$Config,
        [string]$BreachId,
        [string]$FinalMeasures = "",
        [string]$ClosureNotes = ""
    )
    $record = $script:GDPRBreachLog | Where-Object { $_.breach_id -eq $BreachId -and $_.status -eq "open" }
    if (-not $record) { return @{ success = $false; reason = "Eintrag nicht gefunden oder bereits geschlossen" } }

    $record.status = "closed"
    $record.closed_at = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $record.final_measures = $FinalMeasures
    $record.closure_notes = $ClosureNotes
    Save-GDPRBreachLog
    Write-JDSLog "INFO" "DSGVO: Datenschutzverletzung $BreachId abgeschlossen"
    return @{ success = $true }
}

function Get-GDPRBreachList {
    param([hashtable]$Config)
    if (-not $script:GDPRBreachLog) { return @() }
    return $script:GDPRBreachLog | Sort-Object -Property timestamp -Descending
}

function Get-GDPRBreachSummary {
    param([hashtable]$Config)
    if (-not $script:GDPRBreachLog) { return @{ total = 0; open = 0; closed = 0; critical = 0 } }
    $total = $script:GDPRBreachLog.Count
    $open = ($script:GDPRBreachLog | Where-Object { $_.status -eq "open" }).Count
    $closed = ($script:GDPRBreachLog | Where-Object { $_.status -eq "closed" }).Count
    $overdue = 0
    foreach ($r in $script:GDPRBreachLog) {
        if ($r.status -eq "open") {
            $deadline = [DateTime]::ParseExact($r.deadline, "yyyy-MM-dd HH:mm:ss", $null)
            if ((Get-Date) -gt $deadline) { $overdue++ }
        }
    }
    return @{ total = $total; open = $open; closed = $closed; overdue = $overdue }
}

function Test-GDPRRetentionPolicies {
    param([hashtable]$Config)
    $cfg = $Config.gdpr
    if (-not $cfg.enabled) { return @{ status = "disabled" } }

    $results = @()
    $totalSizeMB = 0
    $deletableSizeMB = 0

    foreach ($policy in $script:GDPRRetentionPolicies) {
        $path = [System.Environment]::ExpandEnvironmentVariables($policy.path)
        $cutoff = (Get-Date).AddDays(-$policy.retention_days)

        try {
            $matchingFiles = Get-ChildItem -Path $path -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer -and $_.LastWriteTime -lt $cutoff }
            $count = @($matchingFiles).Count
            $size = ($matchingFiles | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
            if (-not $size) { $size = 0 }
            $totalSizeMB += [Math]::Round($size / 1MB, 2)

            $deletable = $policy.auto_delete -and $count -gt 0
            if ($deletable) { $deletableSizeMB += [Math]::Round($size / 1MB, 2) }

            if ($count -gt 0) {
                $results += @{
                    policy = $policy.name
                    path = $policy.path
                    retention_days = $policy.retention_days
                    files_expired = $count
                    size_mb = [Math]::Round($size / 1MB, 2)
                    auto_delete = $policy.auto_delete
                    deletable = $deletable
                }
            }
        } catch { }
    }

    return @{
        status = "ok"
        policies_checked = $script:GDPRRetentionPolicies.Count
        expired_found = ($results | Where-Object { $_.files_expired -gt 0 }).Count
        expired_total_files = ($results | Measure-Object -Property files_expired -Sum).Sum
        total_expired_size_mb = $totalSizeMB
        deletable_size_mb = $deletableSizeMB
        details = $results
    }
}

function Invoke-GDPRDataCleanup {
    param([hashtable]$Config, [bool]$AutoMode = $false)
    $cfg = $Config.gdpr
    if (-not $cfg.enabled) { return @{ status = "disabled" } }
    if (-not $cfg.data_retention.enabled) { return @{ status = "disabled"; reason = "Datenaufbewahrung deaktiviert" } }

    $testResult = Test-GDPRRetentionPolicies -Config $Config
    $deleted = 0
    $deletedSizeMB = 0
    $skipped = 0

    foreach ($policy in $script:GDPRRetentionPolicies) {
        if (-not $policy.auto_delete -and -not $AutoMode) { $skipped++; continue }
        $path = [System.Environment]::ExpandEnvironmentVariables($policy.path)
        $cutoff = (Get-Date).AddDays(-$policy.retention_days)

        try {
            $toDelete = Get-ChildItem -Path $path -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer -and $_.LastWriteTime -lt $cutoff }
            foreach ($f in $toDelete) {
                try {
                    $size = $f.Length
                    Remove-Item -Path $f.FullName -Force -ErrorAction SilentlyContinue
                    $deleted++
                    $deletedSizeMB += [Math]::Round($size / 1MB, 2)
                } catch { }
            }
        } catch { }
    }

    Write-JDSLog "INFO" "DSGVO: Datenbereinigung abgeschlossen - $deleted Dateien geloescht (${deletedSizeMB}MB), $skipped uebersprungen"
    return @{
        deleted = $deleted
        deleted_size_mb = $deletedSizeMB
        skipped_policies = $skipped
    }
}

function Export-GDPRDocumentation {
    param([hashtable]$Config, [string]$Type = "all")
    $cfg = $Config.gdpr
    if (-not $cfg.enabled) { return @{ success = $false; reason = "DSGVO deaktiviert" } }

    $companyName = $env:COMPUTERNAME
    $now = Get-Date -Format "dd.MM.yyyy HH:mm:ss"
    $dateStr = Get-Date -Format "yyyyMMdd"

    $results = @()

    if ($Type -eq "all" -or $Type -eq "processing") {
        $processing = Generate-GDPRProcessingRecord -Config $Config -CompanyName $companyName
        $procPath = Join-Path $script:GDPRDocsPath "verarbeitungsverzeichnis_${dateStr}.html"
        Set-Content -Path $procPath -Value $processing -Encoding UTF8 -Force
        $results += @{ type = "Verarbeitungsverzeichnis"; path = $procPath }
    }

    if ($Type -eq "all" -or $Type -eq "tom") {
        $tom = Generate-GDPRTOM -Config $Config -CompanyName $companyName
        $tomPath = Join-Path $script:GDPRDocsPath "tom_${dateStr}.html"
        Set-Content -Path $tomPath -Value $tom -Encoding UTF8 -Force
        $results += @{ type = "TOM (Technisch-Organisatorische Massnahmen)"; path = $tomPath }
    }

    if ($Type -eq "all" -or $Type -eq "overview") {
        $overview = Generate-GDPROverview -Config $Config -CompanyName $companyName
        $ovPath = Join-Path $script:GDPRDocsPath "dsgvo-uebersicht_${dateStr}.html"
        Set-Content -Path $ovPath -Value $overview -Encoding UTF8 -Force
        $results += @{ type = "DSGVO-Uebersicht & Compliance"; path = $ovPath }
    }

    Write-JDSLog "INFO" "DSGVO: Dokumentation exportiert ($($results.Count) Dateien)"
    return @{ success = $true; files = $results }
}

function Generate-GDPRProcessingRecord {
    param([hashtable]$Config, [string]$CompanyName)
    $modules = @(
        @{ name = "Firewall"; purpose = "Netzwerksicherheit - Schutz vor unbefugtem Zugriff"; data = "IP-Adressen, Ports, Verbindungsdaten"; legal = "Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse)" }
        @{ name = "IDS"; purpose = "Einbruchserkennung & Ueberwachung"; data = "System-Ereignisse, Prozessinformationen"; legal = "Art. 6 Abs. 1 lit. f DSGVO" }
        @{ name = "Verschluesselung"; purpose = "Datensicherheit durch Kryptographie"; data = "Schutz aller verarbeiteten Daten"; legal = "Art. 32 DSGVO" }
        @{ name = "Backup"; purpose = "Datensicherung & Wiederherstellung"; data = "Alle geschaeftskritischen Daten"; legal = "Art. 32 DSGVO, GoBD" }
        @{ name = "Virenscan"; purpose = "Schutz vor Schadsoftware"; data = "Datei-Hashes, Datei-Metadaten"; legal = "Art. 32 DSGVO" }
        @{ name = "Audit-Log"; purpose = "Nachvollziehbarkeit & Forensik"; data = "Sicherheitsrelevante Ereignisse"; legal = "Art. 30 DSGVO, GoBD" }
    )

    $rows = ""
    foreach ($m in $modules) {
        $rows += "<tr><td>$($m.name)</td><td>$($m.purpose)</td><td>$($m.data)</td><td>$($m.legal)</td></tr>`n"
    }

    return @"
<!DOCTYPE html>
<html lang="de">
<head><meta charset="UTF-8"><title>Verarbeitungsverzeichnis - $CompanyName</title>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'Segoe UI',Arial,sans-serif; background:#0a0e17; color:#e0e0e0; padding:40px; }
    .container { max-width:1000px; margin:0 auto; }
    .header { text-align:center; padding:30px; background:linear-gradient(135deg,#0d1b2a,#1b2838); border-radius:15px; margin-bottom:30px; border:1px solid #1e3a5f; }
    .header h1 { color:#00d4ff; font-size:24px; }
    .card { background:#111927; border-radius:12px; padding:25px; margin-bottom:20px; border:1px solid #1e3a5f; }
    .card h2 { color:#00d4ff; margin-bottom:15px; font-size:18px; border-bottom:1px solid #1e3a5f; padding-bottom:10px; }
    table { width:100%; border-collapse:collapse; margin-top:10px; }
    th,td { padding:10px 12px; text-align:left; border-bottom:1px solid #1a2332; font-size:13px; }
    th { color:#00d4ff; font-weight:600; }
    .footer { text-align:center; color:#556677; margin-top:30px; font-size:12px; }
</style></head>
<body>
<div class="container">
    <div class="header"><h1>Verarbeitungsverzeichnis nach Art. 30 DSGVO</h1><p>$CompanyName | $now</p></div>
    <div class="card"><h2>Verantwortlicher</h2><p><strong>Name:</strong> $CompanyName</p><p><strong>System:</strong> JDS-Secure v$script:JDSVersion</p></div>
    <div class="card"><h2>Verarbeitungstaetigkeiten</h2><table><tr><th>Anwendung</th><th>Zweck</th><th>Datenkategorien</th><th>Rechtsgrundlage</th></tr>$rows</table></div>
    <div class="legal"><h2>Haftungsausschluss / Disclaimer</h2><p>Automatisch generiert. Ersetzt keine rechtliche Prufung. Keine Haftung. / Auto-generated. Does not replace legal review. No liability.</p></div>
    <div class="footer"><p>Generiert von JDS-Secure v$script:JDSVersion | $now</p></div>
</div></body></html>
"@
}

function Generate-GDPRTOM {
    param([hashtable]$Config, [string]$CompanyName)
    $now = Get-Date -Format "dd.MM.yyyy HH:mm:ss"
    return @"
<!DOCTYPE html>
<html lang="de">
<head><meta charset="UTF-8"><title>TOM - $CompanyName</title>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'Segoe UI',Arial,sans-serif; background:#0a0e17; color:#e0e0e0; padding:40px; }
    .container { max-width:1000px; margin:0 auto; }
    .header { text-align:center; padding:30px; background:linear-gradient(135deg,#0d1b2a,#1b2838); border-radius:15px; margin-bottom:30px; border:1px solid #1e3a5f; }
    .header h1 { color:#00d4ff; font-size:24px; }
    .card { background:#111927; border-radius:12px; padding:25px; margin-bottom:20px; border:1px solid #1e3a5f; }
    .card h2 { color:#00d4ff; margin-bottom:15px; font-size:18px; border-bottom:1px solid #1e3a5f; padding-bottom:10px; }
    .card p { line-height:1.8; color:#ccd; }
    .footer { text-align:center; color:#556677; margin-top:30px; font-size:12px; }
</style></head>
<body>
<div class="container">
    <div class="header"><h1>Technisch-Organisatorische Massnahmen (TOM)</h1><p>$CompanyName | $now</p></div>
    <div class="card"><h2>1. Zutrittskontrolle (Art. 32 Abs. 1 lit. a DSGVO)</h2><p>Server-Zugang durch Passwortschutz, Firewall-Regeln, IDS-Ueberwachung.</p></div>
    <div class="card"><h2>2. Zugangskontrolle (Art. 32 Abs. 1 lit. b DSGVO)</h2><p>Benutzerauthentifizierung, Rechteverwaltung, Audit-Logging aller Zugriffe.</p></div>
    <div class="card"><h2>3. Zugriffskontrolle (Art. 32 Abs. 1 lit. c DSGVO)</h2><p>Berechtigungskonzept, Prozess-Security, Datei-Integritaet, USB-Sperre.</p></div>
    <div class="card"><h2>4. Weitergabekontrolle (Art. 32 Abs. 1 lit. d DSGVO)</h2><p>Verschluesselung (AES-256, BitLocker, EFS), Netzwerk-Sicherheit, Honeypot.</p></div>
    <div class="card"><h2>5. Eingabekontrolle (Art. 32 Abs. 1 lit. e DSGVO)</h2><p>Audit-Log, Incident-Response, DSGVO-Meldewesen, Quarantaene-Log.</p></div>
    <div class="card"><h2>6. Verfuegbarkeitskontrolle (Art. 32 Abs. 1 lit. f DSGVO)</h2><p>Backup-System (multi-destination, Versioning), Ransomware-Schutz, Selbstschutz.</p></div>
    <div class="card"><h2>7. Trennungsgebot (Art. 32 Abs. 1 lit. g DSGVO)</h2><p>Getrennte Datenverarbeitung pro Mandant/Zweck, Zugriffsbeschraenkungen.</p></div>
    <div class="card"><h2>8. Datenminimierung (Art. 5 Abs. 1 lit. c DSGVO)</h2><p>Losechkonzept mit automatischer Datenbereinigung, Aufbewahrungsfristen.</p></div>
    <div class="card"><h2>9. Verfahren zur regelmaessigen Ueberpruefung</h2><p>Vulnerability-Scan, Prozess-Audit, Integritaets-Check, Selbstschutz-Prüfung.</p></div>
    <div class="card"><h2>10. Datenschutz-Folgenabschaetzung</h2><p>Automatische Dokumentation aller Massnahmen, DSGVO-Berichte, Meldeketten.</p></div>
    <div class="legal"><h2>Haftungsausschluss / Disclaimer</h2><p>Automatisch generiert. Ersetzt keine rechtliche Prufung. Keine Haftung. / Auto-generated. Does not replace legal review. No liability.</p></div>
    <div class="footer"><p>Generiert von JDS-Secure v$script:JDSVersion | $now</p></div>
</div></body></html>
"@
}

function Generate-GDPROverview {
    param([hashtable]$Config, [string]$CompanyName)
    $now = Get-Date -Format "dd.MM.yyyy HH:mm:ss"
    $breachSummary = Get-GDPRBreachSummary -Config $Config
    $retentionResult = Test-GDPRRetentionPolicies -Config $Config
    return @"
<!DOCTYPE html>
<html lang="de">
<head><meta charset="UTF-8"><title>DSGVO-Uebersicht - $CompanyName</title>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'Segoe UI',Arial,sans-serif; background:#0a0e17; color:#e0e0e0; padding:40px; }
    .container { max-width:1000px; margin:0 auto; }
    .header { text-align:center; padding:30px; background:linear-gradient(135deg,#0d1b2a,#1b2838); border-radius:15px; margin-bottom:30px; border:1px solid #1e3a5f; }
    .header h1 { color:#00d4ff; font-size:24px; }
    .card { background:#111927; border-radius:12px; padding:25px; margin-bottom:20px; border:1px solid #1e3a5f; }
    .card h2 { color:#00d4ff; margin-bottom:15px; font-size:18px; border-bottom:1px solid #1e3a5f; padding-bottom:10px; }
    .metric-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:15px; margin-top:15px; }
    .metric { background:#0d1b2a; padding:20px; border-radius:10px; text-align:center; }
    .metric .value { font-size:32px; font-weight:700; color:#00d4ff; }
    .metric .label { font-size:12px; color:#8899aa; margin-top:5px; }
    .badge { display:inline-block; padding:4px 12px; border-radius:20px; font-size:12px; font-weight:600; }
    .badge-ok { background:#00e67622; color:#00e676; border:1px solid #00e67644; }
    .badge-err { background:#ff174422; color:#ff1744; border:1px solid #ff174444; }
    .footer { text-align:center; color:#556677; margin-top:30px; font-size:12px; }
    .legal { background:#1a0a0a; border:1px solid #5f1e1e; border-radius:12px; padding:20px; margin-bottom:20px; }
    .legal h2 { color:#ff6b6b; font-size:14px; }
    .legal p { color:#cc9999; font-size:11px; line-height:1.6; }
</style></head>
<body>
<div class="container">
    <div class="header"><h1>DSGVO-Compliance Uebersicht</h1><p>$CompanyName | $now</p></div>
    <div class="card"><h2>Datenschutzverletzungen</h2>
        <div class='metric-grid'>
            <div class='metric'><div class='value'>$($breachSummary.total)</div><div class='label'>Gesamt</div></div>
            <div class='metric'><div class='value' style='color:$(if ($breachSummary.open -gt 0){"#ffab00"}else{"#00e676"})'>$($breachSummary.open)</div><div class='label'>Offen</div></div>
            <div class='metric'><div class='value'>$($breachSummary.closed)</div><div class='label'>Abgeschlossen</div></div>
            <div class='metric'><div class='value' style='color:$(if ($breachSummary.overdue -gt 0){"#ff1744"}else{"#00e676"})'>$($breachSummary.overdue)</div><div class='label'>Ueberfaellig (72h)</div></div>
        </div>
    </div>
    <div class="card"><h2>Datenaufbewahrung &amp; Loeschkonzept</h2>
        <div class='metric-grid'>
            <div class='metric'><div class='value'>$($retentionResult.policies_checked)</div><div class='label'>Richtlinien</div></div>
            <div class='metric'><div class='value' style='color:$(if ($retentionResult.expired_found -gt 0){"#ffab00"}else{"#00e676"})'>$($retentionResult.expired_total_files)</div><div class='label'>Abgelaufene Dateien</div></div>
            <div class='metric'><div class='value'>$($retentionResult.total_expired_size_mb) MB</div><div class='label'>Geloeschtes Potenzial</div></div>
        </div>
    </div>
    <div class="card"><h2>Umgesetzte Massnahmen</h2>
        <ul style='color:#ccd; line-height:2;'>
            <li><span class='badge badge-ok'>AKTIV</span> Firewall &amp; IDS (Netzwerksicherheit)</li>
            <li><span class='badge badge-ok'>AKTIV</span> Verschlusselung (AES-256, BitLocker, EFS, RSA)</li>
            <li><span class='badge badge-ok'>AKTIV</span> Backup mit Versioning (GoBD-konform)</li>
            <li><span class='badge badge-ok'>AKTIV</span> Virenschutz &amp; Quarantane</li>
            <li><span class='badge badge-ok'>AKTIV</span> Ransomware-Schutz &amp; File-Integritat</li>
            <li><span class='badge badge-ok'>AKTIV</span> DSGVO-Meldewesen (72h-Notfall)</li>
            <li><span class='badge badge-ok'>AKTIV</span> Loeschkonzept &amp; Datenbereinigung</li>
            <li><span class='badge badge-ok'>AKTIV</span> Audit-Log &amp; Incident-Response</li>
            <li><span class='badge badge-ok'>AKTIV</span> Selbetschutz &amp; Integritatspruefung</li>
        </ul>
    </div>
    <div class="legal"><h2>Haftungsausschluss / Disclaimer</h2><p>Automatisch generiert. Ersetzt keine rechtliche Prufung. Keine Haftung. / Auto-generated. Does not replace legal review. No liability.</p></div>
    <div class="footer"><p>Generiert von JDS-Secure v$script:JDSVersion | $now</p></div>
</div></body></html>
"@
}

function Save-GDPRBreachLog {
    $script:GDPRBreachLog | ConvertTo-Json -Depth 5 | Set-Content -Path $script:GDPRBreachLogFile -Encoding UTF8 -Force
}

function Save-GDPRRetentionPolicies {
    $script:GDPRRetentionPolicies | ConvertTo-Json -Depth 5 | Set-Content -Path $script:GDPRPoliciesFile -Encoding UTF8 -Force
}

function Send-GDPRBreachEmail {
    param([hashtable]$Config, [hashtable]$Record)
    $smtp = $Config.audit.smtp_server
    if (-not $smtp) { return @{ success = $false; reason = "Kein SMTP-Server konfiguriert" } }
    try {
        $mailParams = @{
            SmtpServer = $smtp
            Port = if ($Config.audit.smtp_port) { $Config.audit.smtp_port } else { 25 }
            From = if ($Config.audit.smtp_from) { $Config.audit.smtp_from } else { "jds-secure@$($env:COMPUTERNAME)" }
            To = $Config.gdpr.breach.notification_email
            Subject = "[DSGVO] Datenschutzverletzung - $($Record.breach_id)"
            Body = "DSGVO-Datenschutzverletzung $($Record.breach_id)`n`nBeschreibung: $($Record.description)`nBetroffene Daten: $($Record.affected_data)`nBetroffene Personen: $($Record.affected_persons)`nMassnahmen: $($Record.measures)`nFrist: $($Record.deadline)`n`nBitte innerhalb von 72h an die Aufsichtsbehoerde melden."
        }
        Send-MailMessage @mailParams -ErrorAction SilentlyContinue
        $Record.notified_at = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        Save-GDPRBreachLog
        return @{ success = $true }
    } catch { return @{ success = $false; reason = "$_" } }
}
