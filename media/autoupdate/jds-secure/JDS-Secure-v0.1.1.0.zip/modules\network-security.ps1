﻿function Initialize-NetworkSecurity {
    param([hashtable]$Config)
    $cfg = $Config.network_security
    if (-not $cfg.enabled) { return }

    if (-not $cfg.dns_blocklist) { $cfg.dns_blocklist = @() }

    return $cfg
}

function Invoke-NetworkSecurityScan {
    param([hashtable]$Config, [bool]$ShowProgress = $false)
    $cfg = Initialize-NetworkSecurity -Config $Config
    if (-not $cfg.enabled) { return @{ status = "disabled" } }

    $results = @{ open_ports = @(); listening_services = @(); suspicious_connections = @(); dns_issues = @(); arp_anomalies = @(); network_shares = @(); firewall_health = @() }
    $scanStart = Get-Date

    if ($ShowProgress) { Write-Host "  [NETWORK-SEC] Analysiere Netzwerksicherheit..." -ForegroundColor Cyan }

    if ($cfg.scan_open_ports) {
        try {
            $connections = Get-NetTCPConnection -ErrorAction SilentlyContinue
            $listenPorts = $connections | Where-Object { $_.State -eq "Listen" }
            foreach ($conn in $listenPorts) {
                $procName = "Unknown"
                try {
                    $proc = Get-Process -Id $conn.OwningProcess -ErrorAction SilentlyContinue
                    if ($proc) { $procName = $proc.ProcessName }
                } catch { }
                $results.open_ports += @{ port = $conn.LocalPort; address = $conn.LocalAddress; process = $procName; pid = $conn.OwningProcess; state = $conn.State }
                if ($cfg.suspicious_ports -and $conn.LocalPort -in $cfg.suspicious_ports) {
                    $results.suspicious_connections += @{ port = $conn.LocalPort; process = $procName; reason = "suspicious_port" }
                }
            }
        } catch { }
    }

    if ($cfg.scan_established_connections) {
        try {
            $estConnections = Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue
            foreach ($conn in $estConnections) {
                $remoteIp = $conn.RemoteAddress
                if ($remoteIp -and $remoteIp -ne "0.0.0.0" -and $remoteIp -ne "::" -and $remoteIp -notmatch '^(127\.|192\.168\.|10\.|172\.(1[6-9]|2[0-9]|3[01])\.|169\.254\.)') {
                    $procName = "Unknown"
                    try { $proc = Get-Process -Id $conn.OwningProcess -ErrorAction SilentlyContinue; if ($proc) { $procName = $proc.ProcessName } } catch { }
                    $results.suspicious_connections += @{ remote = $remoteIp; port = $conn.RemotePort; process = $procName; reason = "external_connection" }
                }
                if ($cfg.known_threat_ips -and $remoteIp -in $cfg.known_threat_ips) {
                    $results.suspicious_connections += @{ remote = $remoteIp; port = $conn.RemotePort; reason = "known_threat_ip" }
                }
                if ($cfg.alert_on_high_port_count) {
                    $highPorts = ($estConnections | Where-Object { $_.RemotePort -gt 49151 -and $_.OwningProcess -eq $conn.OwningProcess }).Count
                    if ($highPorts -gt 20) {
                        $procName = "Unknown"
                        try { $proc = Get-Process -Id $conn.OwningProcess -ErrorAction SilentlyContinue; if ($proc) { $procName = $proc.ProcessName } } catch { }
                        $results.suspicious_connections += @{ process = $procName; count = $highPorts; reason = "high_ephemeral_port_count" }
                    }
                }
            }
        } catch { }
    }

    if ($cfg.scan_arp) {
        try {
            $arp = Get-NetNeighbor -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.LinkLayerAddress -and $_.IPAddress -notmatch '^(224\.|239\.|255\.)' }
            $arpByMac = $arp | Group-Object LinkLayerAddress
            foreach ($group in $arpByMac) {
                if ($group.Count -gt 2) {
                    $results.arp_anomalies += @{ mac = $group.Name; ips = $group.Group.IPAddress -join ", "; count = $group.Count; type = "multiple_ips" }
                }
            }
        } catch { }
    }

    if ($cfg.scan_dns) {
        try {
            $dnsCache = Get-DnsClientCache -ErrorAction SilentlyContinue | Where-Object { $_.Entry -and $_.Data }
            foreach ($entry in $dnsCache) {
                if ($cfg.dns_blocklist -and ($cfg.dns_blocklist | Where-Object { $entry.Entry -like $_ -or $entry.Data -like $_ })) {
                    $results.dns_issues += @{ domain = $entry.Entry; ip = $entry.Data -join ", "; type = "blocklisted" }
                }
                if ($entry.Data -match '^(0\.0\.0\.0|127\.0\.0\.1)$' -and $entry.Entry -notmatch '^localhost$') {
                    $results.dns_issues += @{ domain = $entry.Entry; ip = $entry.Data; type = "local_redirect" }
                }
            }
        } catch { }
    }

    if ($cfg.scan_shares) {
        try {
            $shares = Get-SmbShare -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch '^(ADMIN\$|C\$|IPC\$|print\$)$' }
            foreach ($share in $shares) {
                $results.network_shares += @{ name = $share.Name; path = $share.Path; description = $share.Description; current_users = $share.CurrentUsers }
                if ($share.Description -match '(backup|data|admin|all|public|everyone)') {
                    $results.network_shares += @{ name = $share.Name; reason = "suspicious_share_name"; severity = "warn" }
                }
            }
        } catch { }
    }

    if ($cfg.scan_firewall_rules) {
        try {
            $allRules = Get-NetFirewallRule -ErrorAction SilentlyContinue | Where-Object { $_.Enabled -eq $true -and $_.Direction -eq "Inbound" -and $_.Action -eq "Allow" }
            foreach ($rule in $allRules) {
                $portFilter = $rule | Get-NetFirewallPortFilter -ErrorAction SilentlyContinue
                if ($portFilter -and $portFilter.LocalPort) {
                    $results.firewall_health += @{ rule = $rule.DisplayName; port = $portFilter.LocalPort; protocol = $portFilter.Protocol; action = "allow_inbound" }
                }
            }
        } catch { }
    }

    $openPortCount = ($results.open_ports | Where-Object { $_.state -eq "Listen" }).Count
    $suspConnCount = $results.suspicious_connections.Count
    $shareCount = $results.network_shares.Count

    $overallStatus = if ($results.arp_anomalies.Count -gt 0 -or ($suspConnCount -gt 5)) { "danger" } elseif ($suspConnCount -gt 0 -or $results.dns_issues.Count -gt 0) { "warn" } else { "safe" }

    $logLevel = if ($overallStatus -eq "danger") { "ERROR" } elseif ($overallStatus -eq "warn") { "WARN" } else { "INFO" }
    Write-JDSLog $logLevel "NETWORK-SEC: $openPortCount offene Ports, $suspConnCount verdaectige Verbindungen, $($results.dns_issues.Count) DNS-Auffaelligkeiten"

    if ($results.arp_anomalies.Count -gt 0 -and $cfg.alert_on_arp_spoof) {
        $alert = @{ type = "Critical"; title = "ARP-Anomalie"; message = "$($results.arp_anomalies.Count) ARP-Auffaelligkeiten - moeglicher ARP-Spoofing" }
        Send-JDSAlert $Config $alert
    }
    if ($results.suspicious_connections.Count -gt 5) {
        $alert = @{ type = "Warning"; title = "Verdaectige Verbindungen"; message = "$($results.suspicious_connections.Count) verdaectige Netzwerkverbindungen" }
        Send-JDSAlert $Config $alert
    }

    return @{
        status = $overallStatus
        open_ports = $openPortCount
        listening_services = $results.listening_services.Count
        suspicious_connections = $suspConnCount
        dns_issues = $results.dns_issues.Count
        arp_anomalies = $results.arp_anomalies.Count
        network_shares = $shareCount
        firewall_rules = $results.firewall_health.Count
        scan_duration_sec = [Math]::Round(((Get-Date) - $scanStart).TotalSeconds, 1)
        details = @($results.suspicious_connections[0..5]; $results.arp_anomalies[0..3])
    }
}

function Invoke-NetworkDefense {
    param([hashtable]$Config)
    $cfg = Initialize-NetworkSecurity -Config $Config
    if (-not $cfg.enabled) { return }

    if ($cfg.block_malicious_dns) {
        $hostsPath = "$env:WINDIR\System32\drivers\etc\hosts"
        if ($cfg.dns_blocklist -and $cfg.dns_blocklist.Count -gt 0) {
            $hostsContent = Get-Content $hostsPath -Raw -ErrorAction SilentlyContinue -Encoding UTF8
            $addedCount = 0
            foreach ($domain in $cfg.dns_blocklist) {
                if ($domain -notmatch '^[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,}$') { continue }
                if ($hostsContent -notmatch [regex]::Escape($domain)) {
                    Add-Content $hostsPath -Value "0.0.0.0 $domain" -Encoding UTF8 -Force -ErrorAction SilentlyContinue
                    $addedCount++
                }
            }
            if ($addedCount -gt 0) { Write-JDSLog "INFO" "NETWORK-SEC: $addedCount malware-Domains zur hosts-Datei hinzugefuegt" }
        }
    }

    if ($cfg.harden_network) {
        try {
            $tcpParams = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -ErrorAction SilentlyContinue
            if (-not $tcpParams.SynAttackProtect -or $tcpParams.SynAttackProtect -ne 1) {
                Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name "SynAttackProtect" -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
            }
            if (-not $tcpParams.EnableICMPRedirect -or $tcpParams.EnableICMPRedirect -ne 0) {
                Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name "EnableICMPRedirect" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
            }
            if (-not $tcpParams.DisableIPSourceRouting) {
                Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name "DisableIPSourceRouting" -Value 2 -Type DWord -Force -ErrorAction SilentlyContinue
            }
            Write-JDSLog "INFO" "NETWORK-SEC: TCP/IP-Haertung angewendet (SynAttackProtect, ICMP-Redirect, IP-SourceRouting)"
        } catch { }
    }

    if ($cfg.block_netbios) {
        try {
            $netbtParams = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" -ErrorAction SilentlyContinue
            if (-not $netbtParams.SMBDeviceEnabled -or $netbtParams.SMBDeviceEnabled -ne 0) {
                Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" -Name "SMBDeviceEnabled" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
                Write-JDSLog "INFO" "NETWORK-SEC: NetBIOS ueber TCP/IP deaktiviert"
            }
        } catch { }
    }

    if ($cfg.log_all_connections) {
        try {
            $auditPolicy = Get-AuditPolicy -SubCategory "{0CCE9226-69AE-11D9-BED3-505054503030}" -ErrorAction SilentlyContinue
            if (-not $auditPolicy -or $auditPolicy.IncludeSAS -eq "None") {
                & "$env:WINDIR\system32\auditpol.exe" /set /subcategory:"Filtering Platform Connection" /success:enable /failure:enable | Out-Null
                Write-JDSLog "INFO" "NETWORK-SEC: Netzwerkverbindungs-Auditing aktiviert"
            }
        } catch { }
    }
}

function Start-NetworkMonitor {
    param([hashtable]$Config)
    $cfg = Initialize-NetworkSecurity -Config $Config
    if (-not $cfg.enabled) { return }

    $interval = if ($cfg.monitor_interval_seconds) { $cfg.monitor_interval_seconds } else { 180 }

    Invoke-NetworkDefense -Config $Config
    Write-JDSLog "INFO" "NETWORK-SEC: Netzwerkueberwachung gestartet (Intervall: ${interval}s)"

    while ($true) {
        Start-Sleep -Seconds $interval
        $result = Invoke-NetworkSecurityScan -Config $Config
        if ($result.status -ne "safe") {
            $alert = @{ type = if ($result.status -eq "danger") { "Critical" } else { "Warning" }; title = "Netzwerksicherheit"; message = "$($result.suspicious_connections) verdaectige Verbindungen, $($result.arp_anomalies) ARP-Anomalien" }
            Send-JDSAlert $Config $alert
        }
    }
}

function Invoke-FastPortScan {
    param([string[]]$TargetIPs = @("127.0.0.1"), [int[]]$Ports = @(21,22,23,25,53,80,110,135,139,143,443,445,993,995,1433,1521,2049,3306,3389,5432,5900,6379,8080,8443,27017))
    $results = @()
    foreach ($ip in $TargetIPs) {
        foreach ($port in $Ports) {
            try {
                $socket = New-Object System.Net.Sockets.TcpClient
                $async = $socket.BeginConnect($ip, $port, $null, $null)
                $wait = $async.AsyncWaitHandle.WaitOne(100)
                if ($wait -and $socket.Connected) {
                    $results += @{ ip = $ip; port = $port; state = "open" }
                    $socket.EndConnect($async)
                }
                $socket.Close()
            } catch { }
        }
    }
    return $results
}
