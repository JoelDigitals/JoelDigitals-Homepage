﻿function Initialize-SelfDefense {
    param([hashtable]$Config)
    $cfg = $Config.self_defense
    if (-not $cfg.enabled) { return }

    $installPath = $Config.general.install_path
    $dataPath = $Config.general.data_path

    return @{
        install_path = $installPath
        data_path = $dataPath
        watch_files = @(
            (Join-Path $installPath "jds-secure.ps1"),
            (Join-Path $installPath "config\security-config.json"),
            (Join-Path $installPath "modules\*"),
            (Join-Path $installPath "tools\jds-service.ps1")
        )
    }
}

function Invoke-SelfDefenseCheck {
    param([hashtable]$Config, [bool]$ShowProgress = $false)
    $cfg = $Config.self_defense
    if (-not $cfg.enabled) { return @{ status = "disabled" } }

    $threats = @()
    $protections = @()
    $scanStart = Get-Date

    if ($ShowProgress) { Write-Host "  [SELF-DEFENSE] Pruefe JDS-Secure-Integritaet..." -ForegroundColor Cyan }

    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) { $protections += @{ type = "warn"; detail = "Nicht als Administrator ausgefuehrt - eingeschraenkter Selbstschutz" } }

    try {
        $installPath = $Config.general.install_path
        $dataPath = $Config.general.data_path

        if ($installPath -and (Test-Path $installPath)) {
            $acl = Get-Acl $installPath -ErrorAction SilentlyContinue
            if ($acl) {
                $everyoneAccess = $acl.Access | Where-Object { $_.IdentityReference -match "Jeder|Everyone|BUILTIN\\Benutzer|NT AUTHORITY\\Authenticated Users" -and $_.FileSystemRights -match "FullControl|Modify|Write" }
                if ($everyoneAccess) {
                    $threats += @{ type = "weak_acl"; severity = "warn"; detail = "Installationsverzeichnis hat zu weitlaeufige Berechtigungen"; path = $installPath }
                }
            }

            $criticalFiles = @("jds-secure.ps1", "config\security-config.json", "tools\jds-service.ps1")
            foreach ($cf in $criticalFiles) {
                $cfPath = Join-Path $installPath $cf
                if (Test-Path $cfPath) {
                    $hash = Get-FileHash $cfPath -Algorithm SHA256 -ErrorAction SilentlyContinue
                    if ($hash) {
                        $protections += @{ type = "hash"; file = $cf; hash = $hash.Hash }
                    }
                }
            }
        }

        try {
            $processes = Get-Process -Name "*JDS*", "*jds*", "*secure*" -ErrorAction SilentlyContinue
            if ($processes.Count -eq 0 -and $cfg.check_process) {
                $threats += @{ type = "not_running"; severity = "info"; detail = "JDS-Secure-Prozess nicht im Task-Manager sichtbar" }
            }
        } catch { }

        try {
            $services = Get-Service -Name "JDSSecure" -ErrorAction SilentlyContinue
            if ($services -and $services.Status -ne "Running" -and $cfg.check_service) {
                $threats += @{ type = "service_stopped"; severity = "warn"; detail = "JDSSecure-Dienst laeuft nicht" }
            }
        } catch { }

        try {
            $tasks = Get-ScheduledTask -TaskName "JDS-Secure-*" -ErrorAction SilentlyContinue
            if ($tasks.Count -eq 0 -and $cfg.check_tasks) {
                $threats += @{ type = "tasks_missing"; severity = "warn"; detail = "Keine JDS-Secure Tasks gefunden - moeglicherweise entfernt" }
            }
        } catch { }

        try {
            $eventLog = Get-WinEvent -LogName "JDS-Secure" -MaxEvents 1 -ErrorAction SilentlyContinue
            if (-not $eventLog -and $cfg.check_eventlog) {
                $threats += @{ type = "eventlog_missing"; severity = "info"; detail = "JDS-Secure Event Log nicht gefunden" }
            }
        } catch { }

        try {
            $watchFiles = @("jds-secure.ps1", "config\security-config.json")
            foreach ($wf in $watchFiles) {
                $wfPath = Join-Path $installPath $wf
                if (Test-Path $wfPath) {
                    $currentHash = Get-FileHash $wfPath -Algorithm SHA256 -ErrorAction SilentlyContinue
                    if ($currentHash -and $cfg.known_hashes -and $cfg.known_hashes.$wf) {
                        if ($currentHash.Hash -ne $cfg.known_hashes.$wf) {
                            $threats += @{ type = "file_modified"; severity = "danger"; detail = "$wf wurde modifiziert - moegliche Manipulation"; file = $wf }
                        }
                    }
                }
            }
        } catch { }

        try {
            $configMod = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\JDSSecure" -ErrorAction SilentlyContinue
            if (-not $configMod -and $cfg.check_registry) {
                $threats += @{ type = "regkey_missing"; severity = "info"; detail = "JDS-Secure nicht in installierter Software-Liste" }
            }
        } catch { }

        if ($cfg.dead_man_switch) {
            $signalFile = "$env:ProgramData\JDS-Secure\.heartbeat"
            try {
                if (-not (Test-Path $env:ProgramData\JDS-Secure)) { New-Item -ItemType Directory -Path $env:ProgramData\JDS-Secure -Force | Out-Null }
                Set-Content -Path $signalFile -Value ((Get-Date).ToString('o')) -Force -ErrorAction SilentlyContinue
                $protections += @{ type = "heartbeat"; file = $signalFile }
            } catch { }
        }
    } catch {
        Write-JDSLog "WARN" "SELF-DEFENSE: Pruefung fehlgeschlagen: $_"
    }

    $dangerCount = ($threats | Where-Object { $_.severity -eq "danger" }).Count
    $warnCount = ($threats | Where-Object { $_.severity -eq "warn" }).Count

    foreach ($threat in $threats) {
        if ($threat.severity -eq "danger") {
            Write-JDSLog "CRITICAL" "SELF-DEFENSE: $($threat.detail)"
            $alert = @{ type = "Critical"; title = "Selbstschutz-Alarm"; message = $threat.detail }
            Send-JDSAlert $Config $alert

            if ($cfg.auto_recover -and $threat.type -eq "file_modified") {
                Write-JDSLog "WARN" "SELF-DEFENSE: Automatische Wiederherstellung von $($threat.file)..."
            }
        } elseif ($threat.severity -eq "warn") {
            Write-JDSLog "WARN" "SELF-DEFENSE: $($threat.detail)"
        }
    }

    return @{
        status = if ($dangerCount -gt 0) { "danger" } elseif ($warnCount -gt 0) { "warn" } else { "safe" }
        threats = $threats.Count
        danger_threats = $dangerCount
        warning_threats = $warnCount
        protections_active = $protections.Count
        scan_duration_sec = [Math]::Round(((Get-Date) - $scanStart).TotalSeconds, 1)
        details = $threats
    }
}

function Start-SelfDefenseMonitor {
    param([hashtable]$Config)
    $cfg = $Config.self_defense
    if (-not $cfg.enabled) { return }

    $interval = if ($cfg.check_interval_seconds) { $cfg.check_interval_seconds } else { 600 }
    Write-JDSLog "INFO" "SELF-DEFENSE: Selbstschutz-Ueberwachung gestartet (Intervall: ${interval}s)"

    while ($true) {
        Start-Sleep -Seconds $interval
        $result = Invoke-SelfDefenseCheck -Config $Config
        if ($result.status -eq "danger") {
            Write-JDSLog "CRITICAL" "SELF-DEFENSE: $($result.danger_threats) kritische Bedrohungen gegen JDS Secure!"
            $alert = @{ type = "Critical"; title = "JDS-Secure Selbstschutz"; message = "$($result.danger_threats) kritische Bedrohungen erkannt" }
            Send-JDSAlert $Config $alert
        }
    }
}
