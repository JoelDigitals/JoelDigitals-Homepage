# JDS Secure - Schnellstart (Deutsch)

## Installation

```powershell
.\setup.ps1 -Easy
```

Oder mit grafischem Assistenten:

```powershell
.\setup.ps1 -GUI
```

## Start

```powershell
.\jds-secure.ps1 -Mode GUI          # Grafische Oberflaeche (empfohlen)
.\jds-secure.ps1 -Mode Interactive  # Konsolen-Menue
.\jds-secure.ps1 -Mode Service      # Hintergrunddienst (14 Daemons)
.\jds-secure.ps1 -Mode QuickScan    # Schnellscan
```

## Wichtige Befehle

| Aktion | Befehl |
|--------|--------|
| Vollscan | `Invoke-FullScan` |
| Backup | `Invoke-BackupSystem` |
| Firewall haerten | `Invoke-FirewallHardening` |
| DSGVO-Meldung | `New-GDPRBreachNotification` |
| Virenscan | `Invoke-VirusScan -ScanType quick` |
| Bericht | `Export-SecurityReport` |

## DSGVO-Pflichten

- **Art. 33**: Meldung einer Datenschutzverletzung via Menuepunkt 19
- **Art. 30**: Verarbeitungsverzeichnis via DSGVO-Menu (Option 4)
- **Art. 32**: TOM-Dokumentation via DSGVO-Menu (Option 5)
- **Art. 17**: Loeschkonzept via Datenbereinigung (Option 2)

## Systemanforderungen

- Windows 10/11 oder Windows Server 2016+
- PowerShell 5.1+
- Administratorrechte fuer Firewall/Service-Installation

---

## Haftungsausschluss

Dieses System unterstuetzt bei der Einhaltung von Sicherheitsstandards und
DSGVO-Anforderungen, ersetzt jedoch keine rechtsverbindliche Pruefung.
Der Entwickler uebernimmt keine Haftung. Vor produktivem Einsatz ist eine
umfassende Pruefung durch Fachpersonal erforderlich.
