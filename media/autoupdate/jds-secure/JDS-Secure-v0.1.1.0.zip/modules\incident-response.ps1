﻿function Initialize-IncidentResponse {
    param([hashtable]$Config)
    $cfg = $Config.incident_response
    if (-not $cfg.enabled) { return }

    return @{
        playbook_path = "$($Config.general.data_path)\playbooks"
        evidence_path = "$($Config.general.data_path)\evidence"
    }
}

function Invoke-IncidentResponse {
    param(
        [hashtable]$Config,
        [string]$IncidentType = "generic",
        [string]$Severity = "warning",
        [string]$Description = "",
        [string]$Source = "",
        [hashtable]$Context = @{},
        [bool]$Automated = $true
    )

    $cfg = $Config.incident_response
    if (-not $cfg.enabled) { return @{ status = "disabled" } }

    $ir = Initialize-IncidentResponse -Config $Config
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $incidentId = "INC-$(Get-Date -Format 'yyyyMMdd')-$([System.Guid]::NewGuid().ToString('N').Substring(0,6))"

    Write-JDSLog "CRITICAL" "INCIDENT: [$incidentId] $IncidentType/$Severity - $Description (Quelle: $Source)"

    if (-not (Test-Path $ir.evidence_path)) { New-Item -ItemType Directory -Path $ir.evidence_path -Force | Out-Null }
    if (-not (Test-Path $ir.playbook_path)) { New-Item -ItemType Directory -Path $ir.playbook_path -Force | Out-Null }

    $evidenceDir = Join-Path $ir.evidence_path $incidentId
    New-Item -ItemType Directory -Path $evidenceDir -Force | Out-Null

    $incidentRecord = @{
        id = $incidentId
        timestamp = $timestamp
        type = $IncidentType
        severity = $Severity
        description = $Description
        source = $Source
        context = $Context
        automated = $Automated
        computer = $env:COMPUTERNAME
        user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        actions_taken = @()
    }

    $actionsTaken = @()

    if ($Automated) {
        switch ($IncidentType) {
            "ransomware" {
                if ($cfg.action_kill_processes) {
                    $suspProcs = @("*ransom*", "*encrypt*", "*crypto*", "*lock*", "*bit*", "*decrypt*")
                    foreach ($pn in $suspProcs) {
                        try { Get-Process -Name $pn -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue; $actionsTaken += "Prozesse beendet: $pn" } catch { }
                    }
                }
                if ($cfg.action_block_shares) {
                    try { Get-SmbShare | Where-Object { $_.Name -notmatch '\$$' } | Remove-SmbShare -Force -ErrorAction SilentlyContinue; $actionsTaken += "SMB-Freigaben geschlossen" } catch { }
                }
                if ($cfg.action_create_restore_point) {
                    try { & "$env:WINDIR\system32\wbem\WMIC.exe" /namespace:\\root\default path SystemRestore call CreateRestorePoint "JDS-IR-Ransomware-$incidentId", 0, 100 | Out-Null; $actionsTaken += "Wiederherstellungspunkt erstellt" } catch { }
                }
                if ($cfg.action_enable_defender) {
                    try { Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction SilentlyContinue; $actionsTaken += "Defender-Echtzeitschutz aktiviert" } catch { }
                }
                if ($cfg.action_collect_evidence) {
                    try {
                        Get-Process | Export-Csv (Join-Path $evidenceDir "processes.csv") -NoTypeInformation -Encoding UTF8
                        Get-NetTCPConnection | Export-Csv (Join-Path $evidenceDir "connections.csv") -NoTypeInformation -Encoding UTF8
                        $actionsTaken += "Beweissicherung: Prozesse + Verbindungen"
                    } catch { }
                }
            }

            "intrusion" {
                if ($cfg.action_block_ip) {
                    try {
                        $ip = if ($Context.remote_ip) { $Context.remote_ip } else { "" }
                        if ($ip) { New-NetFirewallRule -DisplayName "JDS-IR-Block-$incidentId" -Direction Inbound -RemoteAddress $ip -Action Block -ErrorAction SilentlyContinue; $actionsTaken += "IP blockiert: $ip" }
                    } catch { }
                }
                if ($cfg.action_collect_evidence) {
                    try {
                        Get-NetTCPConnection | Where-Object { $_.State -eq "Established" } | Export-Csv (Join-Path $evidenceDir "connections.csv") -NoTypeInformation -Encoding UTF8
                        netstat -anob | Out-File (Join-Path $evidenceDir "netstat.txt") -Encoding UTF8
                        Get-Service | Export-Csv (Join-Path $evidenceDir "services.csv") -NoTypeInformation -Encoding UTF8
                        $actionsTaken += "Beweissicherung: Netzwerk + Dienste"
                    } catch { }
                }
            }

            "integrity" {
                if ($cfg.action_integrity_check) {
                    try { Invoke-IntegrityBaseline -Config $Config; $actionsTaken += "Neue Integritats-Baseline erstellt" } catch { }
                }
            }

            "process" {
                if ($cfg.action_kill_blacklisted) {
                    $blacklisted = $Config.process_security.blacklist
                    foreach ($bl in $blacklisted) {
                        try { Get-Process -Name $bl -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue; $actionsTaken += "Blacklisted Prozess beendet: $bl" } catch { }
                    }
                    if ($Context.process_ids) {
                        foreach ($pid in $Context.process_ids) {
                            try { Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue; $actionsTaken += "Prozess beendet: PID $pid" } catch { }
                        }
                    }
                }
            }

            "vulnerability" {
                if ($cfg.action_apply_mitigations) {
                    try {
                        Invoke-FirewallHardening -Config $Config
                        $actionsTaken += "Firewall-Hartung angewendet"
                    } catch { }
                    try {
                        Invoke-NetworkDefense -Config $Config
                        $actionsTaken += "Netzwerk-Hartung angewendet"
                    } catch { }
                }
            }

            "default" {
                $actionsTaken += "Vorfall dokumentiert (keine automatische Aktion fuer Typ: $IncidentType)"
            }
        }

        if ($cfg.action_create_report) {
            try {
                Export-SecurityReport -Config $Config | Out-Null
                $actionsTaken += "Sicherheitsbericht erstellt"
            } catch { }
        }
    }

    $incidentRecord.actions_taken = $actionsTaken

    $incidentFile = Join-Path $evidenceDir "incident.json"
    $incidentRecord | ConvertTo-Json -Depth 10 | Set-Content $incidentFile -Encoding UTF8 -Force

    $incidentsFile = Join-Path $ir.evidence_path "incidents.json"
    $existingIncidents = @()
    if (Test-Path $incidentsFile) { try { $existingIncidents = Get-Content $incidentsFile -Raw -Encoding UTF8 | ConvertFrom-Json } catch { } }
    $allIncidents = @($existingIncidents) + $incidentRecord
    $allIncidents | ConvertTo-Json -Depth 10 | Set-Content $incidentsFile -Encoding UTF8 -Force

    $alert = @{
        type = if ($Severity -eq "critical") { "Critical" } else { "Warning" }
        title = "Incident Response: $IncidentType"
        message = "$Description | Aktionen: $($actionsTaken -join '; ')"
    }
    Send-JDSAlert $Config $alert

    Write-JDSLog "INFO" "INCIDENT: [$incidentId] Aktionen: $($actionsTaken.Count) durchgefuehrt"
    return @{
        status = "ok"
        incident_id = $incidentId
        incident_path = $incidentFile
        evidence_path = $evidenceDir
        type = $IncidentType
        severity = $Severity
        actions_taken = $actionsTaken
        actions_count = $actionsTaken.Count
    }
}

function Get-IncidentHistory {
    param([hashtable]$Config, [int]$Limit = 20)
    $evidencePath = "$($Config.general.data_path)\evidence"
    $incidentsFile = Join-Path $evidencePath "incidents.json"
    if (-not (Test-Path $incidentsFile)) { return @() }
    try {
        $incidents = Get-Content $incidentsFile -Raw -Encoding UTF8 | ConvertFrom-Json
        return $incidents | Sort-Object { [DateTime]$_.timestamp } -Descending | Select-Object -First $Limit
    } catch { return @() }
}

function Test-IncidentResponse {
    param([hashtable]$Config)
    Write-JDSLog "INFO" "INCIDENT: Teste Incident-Response-System..."
    $result = Invoke-IncidentResponse -Config $Config -IncidentType "test" -Severity "info" -Description "Test-Event vom Administrator" -Source "admin_test" -Automated $false
    Write-JDSLog "INFO" "INCIDENT: Test abgeschlossen - ID: $($result.incident_id)"
    return $result
}

function Invoke-AutoRespond {
    param([hashtable]$Config, [hashtable]$ScanResults)
    $cfg = $Config.incident_response
    if (-not $cfg.enabled -or -not $cfg.auto_respond) { return }

    if ($ScanResults.ransomware -and $ScanResults.ransomware.status -eq "danger") {
        Invoke-IncidentResponse -Config $Config -IncidentType "ransomware" -Severity "critical" -Description "Ransomware-Aktivitaet erkannt ($($ScanResults.ransomware.suspicious_findings) Indikatoren)" -Source "ransomware" -Context $ScanResults.ransomware
    }
    if ($ScanResults.process -and $ScanResults.process.blacklisted -gt 0) {
        Invoke-IncidentResponse -Config $Config -IncidentType "process" -Severity "critical" -Description "$($ScanResults.process.blacklisted) blacklisted Prozesse" -Source "process_security" -Context $ScanResults.process
    }
    if ($ScanResults.integrity -and $ScanResults.integrity.critical -gt 0) {
        Invoke-IncidentResponse -Config $Config -IncidentType "integrity" -Severity "critical" -Description "$($ScanResults.integrity.critical) kritische Integritaetsverletzungen" -Source "file_integrity" -Context $ScanResults.integrity
    }
    if ($ScanResults.vulnerability -and $ScanResults.vulnerability.critical -gt 0) {
        Invoke-IncidentResponse -Config $Config -IncidentType "vulnerability" -Severity "warning" -Description "$($ScanResults.vulnerability.critical) kritische Sicherheitsluecken" -Source "vulnerability_scan" -Context $ScanResults.vulnerability
    }
}
