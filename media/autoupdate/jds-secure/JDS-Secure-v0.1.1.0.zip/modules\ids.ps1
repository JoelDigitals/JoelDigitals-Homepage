﻿function Invoke-IDSMonitor {
    param([hashtable]$Config)

    $ids = $Config.ids
    if (-not $ids.enabled) { Write-JDSLog "WARN" "IDS module is disabled"; return }

    Write-JDSLog "INFO" "Starting Intrusion Detection System scan..."

    $alerts = @()
    $suspiciousFound = $false

    try {
        $suspiciousProcesses = $ids.suspicious_processes | ForEach-Object { $_ -replace '\.exe$', '' }

        $runningProcesses = Get-Process -ErrorAction SilentlyContinue
        foreach ($proc in $runningProcesses) {
            $procName = $proc.ProcessName.ToLower()
            foreach ($susp in $suspiciousProcesses) {
                if ($procName -eq $susp.ToLower()) {
                    Write-JDSLog "WARN" "Verdaechtiger Prozess erkannt: $($proc.ProcessName) (PID: $($proc.Id))"
                    $alerts += [PSCustomObject]@{
                        Type = "Warning"
                        Title = "Verdaechtiger Prozess"
                        Message = "Prozess '$($proc.ProcessName)' (PID: $($proc.Id)) wurde erkannt"
                        Timestamp = Get-Date
                    }
                    $suspiciousFound = $true
                }
            }
        }

        $listeningPorts = netstat -an | Select-String "LISTENING"
        foreach ($line in $listeningPorts) {
            if ($line -match "TCP\s+0\.0\.0\.0:(\d+)") {
                $portNum = [int]$Matches[1]
                if ($portNum -in $ids.suspicious_ports) {
                    $procInfo = Get-NetTCPConnection -LocalPort $portNum -ErrorAction SilentlyContinue
                    $owningProc = if ($procInfo) { (Get-Process -Id $procInfo.OwningProcess -ErrorAction SilentlyContinue).ProcessName } else { "Unknown" }
                    Write-JDSLog "WARN" "Verdaechtiger Port $portNum geoeffnet von $owningProc"
                    $alerts += [PSCustomObject]@{
                        Type = "Warning"
                        Title = "Verdaechtiger Port"
                        Message = "Port $portNum geoeffnet von $owningProc"
                        Timestamp = Get-Date
                    }
                    $suspiciousFound = $true
                }
            }
        }

        if ($ids.monitor_scheduled_tasks) {
            $tasks = Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.State -ne "Disabled" }
            $suspiciousTasks = $tasks | Where-Object {
                $_.TaskPath -match "\\Temp\\|\\Temporary\\" -or
                ($_.Actions.Execute -and $_.Actions.Execute -match "temp|appdata|powershell.*-enc")
            }
            foreach ($task in $suspiciousTasks) {
                Write-JDSLog "WARN" "Verdaechtiger Scheduled Task: $($task.TaskName) ($($task.TaskPath))"
                $alerts += [PSCustomObject]@{
                    Type = "Warning"
                    Title = "Verdaechtiger Task"
                    Message = "Task '$($task.TaskName)' in ungewoehnlicher Pfad"
                    Timestamp = Get-Date
                }
                $suspiciousFound = $true
            }
        }

        if ($ids.monitor_registry_changes) {
            $autorunPaths = @(
                "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
                "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce",
                "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
                "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnceEx"
            )
            foreach ($rPath in $autorunPaths) {
                try {
                    $items = Get-ItemProperty -Path $rPath -ErrorAction SilentlyContinue
                    $props = $items.PSObject.Properties | Where-Object { $_.Name -notlike "PS*" }
                    foreach ($prop in $props) {
                        if ($prop.Value -match "temp|powershell.*-.*enc|rundll32.*http|regsvr32.*http") {
                            Write-JDSLog "WARN" "Verdaechtiger AutoRun-Eintrag: $($prop.Name) = $($prop.Value)"
                            $alerts += [PSCustomObject]@{
                                Type = "Warning"
                                Title = "Verdaechtiger AutoRun"
                                Message = "$($prop.Name) in $rPath"
                                Timestamp = Get-Date
                            }
                            $suspiciousFound = $true
                        }
                    }
                } catch {}
            }
        }

        if ($ids.alert_on_failed_logins) {
            $threshold = $ids.failed_login_threshold
            $failedLogins = Get-WinEvent -FilterHashtable @{LogName='Security'; ID=4625} -MaxEvents 1000 -ErrorAction SilentlyContinue |
                Where-Object { $_.TimeCreated -gt (Get-Date).AddHours(-1) }

            if ($failedLogins -and $failedLogins.Count -ge $threshold) {
                $uniqueIps = $failedLogins | ForEach-Object {
                    if ($_.Message -match "Quellnetzwerkadresse:\s+(\S+)") { $Matches[1] }
                } | Select-Object -Unique

                Write-JDSLog "WARN" "Erhoehte Fehlanmeldungen: $($failedLogins.Count) in 1h von $($uniqueIps.Count) IP(s)"
                $alerts += [PSCustomObject]@{
                    Type = "Critical"
                    Title = "Brute-Force-Versuch"
                    Message = "$($failedLogins.Count) fehlgeschlagene Anmeldungen von $($uniqueIps.Count) IP(s)"
                    Timestamp = Get-Date
                }
                $suspiciousFound = $true
            }
        }

        if ($ids.alert_on_new_user) {
            $recentUsers = Get-LocalUser -ErrorAction SilentlyContinue | Where-Object {
                $_.LastLogon -and $_.LastLogon -gt (Get-Date).AddHours(-24)
            }
            # Wohlbekannte SID statt lokalisiertem Gruppennamen ("Administratoren") -
            # funktioniert unabhaengig von der Systemsprache.
            $adminGroup = Get-LocalGroupMember -SID "S-1-5-32-544" -ErrorAction SilentlyContinue
            $newAdmins = $adminGroup | Where-Object {
                $_.ObjectClass -eq "User" -and
                (Get-LocalUser -Name $_.Name -ErrorAction SilentlyContinue).LastLogon -gt (Get-Date).AddDays(-7)
            }
            if ($newAdmins.Count -gt 0) {
                Write-JDSLog "WARN" "Neue Admin-Benutzer erkannt: $($newAdmins.Count)"
                $alerts += [PSCustomObject]@{
                    Type = "Critical"
                    Title = "Neue Administrator-Konten"
                    Message = "Es wurden $($newAdmins.Count) neue Administratoren hinzugefuegt"
                    Timestamp = Get-Date
                }
                $suspiciousFound = $true
            }
        }

        if ($suspiciousFound) {
            foreach ($alert in $alerts) {
                Send-JDSAlert $Config @{
                    type = $alert.Type
                    title = $alert.Title
                    message = $alert.Message
                }
            }
        } else {
            Write-JDSLog "INFO" "IDS scan completed - no threats detected"
        }

        return [PSCustomObject]@{
            ThreatsFound = $suspiciousFound
            Alerts = $alerts
            ScanTime = Get-Date
        }
    } catch {
        Write-JDSLog "ERROR" "IDS scan failed: $_"
        return [PSCustomObject]@{
            ThreatsFound = $false
            Alerts = @()
            ScanTime = Get-Date
            Error = $_
        }
    }
}

function Invoke-IDSContinuous {
    param(
        [hashtable]$Config,
        [int]$Interval = 30
    )

    $ids = $Config.ids
    $interval = if ($ids.scan_interval_seconds) { $ids.scan_interval_seconds } else { $Interval }

    Write-JDSLog "INFO" "Starting continuous IDS monitoring every ${interval}s..."

    while ($true) {
        Invoke-IDSMonitor -Config $Config
        Start-Sleep -Seconds $interval
    }
}

function Add-JDSSuspiciousProcess {
    param([string]$ProcessName)

    $configPath = "$PSScriptRoot\..\config\security-config.json"
    $config = Get-Content $configPath -Raw | ConvertFrom-Json

    $processList = @($config.ids.suspicious_processes) + $ProcessName
    $config.ids.suspicious_processes = $processList | Select-Object -Unique

    $config | ConvertTo-Json -Depth 10 | Set-Content $configPath
    Write-JDSLog "INFO" "Added '$ProcessName' to suspicious processes list"
}


