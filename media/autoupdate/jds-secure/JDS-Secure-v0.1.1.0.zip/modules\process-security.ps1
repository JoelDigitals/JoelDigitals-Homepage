﻿function Initialize-ProcessSecurity {
    param([hashtable]$Config)
    $cfg = $Config.process_security
    if (-not $cfg.enabled) { return }

    if (-not $cfg.blacklist) { $cfg.blacklist = @("mimikatz", "wireshark", "nc.exe", "netcat", "nmap", "sqlmap", "hydra", "john", "hashcat", "procdump", "psexec", "cain", "abel", "rdpwrap", "anydesk", "teamviewer", "vnc", "pth", "meterpreter", "shellter", "veil", "responder", "impacket", "bloodhound", "sharp", "certipy", "kerbrute", "asreproast", "keberoast", "pypykatz", "dumpert", "mimipenguin", "laZagne", "spray", "brute", "crack", "hash", "backdoor", "keylog", "inject") }

    if (-not $cfg.low_integrity_risk) { $cfg.low_integrity_risk = @("cmd.exe", "powershell.exe", "pwsh.exe", "wscript.exe", "cscript.exe", "mshta.exe", "regsvr32.exe", "rundll32.exe", "certutil.exe", "bitsadmin.exe", "curl.exe", "wget.exe", "ssh.exe", "ftp.exe", "netsh.exe", "nslookup.exe", "ping.exe", "whoami.exe", "net.exe", "net1.exe", "schtasks.exe", "wmic.exe", "taskkill.exe", "tasklist.exe", "sc.exe", "bcdedit.exe", "reg.exe", "regedit.exe", "msiexec.exe", "explorer.exe", "notepad.exe", "calc.exe", "mspaint.exe") }

    if (-not $cfg.alert_threshold_children) { $cfg.alert_threshold_children = 20 }
    if (-not $cfg.alert_threshold_cpu) { $cfg.alert_threshold_cpu = 90 }

    return $cfg
}

function Invoke-ProcessAudit {
    param([hashtable]$Config, [bool]$ShowProgress = $false)
    $cfg = Initialize-ProcessSecurity -Config $Config
    if (-not $cfg.enabled) { return @{ status = "disabled" } }

    $results = @{ suspicious = @(); blacklisted = @(); unknown = @(); high_resource = @(); parent_analysis = @(); network_connections = @() }
    $scanStart = Get-Date

    if ($ShowProgress) { Write-Host "  [PROCESS-SEC] Analysiere laufende Prozesse..." -ForegroundColor Cyan }

    $processes = Get-Process -ErrorAction SilentlyContinue

    foreach ($proc in $processes) {
        $procName = $proc.ProcessName.ToLower()
        $procPath = ""
        try { $procPath = $proc.Path } catch { try { $procPath = (Get-Process -Id $proc.Id -ErrorAction SilentlyContinue).Path } catch { } }

        if ($procName -in $cfg.blacklist) {
            $results.blacklisted += @{ name = $procName; id = $proc.Id; path = $procPath; cpu = [Math]::Round($proc.CPU, 1); memory_mb = [Math]::Round($proc.WorkingSet / 1MB, 1); start_time = try { $proc.StartTime.ToString("o") } catch { "N/A" } }
        }

        if ($cfg.detect_suspicious_parents -and $procPath) {
            try {
                $parent = Get-CimInstance Win32_Process -Filter "ProcessId = $($proc.Id)" -ErrorAction SilentlyContinue
                if ($parent) {
                    $parentProc = Get-Process -Id $parent.ParentProcessId -ErrorAction SilentlyContinue
                    if ($parentProc -and $parentProc.ProcessName.ToLower() -in @("explorer", "svchost", "services", "winlogon") -and $procName -in @("cmd.exe", "powershell.exe", "wscript.exe", "cscript.exe")) {
                        $results.parent_analysis += @{ process = $procName; id = $proc.Id; parent = $parentProc.ProcessName; parent_id = $parentProc.Id; suspicious = $true }
                    }
                }
            } catch { }
        }

        if ($cfg.detect_suspicious_paths -and $procPath) {
            $procDir = (Get-Item $procPath -ErrorAction SilentlyContinue).DirectoryName
            if ($procDir -match '\\AppData\\|\\Temp\\|\\Users\\[^\\]+\\Desktop\\|\\Downloads\\|C:\\Windows\\Temp\\') {
                if ($procName -in $cfg.low_integrity_risk) {
                    $results.suspicious += @{ name = $procName; id = $proc.Id; path = $procPath; reason = "ausfuehrung_von_temp"; directory = $procDir }
                }
            }
        }

        if ($cfg.detect_unsigned -and $procPath -and (Test-Path $procPath)) {
            try {
                $cert = (Get-AuthenticodeSignature $procPath -ErrorAction SilentlyContinue)
                if ($cert -and $cert.Status -ne "Valid" -and $cert.Status -ne "NotSigned" -and $procName -notin @("svchost", "csrss", "wininit", "winlogon", "lsass", "services", "smss", "system", "idle")) {
                    $results.suspicious += @{ name = $procName; id = $proc.Id; path = $procPath; reason = "unsigned_binary"; sign_status = $cert.Status.ToString() }
                }
            } catch { }
        }

        if ($cfg.detect_high_resource) {
            $cpu = try { $proc.CPU } catch { 0 }
            $mem = try { $proc.WorkingSet / 1MB } catch { 0 }
            if ($cpu -gt 100 -or $mem -gt 500) {
                if ($procName -notin @("svchost", "system", "idle", "csrss", "services", "lsass", "wininit", "winlogon", "smss", "explorer")) {
                    $results.high_resource += @{ name = $procName; id = $proc.Id; cpu = [Math]::Round($cpu, 1); memory_mb = [Math]::Round($mem, 1) }
                }
            }
        }

        if ($cfg.detect_network_servers) {
            try {
                $connections = Get-NetTCPConnection -OwningProcess $proc.Id -ErrorAction SilentlyContinue
                $listenConns = $connections | Where-Object { $_.State -eq "Listen" }
                if ($listenConns -and $procName -notin @("svchost", "System", "lsass", "services", "spoolsv", "sqlservr", "winhttp")) {
                    foreach ($conn in $listenConns) {
                        $results.network_connections += @{ name = $procName; id = $proc.Id; port = $conn.LocalPort; address = $conn.LocalAddress }
                    }
                }
            } catch { }
        }
    }

    if ($cfg.detect_run_keys) {
        $runPaths = @("HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run", "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce")
        foreach ($rp in $runPaths) {
            try {
                $items = Get-ItemProperty $rp -ErrorAction SilentlyContinue
                if ($items) {
                    $items.PSObject.Properties | Where-Object { $_.Name -match '^[^A-Z_]' } | ForEach-Object {
                        $val = $_.Value
                        if ($val -match '(powershell|cmd|wscript|cscript|mshta|regsvr32|rundll32)') {
                            $results.suspicious += @{ name = "runkey"; path = $rp; value = $_.Name; command = $val; reason = "suspicious_run_key" }
                        }
                    }
                }
            } catch { }
        }
    }

    foreach ($bl in $results.blacklisted) {
        Write-JDSLog "ERROR" "PROCESS-SEC: Blacklisted Prozess - $($bl.name) (PID: $($bl.id), Pfad: $($bl.path))"
        $alert = @{ type = "Critical"; title = "Blacklisted Prozess"; message = "$($bl.name) wird ausgefuehrt (PID: $($bl.id))" }
        Send-JDSAlert $Config $alert
        if ($cfg.auto_kill_blacklisted) {
            try { Stop-Process -Id $bl.id -Force -ErrorAction SilentlyContinue; Write-JDSLog "WARN" "PROCESS-SEC: $($bl.name) wurde beendet" } catch { }
        }
    }

    $overallStatus = if ($results.blacklisted.Count -gt 0) { "danger" } elseif ($results.suspicious.Count -gt 0 -or $results.parent_analysis.Count -gt 0) { "warn" } else { "safe" }

    return @{
        status = $overallStatus
        total_processes = $processes.Count
        blacklisted = $results.blacklisted.Count
        suspicious = $results.suspicious.Count
        high_resource = $results.high_resource.Count
        parent_anomalies = $results.parent_analysis.Count
        network_servers = $results.network_connections.Count
        scan_duration_sec = [Math]::Round(((Get-Date) - $scanStart).TotalSeconds, 1)
        details = @($results.blacklisted[0..5]; $results.suspicious[0..5])
    }
}

function Start-ProcessMonitor {
    param([hashtable]$Config)
    $cfg = Initialize-ProcessSecurity -Config $Config
    if (-not $cfg.enabled) { return }

    $interval = if ($cfg.monitor_interval_seconds) { $cfg.monitor_interval_seconds } else { 120 }
    Write-JDSLog "INFO" "PROCESS-SEC: Dauerueberwachung gestartet (Intervall: ${interval}s)"

    $knownProcesses = @{}
    Get-Process -ErrorAction SilentlyContinue | ForEach-Object { $knownProcesses[$_.Id] = $_.ProcessName }

    while ($true) {
        Start-Sleep -Seconds $interval
        $result = Invoke-ProcessAudit -Config $Config

        $currentProcesses = @{}
        Get-Process -ErrorAction SilentlyContinue | ForEach-Object { $currentProcesses[$_.Id] = $_.ProcessName }

        if ($cfg.detect_new_processes) {
            $newProcs = $currentProcesses.Keys | Where-Object { -not $knownProcesses.ContainsKey($_) }
            foreach ($newId in $newProcs) {
                $newName = $currentProcesses[$newId]
                if ($newName -in $cfg.blacklist) {
                    Write-JDSLog "ERROR" "PROCESS-SEC: Blacklisted Prozess gestartet - $newName (PID: $newId)"
                    $alert = @{ type = "Critical"; title = "Blacklisted Prozess gestartet"; message = "$newName (PID: $newId)" }
                    Send-JDSAlert $Config $alert
                    if ($cfg.auto_kill_blacklisted) {
                        try { Stop-Process -Id $newId -Force -ErrorAction SilentlyContinue } catch { }
                    }
                } elseif ($newName -in $cfg.low_integrity_risk) {
                    Write-JDSLog "INFO" "PROCESS-SEC: Neuer Prozess - $newName (PID: $newId)"
                }
            }
        }

        if ($result.status -eq "danger") {
            $alert = @{ type = "Critical"; title = "Prozess-Sicherheitsalarm"; message = "$($result.blacklisted) blacklisted, $($result.suspicious) verdaechtige Prozesse" }
            Send-JDSAlert $Config $alert
        }

        $knownProcesses = $currentProcesses
    }
}
