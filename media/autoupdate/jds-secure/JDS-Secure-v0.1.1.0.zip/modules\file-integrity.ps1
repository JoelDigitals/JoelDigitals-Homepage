﻿function Initialize-FileIntegrity {
    param([hashtable]$Config)
    $cfg = $Config.file_integrity
    if (-not $cfg.enabled) { return }

    $statePath = "$($Config.general.data_path)\integrity"
    if (-not (Test-Path $statePath)) { New-Item -ItemType Directory -Path $statePath -Force | Out-Null }

    return @{ state_path = $statePath }
}

function Invoke-IntegrityBaseline {
    param([hashtable]$Config, [bool]$ShowProgress = $false)
    $cfg = $Config.file_integrity
    if (-not $cfg.enabled) { return @{ status = "disabled" } }

    $fi = Initialize-FileIntegrity -Config $Config
    $baseline = @{}
    $fileCount = 0

    $watchPaths = if ($cfg.watch_paths -and $cfg.watch_paths.Count -gt 0) { $cfg.watch_paths } else { @("$env:WINDIR\System32\drivers\etc\hosts", "C:\Windows\System32\drivers\etc\networks", "C:\ProgramData") }

    if ($ShowProgress) { Write-Host "  [INTEGRITY] Erstelle Baseline von $($watchPaths.Count) Pfaden..." -ForegroundColor Cyan }

    foreach ($path in $watchPaths) {
        if (-not (Test-Path $path)) { continue }
        try {
            $isDir = (Get-Item $path).PSIsContainer
            if ($isDir) {
                $files = Get-ChildItem $path -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Length -le ($cfg.max_file_size_mb * 1MB) }
                foreach ($file in $files) {
                    $hash = Get-FileHash $file.FullName -Algorithm SHA256 -ErrorAction SilentlyContinue
                    if ($hash) {
                        $relativePath = $file.FullName.Substring($path.Length).TrimStart('\')
                        $baseline["$path\$relativePath"] = @{
                            hash = $hash.Hash
                            size = $file.Length
                            last_modified = $file.LastWriteTime.ToString("o")
                            attributes = $file.Attributes.ToString()
                        }
                        $fileCount++
                    }
                }
            } else {
                $hash = Get-FileHash $path -Algorithm SHA256 -ErrorAction SilentlyContinue
                if ($hash) {
                    $item = Get-Item $path
                    $baseline[$path] = @{
                        hash = $hash.Hash
                        size = $item.Length
                        last_modified = $item.LastWriteTime.ToString("o")
                        attributes = $item.Attributes.ToString()
                    }
                    $fileCount++
                }
            }
        } catch { Write-JDSLog "WARN" "INTEGRITY: Konnte $path nicht scannen: $_" }
    }

    if ($cfg.watch_registry_keys -and $cfg.watch_registry_keys.Count -gt 0) {
        foreach ($regKey in $cfg.watch_registry_keys) {
            try {
                $regValue = Get-ItemProperty -Path $regKey -ErrorAction SilentlyContinue
                if ($regValue) {
                    $regHashInput = ($regValue | Out-String)
                    $regHash = Get-FileHash -InputStream ([System.IO.MemoryStream]::new([System.Text.Encoding]::UTF8.GetBytes($regHashInput))) -Algorithm SHA256
                    $baseline["REG:$regKey"] = @{
                        hash = $regHash.Hash
                        type = "registry"
                        last_checked = (Get-Date).ToString("o")
                    }
                    $fileCount++
                }
            } catch { }
        }
    }

    $baselineFile = Join-Path $fi.state_path "baseline_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
    $baseline | ConvertTo-Json -Depth 5 | Set-Content $baselineFile -Encoding UTF8 -Force

    $latestFile = Join-Path $fi.state_path "baseline_latest.json"
    Copy-Item $baselineFile $latestFile -Force

    if ($cfg.keep_baselines -and $cfg.keep_baselines -gt 1) {
        $allBaselines = Get-ChildItem (Join-Path $fi.state_path "baseline_*.json") | Sort-Object Name -Descending | Select-Object -Skip $cfg.keep_baselines
        foreach ($old in $allBaselines) { Remove-Item $old.FullName -Force -ErrorAction SilentlyContinue }
    }

    Write-JDSLog "INFO" "INTEGRITY: Baseline erstellt - $fileCount Eintraege"
    return @{ status = "ok"; file_count = $fileCount; baseline_file = $baselineFile }
}

function Invoke-IntegrityCheck {
    param([hashtable]$Config, [bool]$ShowProgress = $false)
    $cfg = $Config.file_integrity
    if (-not $cfg.enabled) { return @{ status = "disabled" } }

    $fi = Initialize-FileIntegrity -Config $Config
    $latestFile = Join-Path $fi.state_path "baseline_latest.json"
    if (-not (Test-Path $latestFile)) { return @{ status = "no_baseline"; message = "Keine Baseline vorhanden - zuerst Invoke-IntegrityBaseline ausfuehren" } }

    $baseline = Get-Content $latestFile -Raw -Encoding UTF8 | ConvertFrom-Json
    $changes = @()
    $newFiles = @()
    $deletedFiles = @()
    $checkedCount = 0
    $scanStart = Get-Date

    if ($ShowProgress) { Write-Host "  [INTEGRITY] Pruefe Integritaet von $($baseline.PSObject.Properties.Name.Count) Eintraegen..." -ForegroundColor Cyan }

    foreach ($entry in $baseline.PSObject.Properties) {
        $path = $entry.Name
        $record = $entry.Value
        $checkedCount++

        if ($path.StartsWith("REG:")) {
            $regPath = $path.Substring(4)
            try {
                $regValue = Get-ItemProperty -Path $regPath -ErrorAction SilentlyContinue
                if ($regValue) {
                    $regHashInput = ($regValue | Out-String)
                    $currentHash = Get-FileHash -InputStream ([System.IO.MemoryStream]::new([System.Text.Encoding]::UTF8.GetBytes($regHashInput))) -Algorithm SHA256
                    if ($currentHash.Hash -ne $record.hash) {
                        $changes += @{ path = $path; type = "registry_changed"; expected = $record.hash; actual = $currentHash.Hash; severity = "warn" }
                    }
                } else {
                    $changes += @{ path = $path; type = "registry_deleted"; severity = "warn" }
                }
            } catch { }
        } else {
            if (Test-Path $path) {
                try {
                    $currentHash = Get-FileHash $path -Algorithm SHA256 -ErrorAction SilentlyContinue
                    if ($currentHash) {
                        if ($currentHash.Hash -ne $record.hash) {
                            $severity = if ($cfg.critical_paths -and ($cfg.critical_paths | Where-Object { $path -like $_ })) { "danger" } else { "warn" }
                            $changes += @{ path = $path; type = "modified"; expected = $record.hash; actual = $currentHash.Hash; severity = $severity }
                        }
                    }
                } catch { }
            } else {
                $deletedFiles += $path
                $changes += @{ path = $path; type = "deleted"; severity = "danger" }
            }
        }
    }

    if ($cfg.detect_new_files) {
        $watchPaths = if ($cfg.watch_paths) { $cfg.watch_paths } else { @() }
        foreach ($watchPath in $watchPaths) {
            if (-not (Test-Path $watchPath)) { continue }
            try {
                $isDir = (Get-Item $watchPath).PSIsContainer
                if (-not $isDir) { continue }
                $currentFiles = Get-ChildItem $watchPath -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Length -le ($cfg.max_file_size_mb * 1MB) }
                foreach ($file in $currentFiles) {
                    if (-not $baseline.PSObject.Properties.Name.Contains($file.FullName)) {
                        $newFiles += $file.FullName
                        $changes += @{ path = $file.FullName; type = "new"; size = $file.Length; severity = "info" }
                    }
                }
            } catch { }
        }
    }

    $alertCount = ($changes | Where-Object { $_.severity -eq "danger" }).Count
    $warnCount = ($changes | Where-Object { $_.severity -eq "warn" }).Count

    $overallStatus = if ($alertCount -gt 0) { "danger" } elseif ($warnCount -gt 0) { "warn" } else { "safe" }

    $logLevel = if ($overallStatus -eq "danger") { "ERROR" } elseif ($overallStatus -eq "warn") { "WARN" } else { "INFO" }
    Write-JDSLog $logLevel "INTEGRITY: $checkedCount geprueft, $($changes.Count) Aenderungen ($alertCount kritisch, $warnCount Warnungen)"

    if ($changes.Count -gt 0) {
        $changeDetail = ($changes | ForEach-Object { "$($_.type): $($_.path)" }) -join "; "
        $alert = @{ type = if ($alertCount -gt 0) { "Critical" } else { "Warning" }; title = "Integritaetsverletzung"; message = "$($changes.Count) Aenderungen erkannt: $changeDetail" }
        if ($cfg.alert_on_change -and $changes.Count -gt 0) { Send-JDSAlert $Config $alert }

        if ($cfg.auto_remediate -and $alertCount -gt 0) {
            Write-JDSLog "WARN" "INTEGRITY: Automatische Wiederherstellung wird durchgefuehrt"
            try {
                $latestGoodBackup = Get-ChildItem (Join-Path $fi.state_path "baseline_*.json") | Sort-Object LastWriteTime -Descending | Select-Object -Skip 1 | Select-Object -First 1
                if ($latestGoodBackup) {
                    Copy-Item $latestGoodBackup.FullName $latestFile -Force
                    Write-JDSLog "INFO" "INTEGRITY: Auf vorherige Baseline zurueckgesetzt: $($latestGoodBackup.Name)"
                }
            } catch { }
        }
    }

    return @{
        status = $overallStatus
        checked = $checkedCount
        changes = $changes.Count
        critical = $alertCount
        warnings = $warnCount
        new_files = $newFiles
        deleted_files = $deletedFiles
        scan_duration_sec = [Math]::Round(((Get-Date) - $scanStart).TotalSeconds, 1)
        details = $changes[0..10]
    }
}

function Invoke-IntegrityContinuous {
    param([hashtable]$Config)
    $cfg = $Config.file_integrity
    if (-not $cfg.enabled) { return }

    $interval = if ($cfg.check_interval_seconds) { $cfg.check_interval_seconds } else { 300 }

    Invoke-IntegrityBaseline -Config $Config
    Write-JDSLog "INFO" "INTEGRITY: Dauerueberwachung gestartet (Intervall: ${interval}s)"

    while ($true) {
        Start-Sleep -Seconds $interval
        $result = Invoke-IntegrityCheck -Config $Config -ShowProgress $false
        if ($result.status -eq "danger") {
            Write-JDSLog "CRITICAL" "INTEGRITY: $($result.critical) kritische Aenderungen!"
            $alert = @{ type = "Critical"; title = "Kritische Integritaetsverletzung"; message = "$($result.critical) kritische Dateiaenderungen erkannt" }
            Send-JDSAlert $Config $alert
        }
    }
}
