﻿function Invoke-FirewallHardening {
    param([hashtable]$Config)

    $fw = $Config.firewall
    if (-not $fw.enabled) { Write-JDSLog "WARN" "Firewall module is disabled"; return }

    Write-JDSLog "INFO" "Starting firewall hardening..."

    $profiles = @("Domain", "Private", "Public")

    try {
        foreach ($profile in $profiles) {
            $netshProfile = $profile
            & netsh advfirewall set $netshProfile profile state on 2>&1 | Out-Null
            & netsh advfirewall set $netshProfile profile firewallpolicy blockinbound,allowoutbound 2>&1 | Out-Null

            if (-not $fw.allow_ping) {
                & netsh advfirewall firewall add rule name="JDS-Block-Ping-$profile" protocol=icmpv4:8,any dir=in action=block profile=$profile 2>&1 | Out-Null
            }

            & netsh advfirewall set $netshProfile profile settings inboundusernotification disable 2>&1 | Out-Null
            & netsh advfirewall set $netshProfile profile settings unicastresponsetomulticast disable 2>&1 | Out-Null
        }

        Set-NetFirewallProfile -DefaultInboundAction Block -DefaultOutboundAction Allow -ErrorAction SilentlyContinue

        if ($fw.change_default_rdp_port -and $fw.custom_rdp_port -ne 3389) {
            Write-JDSLog "INFO" "Changing RDP port to $($fw.custom_rdp_port)..."
            try {
                $rdpPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
                Set-ItemProperty -Path $rdpPath -Name "PortNumber" -Value $fw.custom_rdp_port -Type DWord -Force

                New-NetFirewallRule -DisplayName "JDS-RDP-Custom" -Direction Inbound -Protocol TCP -LocalPort $fw.custom_rdp_port -Action Allow -Profile Any | Out-Null
                Disable-NetFirewallRule -DisplayGroup "Remote Desktop" -ErrorAction SilentlyContinue
            } catch {
                Write-JDSLog "ERROR" "Failed to change RDP port: $_"
            }
        }

        if ($fw.allowed_ports.Count -gt 0) {
            foreach ($port in $fw.allowed_ports) {
                $existing = Get-NetFirewallRule -DisplayName "JDS-Allow-Port-$port" -ErrorAction SilentlyContinue
                if (-not $existing) {
                    New-NetFirewallRule -DisplayName "JDS-Allow-Port-$port" -Direction Inbound -Protocol TCP -LocalPort $port -Action Allow -Profile Any | Out-Null
                }
            }
        }

        if ($fw.block_bruteforce -and $fw.block_inbound) {
            try {
                $rdpPort = if ($fw.change_default_rdp_port) { $fw.custom_rdp_port } else { 3389 }
                $threshold = $fw.bruteforce_threshold
                $window = $fw.bruteforce_window_minutes

                $filterName = "JDS-BruteForce-Protection"
                $filterExisting = Get-NetFirewallRule -DisplayName $filterName -ErrorAction SilentlyContinue
                if (-not $filterExisting) {
                    New-NetFirewallRule -DisplayName $filterName -Direction Inbound -Protocol TCP -LocalPort $rdpPort -Action Block -RemoteAddress "Any" -Profile Any -Description "Brute-Force protection for RDP" | Out-Null
                }
            } catch {
                Write-JDSLog "ERROR" "Failed to setup brute-force protection: $_"
            }
        }

        if ($fw.allowed_ips_rdp.Count -gt 0) {
            $rdpPort = if ($fw.change_default_rdp_port) { $fw.custom_rdp_port } else { 3389 }
            New-NetFirewallRule -DisplayName "JDS-RDP-Whitelist" -Direction Inbound -Protocol TCP -LocalPort $rdpPort -Action Allow -RemoteAddress $fw.allowed_ips_rdp -Profile Any | Out-Null
        }

        if ($fw.log_all_connections) {
            & netsh advfirewall set allprofiles logging filename "$PSScriptRoot\..\logs\firewall.log" 2>&1 | Out-Null
            & netsh advfirewall set allprofiles logging droppedconnections enable 2>&1 | Out-Null
            & netsh advfirewall set allprofiles logging allowedconnections enable 2>&1 | Out-Null
        }

        Write-JDSLog "INFO" "Firewall hardening completed successfully"

        $alerts = @{
            type = "Info"
            title = "Firewall gehartet"
            message = "Windows Firewall wurde erfolgreich konfiguriert"
        }
        Send-JDSAlert $Config $alerts

    } catch {
        Write-JDSLog "ERROR" "Firewall hardening failed: $_"
        throw
    }
}

function Invoke-FirewallScan {
    param([hashtable]$Config)

    $openPorts = @()
    try {
        $rules = Get-NetFirewallRule -Direction Inbound -Enabled True -Action Allow | Where-Object { $_.Profile -ne "Public" -or $_.Direction -eq "Inbound" }

        foreach ($rule in $rules) {
            $portFilter = $rule | Get-NetFirewallPortFilter -ErrorAction SilentlyContinue
            if ($portFilter -and $portFilter.LocalPort) {
                $ports = @($portFilter.LocalPort)
                foreach ($p in $ports) {
                    if ($p -notin $Config.firewall.allowed_ports) {
                        $openPorts += [PSCustomObject]@{
                            RuleName = $rule.DisplayName
                            Port = $p
                            Protocol = $portFilter.Protocol
                        }
                    }
                }
            }
        }

        $listeningPorts = netstat -an | Select-String "LISTENING"
        foreach ($line in $listeningPorts) {
            if ($line -match "TCP\s+0\.0\.0\.0:(\d+)") {
                $portNum = [int]$Matches[1]
                $serviceName = (Get-Process -Id (Get-NetTCPConnection -LocalPort $portNum -ErrorAction SilentlyContinue).OwningProcess -ErrorAction SilentlyContinue).ProcessName
                if ($portNum -notin $Config.firewall.allowed_ports -and $portNum -gt 1024 -and $portNum -notin @(135, 139, 445, 5985, 5986)) {
                    Write-JDSLog "WARN" "Unerwarteter offener Port gefunden: $portNum ($serviceName)"
                }
            }
        }

        if ($openPorts.Count -gt 0) {
            Write-JDSLog "WARN" "Ungewohnliche offene Ports erkannt: $($openPorts.Count) Regel(n)"
            Write-Host ">>> $($openPorts.Count) ungewohnliche offene Ports gefunden (Details in der Logdatei)"
            # Nur die ersten 5 auffaelligen Regeln ausgeben
            $openPorts | Select-Object -First 5 | ForEach-Object {
                Write-Host "    $($_.RuleName) -> Port $($_.Port)/$($_.Protocol)"
            }
            if ($openPorts.Count -gt 5) { Write-Host "    ... und $($openPorts.Count - 5) weitere" }
            $alerts = @{
                type = "Warning"
                title = "Offene Ports erkannt"
                message = "Es wurden $($openPorts.Count) ungewohnliche offene Ports gefunden"
            }
            Send-JDSAlert $Config $alerts
        } else {
            Write-Host ">>> Keine ungewohnlichen offenen Ports gefunden."
        }

        return @{ total_unusual_rules = $openPorts.Count; status = if ($openPorts.Count -gt 0) { "warn" } else { "ok" } }
    } catch {
        Write-JDSLog "ERROR" "Firewall scan failed: $_"
        return @{ total_unusual_rules = 0; status = "error"; error = "$_" }
    }
}

function Invoke-FirewallReset {
    try {
        & netsh advfirewall reset 2>&1 | Out-Null
        Write-JDSLog "INFO" "Firewall rules have been reset to defaults"
        return $true
    } catch {
        Write-JDSLog "ERROR" "Failed to reset firewall: $_"
        return $false
    }
}


