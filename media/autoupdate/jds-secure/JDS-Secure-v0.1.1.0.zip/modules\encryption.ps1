﻿function Invoke-DataEncryption {
    param([hashtable]$Config)

    $enc = $Config.encryption
    if (-not $enc.enabled) { Write-JDSLog "WARN" "Encryption module is disabled"; return }

    Write-JDSLog "INFO" "Starting data encryption..."

    try {
        if ($enc.bitlocker_enabled) {
            $bitlockerDrives = Get-BitLockerVolume -ErrorAction SilentlyContinue
            $systemDrive = (Get-CimInstance Win32_OperatingSystem).SystemDrive

            if (-not $bitlockerDrives -or $bitlockerDrives.Count -eq 0) {
                Write-JDSLog "INFO" "BitLocker not active on any drives"
            } else {
                foreach ($drive in $bitlockerDrives) {
                    if ($drive.ProtectionStatus -eq 0) {
                        Write-JDSLog "WARN" "BitLocker deaktiviert auf $($drive.MountPoint) - aktivieren..."
                        try {
                            Enable-BitLocker -MountPoint $drive.MountPoint -RecoveryPasswordProtector -SkipHardwareTest -ErrorAction SilentlyContinue
                            Write-JDSLog "INFO" "BitLocker aktiviert auf $($drive.MountPoint)"
                        } catch {
                            Write-JDSLog "ERROR" "BitLocker Aktivierung fehlgeschlagen auf $($drive.MountPoint): $_"
                        }
                    }
                }
            }
        }

        $paths = $enc.auto_encrypt_paths
        foreach ($path in $paths) {
            if (-not (Test-Path $path)) {
                try {
                    New-Item -ItemType Directory -Path $path -Force | Out-Null
                    Write-JDSLog "INFO" "Created directory: $path"
                } catch {
                    Write-JDSLog "WARN" "Could not create directory $path"
                    continue
                }
            }

            Set-AclEncryption -Path $path
        }

        if ($enc.efs_enabled) {
            $efsKey = Get-CimInstance -Namespace "root\CIMv2\Security\MicrosoftVolumeEncryption" -ClassName "Win32_EncryptableVolume" -ErrorAction SilentlyContinue
            Write-JDSLog "INFO" "EFS (Encrypting File System) is available on this system"
        }

        Write-JDSLog "INFO" "File encryption protection applied to configured paths"

        $alerts = @{
            type = "Info"
            title = "Verschluesselung aktiv"
            message = "Datenverschluesselung wurde erfolgreich angewendet"
        }
        Send-JDSAlert $Config $alerts

    } catch {
        Write-JDSLog "ERROR" "Data encryption failed: $_"
        throw
    }
}

function Set-AclEncryption {
    param([string]$Path)

    try {
        $acl = Get-Acl -Path $Path -ErrorAction SilentlyContinue
        if (-not $acl) { return }

        # Wohlbekannte SIDs statt lokalisierter Kontonamen (z.B. "Administratoren")
        # verwenden - Namen wie "BUILTIN\Administratoren" scheitern an der
        # Uebersetzung, sobald Sprache/Konfiguration des Systems abweicht.
        # SIDs sind sprachunabhaengig und funktionieren immer.
        $builtinAdmins = New-Object System.Security.Principal.SecurityIdentifier([System.Security.Principal.WellKnownSidType]::BuiltinAdministratorsSid, $null)
        $system = New-Object System.Security.Principal.SecurityIdentifier([System.Security.Principal.WellKnownSidType]::LocalSystemSid, $null)
        $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().User

        $accessRuleAdmins = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $builtinAdmins, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow"
        )
        $accessRuleSystem = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $system, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow"
        )

        $acl.SetAccessRule($accessRuleAdmins)
        $acl.SetAccessRule($accessRuleSystem)

        $acl.SetAccessRuleProtection($true, $false)

        Set-Acl -Path $Path -AclObject $acl -ErrorAction SilentlyContinue

        $subItems = Get-ChildItem -Path $Path -Recurse -ErrorAction SilentlyContinue
        foreach ($item in $subItems) {
            try {
                $itemAcl = Get-Acl -Path $item.FullName -ErrorAction SilentlyContinue
                if ($itemAcl) {
                    $itemAcl.SetAccessRule($accessRuleAdmins)
                    $itemAcl.SetAccessRule($accessRuleSystem)
                    $itemAcl.SetAccessRuleProtection($true, $false)
                    Set-Acl -Path $item.FullName -AclObject $itemAcl -ErrorAction SilentlyContinue
                }
            } catch {}
        }

        Write-JDSLog "INFO" "ACL protection applied to: $Path"
    } catch {
        Write-JDSLog "WARN" "Failed to set ACL on $Path`: $_"
    }
}

function Protect-File {
    param(
        [string]$FilePath,
        [SecureString]$Password = $null
    )

    if (-not (Test-Path $FilePath)) {
        Write-JDSLog "ERROR" "File not found: $FilePath"
        return $false
    }

    try {
        if (-not $Password) {
            $aes = [System.Security.Cryptography.Aes]::Create()
            $aes.KeySize = 256
            $aes.GenerateKey()
            $aes.GenerateIV()

            $key = [Convert]::ToBase64String($aes.Key)
            $iv = [Convert]::ToBase64String($aes.IV)
            $keyPath = "$FilePath.key"
            $keyData = "Key: $key`nIV: $iv`nAlgorithm: AES-256`nCreated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
            Set-Content -Path $keyPath -Value $keyData -Force
            Write-JDSLog "INFO" "Encryption key saved to: $keyPath"
        }

        $content = [System.IO.File]::ReadAllBytes($FilePath)
        $encrypted = [System.Security.Cryptography.ProtectedData]::Protect($content, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
        $encryptedPath = "$FilePath.jdsenc"
        [System.IO.File]::WriteAllBytes($encryptedPath, $encrypted)

        Write-JDSLog "INFO" "File encrypted: $FilePath -> $encryptedPath"
        return $true
    } catch {
        Write-JDSLog "ERROR" "Encryption failed for $FilePath`: $_"
        return $false
    }
}

function Unprotect-File {
    param(
        [string]$EncryptedPath,
        [string]$OutputPath = $null
    )

    if (-not (Test-Path $EncryptedPath)) {
        Write-JDSLog "ERROR" "Encrypted file not found: $EncryptedPath"
        return $false
    }

    try {
        $encrypted = [System.IO.File]::ReadAllBytes($EncryptedPath)
        $decrypted = [System.Security.Cryptography.ProtectedData]::Unprotect($encrypted, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)

        if (-not $OutputPath) {
            $OutputPath = $EncryptedPath -replace '\.jdsenc$', '.decrypted'
            if ($OutputPath -eq $EncryptedPath) { $OutputPath = "$EncryptedPath.decrypted" }
        }

        [System.IO.File]::WriteAllBytes($OutputPath, $decrypted)
        Write-JDSLog "INFO" "File decrypted: $EncryptedPath -> $OutputPath"
        return $true
    } catch {
        Write-JDSLog "ERROR" "Decryption failed for $EncryptedPath`: $_"
        return $false
    }
}

function Invoke-SecureDelete {
    param(
        [string]$Path,
        [int]$Passes = 3
    )

    if (-not (Test-Path $Path)) {
        Write-JDSLog "ERROR" "Path not found: $Path"
        return $false
    }

    Write-JDSLog "WARN" "Secure deleting: $Path with $Passes passes"

    try {
        $isDirectory = (Get-Item $Path).PSIsContainer
        $filesToDelete = if ($isDirectory) { Get-ChildItem $Path -Recurse -File } else { Get-Item $Path }

        foreach ($file in $filesToDelete) {
            try {
                $fileInfo = [System.IO.FileInfo]$file.FullName
                if (-not $fileInfo.Exists) { continue }

                $length = $fileInfo.Length
                $stream = [System.IO.File]::Open($file.FullName, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Write)

                for ($pass = 0; $pass -lt $Passes; $pass++) {
                    $random = [System.Security.Cryptography.RandomNumberGenerator]::Create()
                    $buffer = [byte[]]::new([Math]::Min($length, 4096))
                    $totalWritten = 0

                    while ($totalWritten -lt $length) {
                        $random.GetBytes($buffer)
                        $writeSize = [Math]::Min($buffer.Length, $length - $totalWritten)
                        $stream.Write($buffer, 0, $writeSize)
                        $totalWritten += $writeSize
                    }
                    $stream.Flush()
                    $stream.Seek(0, [System.IO.SeekOrigin]::Begin) | Out-Null
                }

                $stream.Close()
                $stream.Dispose()

                [System.IO.File]::Delete($file.FullName)
                Write-JDSLog "INFO" "Securely deleted: $($file.FullName)"
            } catch {
                Write-JDSLog "WARN" "Failed to secure delete $($file.FullName)`: $_"
            }
        }

        if ($isDirectory) {
            try {
                Remove-Item -Path $Path -Recurse -Force -ErrorAction SilentlyContinue
            } catch {}
        }

        return $true
    } catch {
        Write-JDSLog "ERROR" "Secure delete failed: $_"
        return $false
    }
}

function New-RSACertificate {
    param([string]$CertName = "JDS-Secure-Encryption", [int]$KeySize = 4096, [int]$ValidYears = 10, [string]$ExportPath = "")
    try {
        if (-not $ExportPath) { $ExportPath = "$env:ProgramData\JDS-Secure\certificates" }
        if (-not (Test-Path $ExportPath)) { New-Item -ItemType Directory -Path $ExportPath -Force | Out-Null }

        $cert = New-SelfSignedCertificate -Subject "CN=$CertName,O=JDS Secure,C=DE" -CertStoreLocation "Cert:\LocalMachine\My" -KeyExportPolicy Exportable -KeySpec KeyExchange -KeyLength $KeySize -NotAfter (Get-Date).AddYears($ValidYears) -KeyUsage DataEncipherment, KeyEncipherment -TextExtension @("2.5.29.37={text}1.3.6.1.4.1.311.80.1") -ErrorAction Stop

        $certPath = Join-Path $ExportPath "$CertName.cer"
        $pfxPath = Join-Path $ExportPath "$CertName.pfx"
        $password = [System.Web.Security.Membership]::GeneratePassword(24, 3) -replace '[<>]', 'J'
        $securePass = ConvertTo-SecureString $password -AsPlainText -Force

        Export-Certificate -Cert $cert -FilePath $certPath -Type CERT | Out-Null
        Export-PfxCertificate -Cert $cert -FilePath $pfxPath -Password $securePass | Out-Null

        $passPath = Join-Path $ExportPath "$CertName.pwd.txt"
        "PFX Password: $password`r`nCreated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`r`nCN: $CertName`r`nKeySize: $KeySize" | Out-File $passPath -Encoding UTF8 -Force

        Write-JDSLog "INFO" "RSA-Zertifikat erstellt: $certPath"
        return @{ cert = $cert; certPath = $certPath; pfxPath = $pfxPath; password = $password; thumbprint = $cert.Thumbprint }
    } catch {
        Write-JDSLog "ERROR" "RSA-Zertifikatserstellung fehlgeschlagen: $_"
        return $null
    }
}

function Protect-FileWithCertificate {
    param([string]$FilePath, [string]$Thumbprint)
    if (-not (Test-Path $FilePath)) { Write-JDSLog "ERROR" "Datei nicht gefunden: $FilePath"; return $false }
    try {
        $cert = Get-Item "Cert:\LocalMachine\My\$Thumbprint" -ErrorAction Stop
        $content = [System.IO.File]::ReadAllBytes($FilePath)
        $encrypted = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPublicKey($cert).Encrypt($content, [System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA256)
        $encPath = "$FilePath.rsaenc"
        [System.IO.File]::WriteAllBytes($encPath, $encrypted)
        Write-JDSLog "INFO" "RSA-verschluesselt: $encPath"
        return $true
    } catch {
        Write-JDSLog "ERROR" "RSA-Verschluesselung fehlgeschlagen: $_"
        return $false
    }
}

function Unprotect-FileWithCertificate {
    param([string]$EncryptedPath, [string]$Thumbprint, [string]$OutputPath)
    if (-not (Test-Path $EncryptedPath)) { Write-JDSLog "ERROR" "Verschluesselte Datei nicht gefunden: $EncryptedPath"; return $false }
    try {
        $cert = Get-Item "Cert:\LocalMachine\My\$Thumbprint" -ErrorAction Stop
        $encrypted = [System.IO.File]::ReadAllBytes($EncryptedPath)
        $decrypted = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($cert).Decrypt($encrypted, [System.Security.Cryptography.RSAEncryptionPadding]::OaepSHA256)
        if (-not $OutputPath) { $OutputPath = $EncryptedPath -replace '\.rsaenc$', '.decrypted' }
        [System.IO.File]::WriteAllBytes($OutputPath, $decrypted)
        Write-JDSLog "INFO" "RSA-entschluesselt: $OutputPath"
        return $true
    } catch {
        Write-JDSLog "ERROR" "RSA-Entschluesselung fehlgeschlagen: $_"
        return $false
    }
}

function Protect-String {
    param([string]$PlainText, [string]$Passphrase = "")
    try {
        if ([string]::IsNullOrEmpty($Passphrase)) { $Passphrase = [System.Web.Security.Membership]::GeneratePassword(32, 5) -replace '[<>]', 'J' }
        $salt = [System.Text.Encoding]::UTF8.GetBytes("JDS-Secure-Salt-2024")
        $derive = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($Passphrase, $salt, 100000, [System.Security.Cryptography.HashAlgorithmName]::SHA512)
        $aes = [System.Security.Cryptography.Aes]::Create()
        $aes.Key = $derive.GetBytes(32)
        $aes.IV = $derive.GetBytes(16)
        $encryptor = $aes.CreateEncryptor()
        $input = [System.Text.Encoding]::UTF8.GetBytes($PlainText)
        $output = $encryptor.TransformFinalBlock($input, 0, $input.Length)
        $result = [Convert]::ToBase64String($aes.IV + $output)
        return @{ encrypted = $result; passphrase = $Passphrase; algorithm = "AES-256-PBKDF2" }
    } catch {
        Write-JDSLog "ERROR" "String-Verschluesselung fehlgeschlagen: $_"
        return $null
    }
}

function Unprotect-String {
    param([string]$EncryptedBase64, [string]$Passphrase)
    try {
        $data = [Convert]::FromBase64String($EncryptedBase64)
        $salt = [System.Text.Encoding]::UTF8.GetBytes("JDS-Secure-Salt-2024")
        $iv = $data[0..15]
        $cipherText = $data[16..($data.Length - 1)]
        $derive = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($Passphrase, $salt, 100000, [System.Security.Cryptography.HashAlgorithmName]::SHA512)
        $aes = [System.Security.Cryptography.Aes]::Create()
        $aes.Key = $derive.GetBytes(32)
        $aes.IV = $iv
        $decryptor = $aes.CreateDecryptor()
        $output = $decryptor.TransformFinalBlock($cipherText, 0, $cipherText.Length)
        return [System.Text.Encoding]::UTF8.GetString($output)
    } catch {
        Write-JDSLog "ERROR" "String-Entschluesselung fehlgeschlagen: $_"
        return $null
    }
}

function Invoke-DiskEncryptionCheck {
    param([bool]$ShowProgress = $false)
    if ($ShowProgress) { Write-Host "  [ENCRYPTION] Pruefe Laufwerksverschluesselung..." -ForegroundColor Cyan }
    $results = @()
    try {
        $volumes = Get-BitLockerVolume -ErrorAction SilentlyContinue
        $drives = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Root -match '^[A-Z]:\\$' }
        foreach ($drive in $drives) {
            $root = $drive.Root.TrimEnd('\')
            $vol = $volumes | Where-Object { $_.MountPoint -eq $root }
            $bitlockerStatus = if ($vol -and $vol.ProtectionStatus -eq 1) { "aktiv" } elseif ($vol) { "ungeschuetzt" } else { "nicht_verschluesselt" }
            $results += @{ drive = $root; label = $drive.Name; bitlocker = $bitlockerStatus; protection = if ($bitlockerStatus -eq "aktiv") { "safe" } else { "warn" }; efs_capable = $false }
        }
    } catch { }
    return $results
}

function Set-EnhancedACL {
    param([string]$Path, [string[]]$AdditionalUsers = @())
    if (-not (Test-Path $Path)) { return }
    try {
        $acl = Get-Acl $Path -ErrorAction SilentlyContinue
        if (-not $acl) { return }
        $acl.SetAccessRuleProtection($true, $false)
        # Wohlbekannte SIDs statt lokalisierter Kontonamen - siehe Set-AclEncryption weiter oben.
        $builtinAdmins = New-Object System.Security.Principal.SecurityIdentifier([System.Security.Principal.WellKnownSidType]::BuiltinAdministratorsSid, $null)
        $system = New-Object System.Security.Principal.SecurityIdentifier([System.Security.Principal.WellKnownSidType]::LocalSystemSid, $null)
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($builtinAdmins, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")))
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($system, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")))
        $everyone = New-Object System.Security.Principal.SecurityIdentifier([System.Security.Principal.WellKnownSidType]::BuiltinUsersSid, $null)
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($everyone, "ReadAndExecute", "ContainerInherit,ObjectInherit", "None", "Allow")))
        foreach ($user in $AdditionalUsers) {
            $account = New-Object System.Security.Principal.NTAccount($user)
            $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($account, "Modify", "ContainerInherit,ObjectInherit", "None", "Allow")))
        }
        Set-Acl $Path $acl -ErrorAction SilentlyContinue
        if ((Get-Item $Path).PSIsContainer) {
            Get-ChildItem $Path -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
                try { Set-Acl $_.FullName $acl -ErrorAction SilentlyContinue } catch { }
            }
        }
    } catch { Write-JDSLog "WARN" "Enhanced-ACL fehlgeschlagen fuer $Path`: $_" }
}


