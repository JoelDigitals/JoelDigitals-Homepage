# JDS Secure - Installationsanleitung

**Version 2.0 | Stand: Juni 2026**

---

## 1. Einleitung

Diese Anleitung beschreibt die Installation von JDS Secure auf einem Windows-Server oder Arbeitsplatzrechner. Das System kann wahlweise portabel vom USB-Stick oder als fest installierter Windows-Dienst betrieben werden.

### Zielgruppe

- Systemadministratoren
- IT-Verantwortliche in KMU
- Server-Administratoren

### Sicherheitshinweis

Fuhren Sie die Installation mit administrativen Rechten durch. Der Dienst lauft im System-Kontext und hat Zugriff auf sicherheitsrelevante Funktionen.

---

## 2. Systemvoraussetzungen

### Hardware
- **CPU:** 1 GHz oder schneller (x64)
- **RAM:** Mindestens 1 GB frei (empfohlen: 2 GB)
- **Festplatte:** 100 MB frei fur die Installation, zusatzlich Speicher fur Backups
- **USB-Stick:** Mindestens 500 MB (empfohlen: 2 GB)

### Software
- **Betriebssystem:**
  - Windows 10/11 (Pro, Enterprise, Education)
  - Windows Server 2016/2019/2022 (Standard, Datacenter)
  - Windows Server Essentials/Foundation
- **PowerShell:** Version 5.1 oder hoher
- **.NET Framework:** 4.7.2 oder hoher (in Windows enthalten)

### Berechtigungen
- **Lokale Administratorrechte** fur Installation
- Fur Dienst-Installation: `Administrator` oder `SYSTEM`
- Fur BitLocker: `Administrator` mit TPM-Verfugbarkeit

---

## 3. Installationsvarianten

### 3.1 Portable Installation (USB-Stick)

**Geeignet fur:**
- Mobile IT-Sicherheitsaudits
- Schnelle Einsatze vor Ort
- Test- und Evaluierungszwecke

**Schritte:**

```powershell
# 1. Projektordner offnen
cd "C:\Users\Joel\Desktop\Joel Digitals\Programming\jds-secure"

# 2. USB-Stick einstecken (z.B. Laufwerk E:)
# 3. Deployment ausfuhren
.\deploy-to-usb.ps1 -DriveLetter E -EncryptDrive

# 4. USB-Stick sicher entnehmen
# 5. Auf dem Zielsystem: USB einstecken und ausfuhren
#    E:\JDS-Secure\jds-secure.ps1
```

**Vorteile:** Keine Installation erforderlich, portabel, hinterlasst keine Spuren  
**Nachteile:** Nicht als Dienst verfugbar, manueller Start notwendig

### 3.2 Server-Installation (Empfohlen)

**Geeignet fur:**
- Produktiver Einsatz auf Servern
- Dauerhafter Schutz von Kundendaten
- Automatisierter Hintergrundbetrieb

**Schritte:**

```powershell
# 1. Projektordner offnen
cd "C:\Users\Joel\Desktop\Joel Digitals\Programming\jds-secure"

# 2. Setup starten (interaktiv)
.\setup.ps1

# 3. Oder automatische Installation:
.\setup.ps1 -Mode Server -Auto

# 4. Nach Installation: Dienststatus prufen
Get-Service -Name JDSSecure
```

**Was wird installiert:**

| Komponente | Beschreibung |
|------------|-------------|
| Windows-Dienst `JDSSecure` | Dauerhafter Hintergrundbetrieb |
| Task `JDS-Secure-Scan` | Sicherheitsscan (stundlich) |
| Task `JDS-Secure-Backup` | Backup (taglich 02:00) |
| Task `JDS-Secure-Cleanup` | Bereinigung (wochentlich) |
| Event Log `JDS-Secure` | Zentrale Logging-Quelle |

**Installationsverzeichnisse:**
- Programm: `C:\Program Files\JDS-Secure`
- Daten: `C:\ProgramData\JDS-Secure`
- Logs: `C:\ProgramData\JDS-Secure\logs`

### 3.3 Benutzerdefinierte Installation

```powershell
# Nur bestimmte Komponenten installieren
.\setup.ps1 -Mode Custom -Components Firewall,Backup,IDS

# Installation mit benutzerdefiniertem Pfad
.\setup.ps1 -Mode Custom -Path "D:\Security\JDS"
```

---

## 4. Setup-Assistent (Interaktiv)

Der Setup-Assistent fuhrt Schritt fur Schritt durch die Installation:

```
╔══════════════════════════════════════════════════════════════╗
║           JDS Secure - Installations-Assistent               ║
╠══════════════════════════════════════════════════════════════╣
║                                                            ║
║  [1]  Schnell-Installation (Server) - Empfohlen             ║
║       Installiert JDS Secure als Windows-Dienst mit         ║
║       automatischen Tasks.                                  ║
║                                                            ║
║  [2]  Portable Installation (USB-Stick)                     ║
║       Kopiert JDS Secure auf einen USB-Stick.               ║
║                                                            ║
║  [3]  Benutzerdefinierte Installation                       ║
║       Individuelle Auswahl der Komponenten.                 ║
║                                                            ║
║  [4]  Deinstallation                                          ║
║       Entfernt JDS Secure vollstandig vom System.           ║
║                                                            ║
║  [0]  Beenden                                                ║
║                                                            ║
╚══════════════════════════════════════════════════════════════╝
```

---

## 5. Konfiguration nach der Installation

### 5.1 Backup-Ziel festlegen

Standardziel ist `D:\JDS-Backup`. Zum Andern:

```powershell
# Im GUI: Tab "Backup" -> Ziel auswahlen
# Oder direkt in der config:
notepad .\config\security-config.json
# "backup.destinations.primary.path" andern
```

**Empfohlene Backup-Strategie:**

| Daten | Ziel | Rhythmus |
|-------|------|----------|
| Kundendaten (C:\CustomerData) | Externe Platte D: | Taglich 02:00 |
| Geschaftsdaten (C:\BusinessData) | Externe Platte D: | Taglich 02:00 |
| SQL-Datenbanken | Externe Platte D: | Taglich 03:00 |
| Voll-Backup (wochentlich) | Netzwerk/NAS | Sonntags 04:00 |

### 5.2 Backup-Aufbewahrung (Rotation)

Die Rotation ist standardmassig aktiviert:

| Intervall | Aufbewahrung |
|-----------|-------------|
| Tagliche Backups | 7 Tage |
| Wochenliche Backups | 4 Wochen |
| Monatliche Backups | 3 Monate |
| Jahrliche Backups | 1 Jahr |

### 5.3 E-Mail-Benachrichtigungen

```json
"audit": {
    "send_email_alerts": true,
    "smtp_server": "mail.ihrfirma.de",
    "smtp_port": 587,
    "smtp_user": "jds-secure@ihrfirma.de",
    "smtp_password": "ihr-passwort",
    "alert_recipients": ["admin@ihrfirma.de"]
}
```

---

## 6. Dienst-Verwaltung

### Status prufen

```powershell
Get-Service JDSSecure
Get-ScheduledTask -TaskName "JDS-Secure-*"
```

### Dienst manuell steuern

```powershell
Stop-Service JDSSecure
Start-Service JDSSecure
Restart-Service JDSSecure
```

### Dienst-Logs anzeigen

```powershell
# Event Log
Get-WinEvent -LogName "JDS-Secure" -MaxEvents 50

# Service-Log
Get-Content "C:\Program Files\JDS-Secure\logs\service.log" -Tail 20
```

---

## 7. Deinstallation

```powershell
# Option 1: Uninstall-Skript
.\uninstall.ps1

# Option 2: Manuell
Stop-Service JDSSecure -Force
sc.exe delete JDSSecure
Unregister-ScheduledTask -TaskName "JDS-Secure-*" -Confirm:$false
Remove-Item "C:\Program Files\JDS-Secure" -Recurse -Force
Remove-Item "C:\ProgramData\JDS-Secure" -Recurse -Force
```

---

## 8. Fehlerbehebung

### Problem: Dienst startet nicht

```powershell
# Log prufen
Get-Content "C:\Program Files\JDS-Secure\logs\service.log" -Tail 20

# Execution Policy prufen
Get-ExecutionPolicy -List

# Manuell testen
powershell -ExecutionPolicy Bypass -File "C:\Program Files\JDS-Secure\tools\jds-service.ps1"
```

### Problem: Backup schlagt fehl

```powershell
# Backup-Log prufen
Get-Content "C:\Program Files\JDS-Secure\logs\jds-audit.log" | Select-String "Backup"

# Zielverfugbarkeit prufen
Test-Path "D:\JDS-Backup"

# Speicherplatz prufen
Get-PSDrive D | Select-Object Used, Free
```

### Problem: Firewall-Regeln werden nicht gesetzt

```powershell
# Als Administrator ausfuhren
.\jds-secure.ps1 -Mode Interactive
# Dann Option 2 -> 1 (Firewall-Hartung)
```

---

## 9. Sicherheitshinweise

1. **Backup-Ziel regelmassig prufen:** Stellen Sie sicher, dass genug Speicherplatz verfugbar ist
2. **Log-Dateien uberwachen:** Kontrollieren Sie regelmasig die Audit-Logs
3. **Updates durchfuhren:** Halten Sie JDS Secure aktuell
4. **Zugriffsrechte:** Der Dienst lauft mit SYSTEM-Rechten - Zugriff einschranken
5. **Netzwerkfreigaben:** Bei Netzwerk-Backups verschlusselte Verbindungen nutzen (SMB 3.0+)
6. **Recovery-Key sichern:** Bei BitLocker-Verschlusselung den Recovery-Key sicher aufbewahren

---

## 10. Quick-Reference

```powershell
# === Schnellbefehle ===
# GUI starten
.\jds-secure.ps1

# Als Dienst installieren
.\setup.ps1 -Mode Server -Auto

# Backup manuell starten
.\jds-secure.ps1 -Mode Backup

# Vollstandigen Scan ausfuhren
.\jds-secure.ps1 -Mode QuickScan

# Sicherheitsbericht erstellen
.\jds-secure.ps1 -Mode Report

# Logs anzeigen
Get-Content .\logs\jds-audit.log -Tail 50
```
