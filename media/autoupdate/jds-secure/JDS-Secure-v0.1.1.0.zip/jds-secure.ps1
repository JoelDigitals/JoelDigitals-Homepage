﻿#!/usr/bin/env pwsh
<#
.SYNOPSIS
    JDS Secure by Joel Digitals - v0.1.0
    Umfassendes Sicherheitssystem fuer KMU (Laufend vom USB-Stick)

.DESCRIPTION
    JDS Secure ist ein modulares Sicherheitssystem fuer kleine und
    mittelstaendische Unternehmen. Es laeuft portabel vom USB-Stick
    und schuetzt Kundendaten und Serversysteme durch:
    - Firewall-Haertung & Netzwerkschutz
    - Intrusion Detection System (IDS)
    - Datenverschluesselung (AES-256, BitLocker, EFS)
    - Automatisierte Backups mit Verschluesselung
    - Honeypot-System zur Angriffserkennung
    - Audit-Logging & Monitoring
    - USB-Sicherheitsrichtlinien
    - Brute-Force-Schutz

.PARAMETER Mode
    Startmodus: "GUI" (Standard - Empfohlen), "Interactive" (Konsole), "Service" (Hintergrund), "QuickScan"

.PARAMETER ConfigPath
    Pfad zur Konfigurationsdatei (Standard: config/security-config.json)

.EXAMPLE
    .\jds-secure.ps1 -Mode Interactive
    Startet das Sicherheitssystem im interaktiven Modus

.EXAMPLE
    .\jds-secure.ps1 -Mode Service
    Startet das Sicherheitssystem als Hintergrunddienst
#>
# =============================================================================
# RECHTLICHER HINWEIS / LEGAL DISCLAIMER
# =============================================================================
# JDS Secure wird als "as-is" Sicherheitssystem bereitgestellt. Die Nutzung
# erfolgt auf eigene Verantwortung. Der Entwickler uebernimmt keine Haftung fuer
# Schaeden, die durch Nutzung, Fehlkonfiguration oder Ausfall entstehen.
#
# HAFTUNGSAUSSCHLUSS / LIMITATION OF LIABILITY:
# - Dieses System unterstuetzt bei der Einhaltung von Sicherheitsstandards und
#   DSGVO-Anforderungen, ersetzt jedoch keine rechtsverbindliche Pruefung durch
#   einen Datenschutzbeauftragten oder eine Rechtsberatung.
# - Der Entwickler haftet nicht fuer indirekte, direkte oder Folgeschaeden.
# - Es besteht kein Anspruch auf Support, Aktualisierungen oder Fehlerfreiheit.
# - Vor produktivem Einsatz ist eine umfassende Pruefung durch Fachpersonal
#   erforderlich.
#
# LIABILITY DISCLAIMER (English):
# This software is provided "as is" without warranty of any kind. The author
# shall not be held liable for any damages arising from its use. This tool
# assists with security and GDPR compliance but does not constitute legal
# advice. Professional consultation with a data protection officer and legal
# counsel is required before production use.
# =============================================================================


[CmdletBinding()]
param(
    [Parameter(Position=0)]
    [ValidateSet("GUI", "Interactive", "Service", "QuickScan", "Backup", "Cleanup", "Report", "FullScan", "VirusScan", "Ransomware", "Vulnerability", "Firewall", "IDS", "Network", "Process", "Integrity", "Encryption", "Honeypot", "USB", "SelfDefense", "Audit", "Quarantine", "Incident", "GDPR")]
    [string]$Mode = "GUI",

    [string]$ConfigPath = "",

    [switch]$NoGUI
)

$script:JDSVersion = "0.1.0"
$script:StartTime = Get-Date
$script:ScriptPath = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }

#region Initialisierung
function Initialize-JDSSecure {
    param([string]$Mode = "GUI")
    Write-Host @"

    ==================================================================
              JDS SECURE - Enterprise Security Suite
                    Version $script:JDSVersion
          Sicherheitssystem fuer kleine & mittlere Unternehmen
    ==================================================================

"@ -ForegroundColor Cyan

    $config = Load-JDSConfig

    $manifestPath = Join-Path $config.general.install_path "config\module-manifest.json"
    if (-not (Test-Path $manifestPath) -and $config.security_hardening.verify_modules) {
        Write-Host "  [HARDENING] Erstelle Modul-Integritaets-Manifest..." -ForegroundColor Cyan
        $null = New-JDSModuleManifest -Config $config
    }

    if ($config.security_hardening.enabled -and $config.security_hardening.encrypt_config) {
        $config = Unprotect-JDSConfigSensitive -Config $config
    }

    if ($config.security_hardening.verify_modules -and (Test-Path $manifestPath)) {
        $integrity = Test-JDSModuleIntegrity -Config $config
        if ($integrity.tampered -gt 0) {
            Write-Host "  [WARN] $($integrity.tampered) Module manipuliert! Lade nur intakte Module." -ForegroundColor Yellow
            foreach ($t in $integrity.tampered_details) {
                Write-Host "    [MANIPULIERT] $($t.file)" -ForegroundColor Red
            }
        }
    }

    if ($Mode -eq "GUI" -or $Mode -eq "Interactive") {
        Write-Host "`n  Initialisierung abgeschlossen. Druecke Enter fuer das Menue...`n" -ForegroundColor Cyan
        $null = Read-Host
    } else {
        Write-Host "" -ForegroundColor Cyan
    }
    return $config
}

function Load-JDSConfig {
    param()

    $paths = @(
        $ConfigPath,
        "$script:ScriptPath\config\security-config.json",
        ".\config\security-config.json"
    )

    foreach ($path in $paths) {
        if ($path -and (Test-Path $path)) {
            try {
                $json = Get-Content $path -Raw -Encoding UTF8
                $config = $json | ConvertFrom-Json -ErrorAction Stop

                $hashtable = @{}
                $config.PSObject.Properties | ForEach-Object {
                    $key = $_.Name
                    $value = $_.Value
                    if ($value -is [PSCustomObject]) {
                        $subHash = @{}
                        $value.PSObject.Properties | ForEach-Object {
                            $subHash[$_.Name] = $_.Value
                        }
                        $hashtable[$key] = $subHash
                    } else {
                        $hashtable[$key] = $value
                    }
                }

                Write-Host "  [OK] Konfiguration geladen: $path" -ForegroundColor Green
                if ($hashtable.general.install_path -and $hashtable.general.install_path -ne $script:ScriptPath) {
                    Write-Host "  [INFO] USB-Betrieb erkannt - Pfade automatisch angepasst" -ForegroundColor Yellow
                    $hashtable.general.install_path = $script:ScriptPath
                    $hashtable.general.data_path = "$script:ScriptPath\data"
                }
                return $hashtable
            } catch {
                Write-Host "  [FEHLER] Konfiguration fehlerhaft: $_" -ForegroundColor Red
            }
        }
    }

    Write-Host "  [WARN] Keine Konfiguration gefunden - verwende Standardwerte" -ForegroundColor Yellow
    return @{
        version = "1.0.0"
        general = @{ server_name = $env:COMPUTERNAME; log_retention_days = 90 }
        firewall = @{ enabled = $true; allowed_ports = @(80,443,3389); block_inbound = $true; allow_ping = $false; block_bruteforce = $true; bruteforce_threshold = 5; bruteforce_window_minutes = 15 }
        ids = @{ enabled = $true; scan_interval_seconds = 30; suspicious_ports = @(4444,5555,6666,7777,8443,9001,31337); alert_on_failed_logins = $true; failed_login_threshold = 10 }
        encryption = @{ enabled = $true; auto_encrypt_paths = @("C:\CustomerData","C:\ClientData"); bitlocker_enabled = $true; efs_enabled = $true }
        backup = @{ enabled = $true; destination = "D:\Backups"; retention_days = 30; max_full_backups = 7; encrypted = $true; compression = $true; verify_after_backup = $true; source_paths = @("C:\CustomerData","C:\Users") }
        honeypot = @{ enabled = $true; ports = @(21,23,80,443,3389,8080); fake_files = @("C:\Honeypot\passwords.xlsx","C:\Honeypot\kunden_db.csv","C:\Honeypot\zugangsdaten.txt"); alert_on_access = $true; fake_shares = @("Backup","Data","Admin") }
        audit = @{ enabled = $true; log_file = "logs\jds-audit.log"; send_email_alerts = $false; alert_recipients = @() }
        usb_security = @{ enabled = $true; block_usb_storage = $false; autorun_disabled = $true; whitelist_mode = $false; allowed_usb_devices = @() }
        ransomware = @{ enabled = $true; scan_mass_renames = $true; scan_recent_changes = $true; detect_new_extensions = $true; detect_mass_changes = $true; detect_decrypt_files = $true; monitor_interval_seconds = 60; block_shares_on_alert = $true; block_processes_on_alert = $true }
        file_integrity = @{ enabled = $true; watch_paths = @("$env:WINDIR\System32\drivers\etc\hosts","C:\ProgramData"); check_interval_seconds = 300; keep_baselines = 10; detect_new_files = $true; alert_on_change = $true }
        process_security = @{ enabled = $true; monitor_interval_seconds = 120; detect_suspicious_parents = $true; detect_suspicious_paths = $true; detect_unsigned = $true; detect_high_resource = $true; detect_run_keys = $true; auto_kill_blacklisted = $true }
        network_security = @{ enabled = $true; monitor_interval_seconds = 180; scan_open_ports = $true; scan_established_connections = $true; scan_arp = $true; scan_dns = $true; scan_shares = $true; block_malicious_dns = $true; harden_network = $true; block_netbios = $true }
        vulnerability_scan = @{ enabled = $true; scan_interval_hours = 24; check_missing_patches = $true; max_days_since_update = 30; check_weak_protocols = $true; check_default_credentials = $true; check_firewall_status = $true; check_defender_status = $true; check_rdp_security = $true }
        self_defense = @{ enabled = $true; check_interval_seconds = 600; check_process = $true; check_service = $true; check_tasks = $true; dead_man_switch = $true }
        incident_response = @{ enabled = $true; auto_respond = $true; action_kill_processes = $true; action_block_shares = $true; action_create_restore_point = $true; action_collect_evidence = $true }
        security_hardening = @{ enabled = $true; encrypt_config = $true; verify_modules = $true; watchdog_enabled = $true; sign_logs = $true; auto_recover = $true; check_interval_seconds = 300 }
        alerts = @{ critical = @{ email = $true; popup = $false; log = $true; sound = $true }; warning = @{ email = $true; popup = $false; log = $true; sound = $false }; info = @{ email = $false; popup = $false; log = $true; sound = $false } }
    }
}
#endregion

#region Menue
function Show-MainMenu {
    param([hashtable]$Config)

    $menuRunning = $true
    while ($menuRunning) {
        Clear-Host
        Write-Host @"
╔══════════════════════════════════════════════════════════════╗
║              JDS SECURE - HAUPTMENUE                         ║
║              $script:JDSVersion                                   ║
╠══════════════════════════════════════════════════════════════╣
║                                                            ║
║   [1]  System-Scan ausfuehren (vollstaendig)                ║
║   [2]  Firewall - Haertung & Scan                           ║
║   [3]  Intrusion Detection - Scan                           ║
║   [4]  Datenverschluesselung - Pruefung & Aktivierung        ║
║   [5]  Backup - Manuell starten                              ║
║   [6]  Audit - Bericht erstellen                             ║
║   [7]  Honeypot - Status & Zugriffe                          ║
║   [8]  USB-Sicherheit - Status pruefen                       ║
║   [9]  Service-Modus starten (Dauerbetrieb)                  ║
║   [10] Sicherheitsbericht exportieren                        ║
║   [11] Ransomware-Schutz - Scan                               ║
║   [12] File-Integritaet - Pruefung                            ║
║   [13] Prozess-Security - Audit                               ║
║   [14] Netzwerk-Security - Scan                               ║
║   [15] Vulnerability-Scan                                     ║
║   [16] Selbstschutz - Pruefung                                 ║
║   [17] Incident-Response - Test                                ║
║   [18] Virenscan - Komplett-Scan                                ║
║   [19] Quarantaene - Anzeigen & Verwalten                       ║
║   [20] DSGVO - Datenschutz-Dokumentation                        ║
║   [21] Konfiguration bearbeiten                                 ║
║                                                            ║
║   [0]  Beenden                                               ║
║                                                            ║
╚══════════════════════════════════════════════════════════════╝

"@ -ForegroundColor Cyan
        Write-Host "  Auswahl [0-21]: " -NoNewline -ForegroundColor White
        $choice = Read-Host

        switch ($choice) {
            "1"  { Invoke-FullScan -Config $Config -ShowPause }
            "2"  { Show-FirewallMenu -Config $Config }
            "3"  { Invoke-IDSMonitor -Config $Config; pause }
            "4"  { Invoke-DataEncryption -Config $Config; pause }
            "5"  { Invoke-BackupSystem -Config $Config; pause }
            "6"  { New-JDSAuditReport -Config $Config; pause }
            "7"  { Show-HoneypotMenu -Config $Config }
            "8"  { Test-USBSecurity -Config $Config; pause }
            "9"  { Start-ServiceMode -Config $Config }
            "10" { Export-SecurityReport -Config $Config }
            "11" { Invoke-RansomwareScan -Config $Config -ShowProgress $true; pause }
            "12" { Invoke-IntegrityCheck -Config $Config -ShowProgress $true; pause }
            "13" { Invoke-ProcessAudit -Config $Config -ShowProgress $true; pause }
            "14" { Invoke-NetworkSecurityScan -Config $Config -ShowProgress $true; pause }
            "15" { Invoke-VulnerabilityScan -Config $Config -ShowProgress $true; pause }
            "16" { Invoke-SelfDefenseCheck -Config $Config -ShowProgress $true; pause }
            "17" { Test-IncidentResponse -Config $Config; pause }
            "18" { Invoke-VirusScan -Config $Config -ShowProgress $true -ScanType "full"; pause }
            "19" { Show-QuarantineMenu -Config $Config }
            "20" { Show-GDPRMenu -Config $Config }
            "21" { Edit-Configuration -Config $Config }
            "0"  {
                Write-Host "  JDS-Secure wird beendet. Auf Wiedersehen!" -ForegroundColor Green
                $menuRunning = $false
            }
            default {
                Write-Host "  Ungueltige Auswahl!" -ForegroundColor Red
                Start-Sleep -Seconds 1
            }
        }
    }
}

function Show-FirewallMenu {
    param([hashtable]$Config)

    Clear-Host
    Write-Host @"
╔══════════════════════════════════════════════════════════════╗
║              JDS SECURE - FIREWALL-MENUE                     ║
╠══════════════════════════════════════════════════════════════╣
║                                                            ║
║   [1]  Firewall-Haertung ausfuehren                          ║
║   [2]  Firewall-Regeln scannen (offene Ports)                ║
║   [3]  Firewall zuruecksetzen (Standard)                     ║
║   [4]  Status anzeigen                                       ║
║                                                            ║
║   [0]  Zurueck zum Hauptmenue                                ║
║                                                            ║
╚══════════════════════════════════════════════════════════════╝

"@ -ForegroundColor Cyan
    Write-Host "  Auswahl [0-4]: " -NoNewline
    $choice = Read-Host

    switch ($choice) {
        "1" { Invoke-FirewallHardening -Config $Config; pause }
        "2" { Invoke-FirewallScan -Config $Config; pause }
        "3" { Invoke-FirewallReset; pause }
        "4" {
            Get-NetFirewallProfile | Format-Table Name, Enabled, DefaultInboundAction, DefaultOutboundAction | Out-Host
            pause
        }
        "0" { return }
    }
}

function Show-HoneypotMenu {
    param([hashtable]$Config)

    Clear-Host
    Write-Host @"
╔══════════════════════════════════════════════════════════════╗
║              JDS SECURE - HONEYPOT-MENUE                     ║
╠══════════════════════════════════════════════════════════════╣
║                                                            ║
║   [1]  Honeypot einrichten & starten                         ║
║   [2]  Honeypot-Zugriffe ueberwachen                         ║
║   [3]  Honeypot-Freigaben erstellen                          ║
║   [4]  Zugriffslog anzeigen                                  ║
║                                                            ║
║   [0]  Zurueck zum Hauptmenue                                ║
║                                                            ║
╚══════════════════════════════════════════════════════════════╝

"@ -ForegroundColor Cyan
    Write-Host "  Auswahl [0-4]: " -NoNewline
    $choice = Read-Host

    switch ($choice) {
        "1" { Invoke-HoneypotSetup -Config $Config; pause }
        "2" { Invoke-HoneypotMonitor -Config $Config; pause }
        "3" { Invoke-HoneypotShares -Config $Config; pause }
        "4" {
            $logFile = "$script:ScriptPath\logs\honeypot-access.log"
            if (Test-Path $logFile) {
                Get-Content $logFile -Tail 50 | Write-Host
            } else {
                Write-Host "  Keine Honeypot-Zugriffe protokolliert." -ForegroundColor Yellow
            }
            pause
        }
        "0" { return }
    }
}
#endregion

#region Kernfunktionen
function Invoke-FullScan {
    param([hashtable]$Config, [switch]$ShowPause)

    Clear-Host
    Write-Host "  JDS SECURE - Vollstaendiger System-Scan`n" -ForegroundColor Cyan

    $results = @{}

    Write-Host "  [1/6] Firewall-Scan..." -NoNewline
    try {
        $fwResult = Invoke-FirewallScan -Config $Config
        $results.Firewall = $fwResult
        Write-Host " $($fwResult.Count) offene Regel(n)" -ForegroundColor $(if ($fwResult.Count -eq 0) { "Green" } else { "Yellow" })
    } catch {
        Write-Host " FEHLER" -ForegroundColor Red
        $results.Firewall = $null
    }

    Write-Host "  [2/6] IDS-Scan..." -NoNewline
    try {
        $idsResult = Invoke-IDSMonitor -Config $Config
        $results.IDS = $idsResult
        if ($idsResult.ThreatsFound) { Write-Host " BEDROHUNGEN GEFUNDEN" -ForegroundColor Red }
        else { Write-Host " Keine Bedrohungen" -ForegroundColor Green }
    } catch {
        Write-Host " FEHLER" -ForegroundColor Red
        $results.IDS = $null
    }

    Write-Host "  [3/6] Auditing..." -NoNewline
    try {
        Initialize-JDSAudit -Config $Config
        $auditResult = Invoke-JDSAuditScan -Config $Config
        $results.Audit = $auditResult
        Write-Host " OK" -ForegroundColor Green
    } catch {
        Write-Host " FEHLER" -ForegroundColor Red
        $results.Audit = $null
    }

    Write-Host "  [4/6] Datenverschluesselung..." -NoNewline
    try {
        Invoke-DataEncryption -Config $Config
        Write-Host " OK" -ForegroundColor Green
    } catch {
        Write-Host " FEHLER" -ForegroundColor Red
    }

    Write-Host "  [5/6] USB-Sicherheit..." -NoNewline
    try {
        Invoke-USBProtection -Config $Config
        Write-Host " OK" -ForegroundColor Green
    } catch {
        Write-Host " FEHLER" -ForegroundColor Red
    }

    Write-Host "  [6/6] Honeypot..." -NoNewline
    try {
        Invoke-HoneypotSetup -Config $Config
        Invoke-HoneypotMonitor -Config $Config
        Write-Host " OK" -ForegroundColor Green
    } catch {
        Write-Host " FEHLER" -ForegroundColor Red
    }

    $scanResultPath = "$script:ScriptPath\logs\last-scan.json"
    $results | ConvertTo-Json -Depth 10 | Set-Content $scanResultPath -Force

    Write-Host "`n  Scan abgeschlossen. Bericht: $scanResultPath" -ForegroundColor Cyan
    if ($ShowPause) {
        Write-Host "  Druecke Enter..." -ForegroundColor Gray
        $null = Read-Host
    }
}

function Start-ServiceMode {
    param([hashtable]$Config)

    $baseDir = if ($PSScriptRoot) { $PSScriptRoot } else { $script:ScriptPath }

    Clear-Host
    Write-Host @"
╔══════════════════════════════════════════════════════════════╗
║           JDS SECURE - SERVICE-MODUS                         ║
║                                                            ║
║   Der Service-Modus startet folgende Daemon-Prozesse:        ║
║    - IDS Ueberwachung (30s)                                  ║
║    - Backup-Planung (02:00)                                  ║
║    - Audit-Monitoring                                        ║
║    - Honeypot-Ueberwachung                                   ║
║    - Ransomware-Schutz (60s)                                 ║
║    - File-Integritat (5min)                                  ║
║    - Prozess-Security (2min)                                 ║
║    - Netzwerk-Security (3min)                                ║
║    - Vulnerability-Scan (24h)                                ║
║    - Selbstschutz (10min)                                    ║
║    - Virenscan (Echtzeit-Ueberwachung)                        ║
║    - Quarantaene-Bereinigung (24h)                            ║
║    - DSGVO-Datenbereinigung (24h)                             ║
║    - Selbstsicherheit (Watchdog + Integritat)                 ║
║                                                            ║
║   Druecke STRG+C zum Beenden des Service-Modus.              ║
║                                                            ║
╚══════════════════════════════════════════════════════════════╝

"@ -ForegroundColor Cyan

    Write-Host "  Starte Service-Modus in 3 Sekunden..." -ForegroundColor Yellow
    Start-Sleep -Seconds 3

    $jobs = @()

    $jobs += Start-Job -Name "JDS-IDS" -ScriptBlock {
        param($c,$d) . "$d\modules\audit.ps1"; . "$d\modules\ids.ps1"; Invoke-IDSContinuous -Config $c
    } -ArgumentList $Config,$baseDir

    $jobs += Start-Job -Name "JDS-Backup" -ScriptBlock {
        param($c,$d) . "$d\modules\audit.ps1"; . "$d\modules\backup.ps1"; Invoke-BackupSchedule -Config $c
    } -ArgumentList $Config,$baseDir

    $jobs += Start-Job -Name "JDS-Audit" -ScriptBlock {
        param($c,$d) while ($true) { . "$d\modules\audit.ps1"; Invoke-JDSAuditScan -Config $c; Start-Sleep -Seconds 300 }
    } -ArgumentList $Config,$baseDir

    $jobs += Start-Job -Name "JDS-Honeypot" -ScriptBlock {
        param($c,$d) while ($true) { . "$d\modules\audit.ps1"; . "$d\modules\honeypot.ps1"; Invoke-HoneypotMonitor -Config $c; Start-Sleep -Seconds 60 }
    } -ArgumentList $Config,$baseDir

    $jobs += Start-Job -Name "JDS-Ransomware" -ScriptBlock {
        param($c,$d) . "$d\modules\audit.ps1"; . "$d\modules\ransomware.ps1"; Start-RansomwareMonitor -Config $c
    } -ArgumentList $Config,$baseDir

    $jobs += Start-Job -Name "JDS-Integrity" -ScriptBlock {
        param($c,$d) . "$d\modules\audit.ps1"; . "$d\modules\file-integrity.ps1"; Invoke-IntegrityContinuous -Config $c
    } -ArgumentList $Config,$baseDir

    $jobs += Start-Job -Name "JDS-Process" -ScriptBlock {
        param($c,$d) . "$d\modules\audit.ps1"; . "$d\modules\process-security.ps1"; Start-ProcessMonitor -Config $c
    } -ArgumentList $Config,$baseDir

    $jobs += Start-Job -Name "JDS-Network" -ScriptBlock {
        param($c,$d) . "$d\modules\audit.ps1"; . "$d\modules\network-security.ps1"; Start-NetworkMonitor -Config $c
    } -ArgumentList $Config,$baseDir

    $jobs += Start-Job -Name "JDS-Vulnerability" -ScriptBlock {
        param($c,$d) . "$d\modules\audit.ps1"; . "$d\modules\vulnerability-scan.ps1"; Start-VulnerabilityMonitor -Config $c
    } -ArgumentList $Config,$baseDir

    $jobs += Start-Job -Name "JDS-SelfDefense" -ScriptBlock {
        param($c,$d) . "$d\modules\audit.ps1"; . "$d\modules\self-defense.ps1"; Start-SelfDefenseMonitor -Config $c
    } -ArgumentList $Config,$baseDir

    $jobs += Start-Job -Name "JDS-VirusScan" -ScriptBlock {
        param($c,$d) . "$d\modules\audit.ps1"; . "$d\modules\virus-scan.ps1"; Start-VirusScanService -Config $c; while ($true) { Start-Sleep -Seconds 3600 }
    } -ArgumentList $Config,$baseDir

    $jobs += Start-Job -Name "JDS-Quarantine" -ScriptBlock {
        param($c,$d) . "$d\modules\audit.ps1"; . "$d\modules\quarantine.ps1"; Start-QuarantineCleanupService -Config $c
    } -ArgumentList $Config,$baseDir

    $jobs += Start-Job -Name "JDS-GDPR" -ScriptBlock {
        param($c,$d) . "$d\modules\audit.ps1"; . "$d\modules\gdpr.ps1"; while ($true) { Invoke-GDPRDataCleanup -Config $c -AutoMode $true | Out-Null; Start-Sleep -Seconds 86400 }
    } -ArgumentList $Config,$baseDir

    $jobs += Start-Job -Name "JDS-Hardening" -ScriptBlock {
        param($c,$d) . "$d\modules\audit.ps1"; . "$d\modules\security-hardening.ps1"; Start-JDSWatchdog -Config $c
    } -ArgumentList $Config,$baseDir

    Write-Host " Service-Modus aktiv mit $($jobs.Count) Hintergrundprozessen" -ForegroundColor Green
    Write-Host " Ueberwachung aktiv. Druecke STRG+C zum Beenden.`n" -ForegroundColor Cyan

    try {
        while ($true) {
            $running = $jobs | Where-Object { $_.State -eq "Running" }
            $failed = $jobs | Where-Object { $_.State -eq "Failed" }

            Write-Host "  $(Get-Date -Format 'HH:mm:ss') - Aktive Dienste: $($running.Count)/$($jobs.Count)" -NoNewline
            if ($failed.Count -gt 0) {
                Write-Host " | Ausgefallen: $($failed.Count)" -ForegroundColor Red
                foreach ($f in $failed) {
                    Write-Host "    [$($f.Name)] $(Receive-Job $f -ErrorAction SilentlyContinue)" -ForegroundColor Red
                    Remove-Job $f -Force -ErrorAction SilentlyContinue
                }
            } else {
                Write-Host ""
            }

            Start-Sleep -Seconds 15
        }
    } finally {
        Write-Host "  Beende Service-Modus..." -ForegroundColor Yellow
        $jobs | Stop-Job -ErrorAction SilentlyContinue
        $jobs | Remove-Job -Force -ErrorAction SilentlyContinue
        Write-Host "  Alle Dienste gestoppt." -ForegroundColor Green
        pause
    }
}

function Show-QuarantineMenu {
    param([hashtable]$Config)
    $menuOpen = $true
    while ($menuOpen) {
        Clear-Host
        $summary = Get-QuarantineSummary -Config $Config
        $list = Get-QuarantineList -Config $Config
        Write-Host @"
╔══════════════════════════════════════════════════════════════╗
║              QUARANTAENE - VERWALTUNG                        ║
╠══════════════════════════════════════════════════════════════╣
║  Status: $($summary.active) aktiv | $($summary.restored) wiederhergestellt    ║
║  Groesse: $($summary.total_size_mb) MB                                     ║
╠══════════════════════════════════════════════════════════════╣
"@ -ForegroundColor Cyan
        $idx = 1
        $quarantineItems = @()
        if ($list -and $list.Count -gt 0) {
            foreach ($item in $list) {
                if (-not $item.restored -and (Test-Path $item.quarantined_path)) {
                    Write-Host "  [$idx] $($item.file_name) - $($item.reason) ($(Get-Date $item.quarantine_date -Format 'dd.MM HH:mm'))" -ForegroundColor Yellow
                    $quarantineItems += $item
                    $idx++
                }
            }
        }
        if ($idx -eq 1) {
            Write-Host "  Keine aktiven Quarantaene-Eintraege." -ForegroundColor Green
        }
        Write-Host @"
╠══════════════════════════════════════════════════════════════╣
║  [W] Wiederherstellen   [C] Bereinigen   [R] Aktualisieren  ║
║  [0] Zuerueck zum Menue                                      ║
╚══════════════════════════════════════════════════════════════╝
"@ -ForegroundColor Cyan
        $qChoice = Read-Host "  Auswahl"
        switch ($qChoice) {
            "0" { $menuOpen = $false }
            "R" { $summary = Get-QuarantineSummary -Config $Config }
            "W" {
                if ($quarantineItems.Count -gt 0) {
                    $restoreIdx = Read-Host "  Welche Nummer wiederherstellen"
                    $restoreItem = $quarantineItems[$restoreIdx - 1]
                    if ($restoreItem) {
                        $result = Restore-QuarantineItem -Config $Config -QuarantineId $restoreItem.id
                        if ($result.success) { Write-Host "  Wiederhergestellt: $($result.restored_path)" -ForegroundColor Green }
                        else { Write-Host "  Fehler: $($result.reason)" -ForegroundColor Red }
                        pause
                    }
                } else { Write-Host "  Keine Eintraege." -ForegroundColor Yellow; pause }
            }
            "C" {
                $days = Read-Host "  Aelter als X Tage loeschen (Standard: 90)"
                if (-not $days) { $days = 90 }
                $result = Clear-Quarantine -Config $Config -OlderThanDays $days
                Write-Host "  $($result.deleted) Dateien bereinigt." -ForegroundColor Green; pause
            }
        }
    }
}

function Show-GDPRMenu {
    param([hashtable]$Config)
    $menuOpen = $true
    while ($menuOpen) {
        Clear-Host
        $breachSum = Get-GDPRBreachSummary -Config $Config
        $retentionResult = Test-GDPRRetentionPolicies -Config $Config
        Write-Host @"
╔══════════════════════════════════════════════════════════════╗
║              DSGVO - DATENSCHUTZ-MENUE                       ║
╠══════════════════════════════════════════════════════════════╣
║  Datenschutzverletzungen: $($breachSum.total) gesamt, $($breachSum.open) offen, $($breachSum.overdue) ueberfaellig  ║
║  Datenaufbewahrung: $($retentionResult.expired_total_files) abgelaufene Dateien    ║
╠══════════════════════════════════════════════════════════════╣
║  [1] Datenschutzverletzung melden (DSGVO Art. 33)            ║
║  [2] Datenbereinigung durchfuehren (Loeschkonzept)            ║
║  [3] Dokumentation exportieren                               ║
║  [4] Verarbeitungsverzeichnis (Art. 30)                       ║
║  [5] TOM-Dokumentation                                        ║
║  [6] DSGVO-Compliance-Uebersicht                              ║
║  [7] Bereinigung testen (Dry-Run)                             ║
║                                                            ║
║  [0] Zuerueck zum Menue                                      ║
╚══════════════════════════════════════════════════════════════╝
"@ -ForegroundColor Cyan
        $gChoice = Read-Host "  Auswahl"
        switch ($gChoice) {
            "0" { $menuOpen = $false }
            "1" {
                $incId = Read-Host "  Incident-ID (oder leer fuer manuell)"
                $desc = Read-Host "  Beschreibung des Vorfalls"
                $data = Read-Host "  Betroffene Daten"
                $persons = Read-Host "  Betroffene Personen (Enter=Unbekannt)"
                if (-not $persons) { $persons = "Unbekannt" }
                $measures = Read-Host "  Ergriffene Massnahmen"
                $email = Read-Host "  Benachrichtigungs-E-Mail (Enter=keine)"
                $result = New-GDPRBreachNotification -Config $Config -IncidentId $incId -Description $desc -AffectedData $data -AffectedPersons $persons -Measures $measures -NotificationEmail $email
                if ($result.success) { Write-Host "  Meldung erstellt: $($result.breach_id)" -ForegroundColor Green; Write-Host "  Frist: $($result.deadline)" -ForegroundColor Yellow; Write-Host "  Export: $($result.report_path)" -ForegroundColor Cyan } else { Write-Host "  Fehler: $($result.reason)" -ForegroundColor Red }
                pause
            }
            "2" { $r = Invoke-GDPRDataCleanup -Config $Config; Write-Host "  $($r.deleted) Dateien geloescht ($($r.deleted_size_mb) MB)" -ForegroundColor Green; pause }
            "3" { $r = Export-GDPRDocumentation -Config $Config -Type "all"; if ($r.success) { foreach ($f in $r.files) { Write-Host "  $($f.type): $($f.path)" -ForegroundColor Cyan } } else { Write-Host "  Fehler: $($r.reason)" -ForegroundColor Red }; pause }
            "4" { $r = Export-GDPRDocumentation -Config $Config -Type "processing"; if ($r.success) { Write-Host "  Exportiert: $($r.files[0].path)" -ForegroundColor Green } else { Write-Host "  Fehler: $($r.reason)" -ForegroundColor Red }; pause }
            "5" { $r = Export-GDPRDocumentation -Config $Config -Type "tom"; if ($r.success) { Write-Host "  Exportiert: $($r.files[0].path)" -ForegroundColor Green } else { Write-Host "  Fehler: $($r.reason)" -ForegroundColor Red }; pause }
            "6" { $r = Export-GDPRDocumentation -Config $Config -Type "overview"; if ($r.success) { Write-Host "  Exportiert: $($r.files[0].path)" -ForegroundColor Green } else { Write-Host "  Fehler: $($r.reason)" -ForegroundColor Red }; pause }
            "7" { $r = Test-GDPRRetentionPolicies -Config $Config; Write-Host "  $($r.policies_checked) Richtlinien, $($r.expired_total_files) abgelaufene Dateien ($($r.total_expired_size_mb) MB)" -ForegroundColor Cyan; pause }
        }
    }
}

function Export-SecurityReport {
    param([hashtable]$Config)

    $reportPath = "$script:ScriptPath\logs\security-report_$(Get-Date -Format 'yyyyMMdd_HHmmss').html"
    Write-Host "  Generiere Sicherheitsbericht..." -ForegroundColor Cyan

    $fwRules = Get-NetFirewallRule -Enabled True -Action Allow -Direction Inbound -ErrorAction SilentlyContinue | Select-Object -First 20
    $failedLogins = (Get-WinEvent -FilterHashtable @{LogName='Security'; ID=4625} -MaxEvents 100 -ErrorAction SilentlyContinue).Count
    $recentEvents = Get-WinEvent -LogName Security -MaxEvents 50 -ErrorAction SilentlyContinue | Where-Object { $_.TimeCreated -gt (Get-Date).AddHours(-24) }

    $serverName = $env:COMPUTERNAME
    $now = Get-Date -Format 'dd.MM.yyyy HH:mm:ss'
    $runningServices = (Get-Service | Where-Object { $_.Status -eq 'Running' }).Count
    $processCount = (Get-Process).Count
    $totalMem = [math]::Round(((Get-CimInstance Win32_OperatingSystem).TotalVisibleMemorySize/1MB), 1)

    $fwRows = Get-NetFirewallProfile | ForEach-Object {
        "<tr><td>$($_.Name)</td><td><span class='badge badge-ok'>AKTIV</span></td><td>$($_.DefaultInboundAction)</td><td>$($_.DefaultOutboundAction)</td></tr>"
    }
    $fwRowsHtml = $fwRows -join "`n"

    $eventRows = ""
    if ($recentEvents) {
        $eventRows = $recentEvents | Select-Object -First 20 | ForEach-Object {
            $l = $_.LevelDisplayName
            $b = if ($l -eq "Error") { "badge-err" } elseif ($l -eq "Warning") { "badge-warn" } else { "badge-ok" }
            "<tr><td>$($_.TimeCreated.ToString('HH:mm:ss'))</td><td>$($_.Id)</td><td><span class='badge $b'>$l</span></td></tr>"
        } -join "`n"
    } else {
        $eventRows = "<tr><td colspan='3'>Keine Ereignisse</td></tr>"
    }

    $ransomResult = Invoke-RansomwareScan -Config $Config -ShowProgress $false
    $integrityResult = Invoke-IntegrityCheck -Config $Config -ShowProgress $false
    $processResult = Invoke-ProcessAudit -Config $Config -ShowProgress $false
    $networkResult = Invoke-NetworkSecurityScan -Config $Config -ShowProgress $false
    $vulnResult = Invoke-VulnerabilityScan -Config $Config -ShowProgress $false
    $selfDefResult = Invoke-SelfDefenseCheck -Config $Config -ShowProgress $false
    $virusResult = Invoke-VirusScan -Config $Config -ShowProgress $false -ScanType "quick"

    $rec1 = if ($failedLogins -gt 10) { "[!] Erhoehte Anzahl von Fehlanmeldungen - Brute-Force-Schutz aktiv" } else { "[OK] Fehlanmeldungen im normalen Bereich" }
    $rec2 = if ($Config.firewall.block_inbound) { "[OK] Firewall blockt eingehende Verbindungen" } else { "[!] Firewall laesst eingehende Verbindungen zu" }
    $rec3 = if ($vulnResult.critical -gt 0) { "[!] $($vulnResult.critical) kritische Sicherheitsluecken - Massnahmen erforderlich" } else { "[OK] Keine kritischen Sicherheitsluecken gefunden" }
    $rec4 = if ($ransomResult.status -eq "danger") { "[!] Ransomware-Indikatoren erkannt - System ueberpruefen" } else { "[OK] Ransomware-Schutz aktiv" }
    $rec5 = if ($processResult.blacklisted -gt 0) { "[!] $($processResult.blacklisted) blacklisted Prozesse - Auto-Kill ausgeloest" } elseif ($vulnResult.warnings -gt 0) { "[WARN] $($vulnResult.warnings) Sicherheitswarnungen - Pruefung empfohlen" } else { "[OK] Keine offenen Sicherheitsrisiken" }
    $rec6 = if ($selfDefResult.threats -gt 0) { "[!] $($selfDefResult.danger_threats) kritische / $($selfDefResult.warning_threats) Warnungen gegen JDS-Secure selbst" } else { "[OK] JDS-Secure-Integritaet intakt" }
    $breachSum = Get-GDPRBreachSummary -Config $Config
    $rec7 = if ($breachSum.open -gt 0) { "[!] $($breachSum.open) offene Datenschutzverletzungen - Frist beachten (72h)" } elseif ($breachSum.total -gt 0) { "[OK] Alle Datenschutzverletzungen bearbeitet" } else { "[OK] Keine Datenschutzverletzungen dokumentiert" }
    $rec8 = if ($virusResult.threats_found -gt 0) { "[!] $($virusResult.threats_found) Virenfunde - Quarantaene prüfen" } else { "[OK] Virenscan ohne Funde" }

    $modulStatusRows = @"
<tr><td>Firewall</td><td><span class='badge badge-ok'>$(if ($Config.firewall.enabled) { "AKTIV" } else { "AUS" })</span></td></tr>
<tr><td>IDS-Ueberwachung</td><td><span class='badge badge-ok'>$(if ($Config.ids.enabled) { "AKTIV" } else { "AUS" })</span></td></tr>
<tr><td>Verschlusselung</td><td><span class='badge badge-ok'>$(if ($Config.encryption.enabled) { "AKTIV" } else { "AUS" })</span></td></tr>
<tr><td>Backup</td><td><span class='badge badge-ok'>$(if ($Config.backup.enabled) { "BEREIT" } else { "AUS" })</span></td></tr>
<tr><td>Honeypot</td><td><span class='badge badge-ok'>$(if ($Config.honeypot.enabled) { "AKTIV" } else { "AUS" })</span></td></tr>
<tr><td>USB-Security</td><td><span class='badge badge-ok'>$(if ($Config.usb_security.enabled) { "AKTIV" } else { "AUS" })</span></td></tr>
<tr><td>Ransomware-Schutz</td><td><span class='badge $(if ($ransomResult.status -eq "danger") { "badge-err" } elseif ($ransomResult.status -eq "warn") { "badge-warn" } else { "badge-ok" })'>$(if ($ransomResult.status -eq "danger") { "GEFUNDEN" } elseif ($ransomResult.status -eq "warn") { "WARNUNG" } else { "SAUBER" })</span> ($($ransomResult.suspicious_findings) Funde)</td></tr>
<tr><td>File-Integritat</td><td><span class='badge $(if ($integrityResult.status -eq "danger") { "badge-err" } elseif ($integrityResult.status -eq "warn") { "badge-warn" } else { "badge-ok" })'>$(if ($integrityResult.status -eq "danger") { "VERLETZT" } elseif ($integrityResult.status -eq "warn") { "GEAENDERT" } else { "INTACT" })</span> ($($integrityResult.changes) Aenderungen)</td></tr>
<tr><td>Prozess-Security</td><td><span class='badge $(if ($processResult.blacklisted -gt 0) { "badge-err" } elseif ($processResult.suspicious -gt 0) { "badge-warn" } else { "badge-ok" })'>$(if ($processResult.blacklisted -gt 0) { "BLOCKED" } elseif ($processResult.suspicious -gt 0) { "VERDAECHTIG" } else { "SAUBER" })</span> ($($processResult.blacklisted) blacklisted)</td></tr>
<tr><td>Netzwerk-Security</td><td><span class='badge $(if ($networkResult.arp_anomalies -gt 0) { "badge-err" } elseif ($networkResult.suspicious_connections -gt 0) { "badge-warn" } else { "badge-ok" })'>$(if ($networkResult.status -eq "danger") { "GEFAHR" } elseif ($networkResult.status -eq "warn") { "WARNUNG" } else { "SAUBER" })</span> ($($networkResult.suspicious_connections) Verbindungen)</td></tr>
<tr><td>Vulnerability-Scan</td><td><span class='badge $(if ($vulnResult.critical -gt 0) { "badge-err" } elseif ($vulnResult.warnings -gt 0) { "badge-warn" } else { "badge-ok" })'>$(if ($vulnResult.critical -gt 0) { "$($vulnResult.critical) KRITISCH" } elseif ($vulnResult.warnings -gt 0) { "$($vulnResult.warnings) WARNUNGEN" } else { "OK" })</span></td></tr>
<tr><td>Selbstschutz</td><td><span class='badge $(if ($selfDefResult.status -eq "danger") { "badge-err" } elseif ($selfDefResult.status -eq "warn") { "badge-warn" } else { "badge-ok" })'>$(if ($selfDefResult.status -eq "danger") { "BEDROHT" } elseif ($selfDefResult.status -eq "warn") { "WARNUNG" } else { "INTACT" })</span> ($($selfDefResult.danger_threats) kritisch / $($selfDefResult.warning_threats) Warnungen)</td></tr>
<tr><td>Incident-Response</td><td><span class='badge badge-ok'>$(if ($Config.incident_response.enabled) { "AKTIV" } else { "AUS" })</span></td></tr>
<tr><td>Virenscan</td><td><span class='badge $(if ($virusResult.threats_found -gt 0) { "badge-err" } elseif ($virusResult.suspicious_found -gt 0) { "badge-warn" } else { "badge-ok" })'>$(if ($virusResult.threats_found -gt 0) { "$($virusResult.threats_found) GEFUNDEN" } elseif ($virusResult.suspicious_found -gt 0) { "$($virusResult.suspicious_found) VERDAECHTIG" } elseif ($virusResult.files_scanned -eq 0) { "AUS" } else { "$($virusResult.files_scanned) Dateien OK" })</span></td></tr>
<tr><td>Quarantaene</td><td><span class='badge badge-ok'>$(if ($Config.quarantine.enabled) { "AKTIV" } else { "AUS" })</span></td></tr>
<tr><td>DSGVO</td><td><span class='badge badge-ok'>$(if ($Config.gdpr.enabled) { "AKTIV" } else { "AUS" })</span></td></tr>
"@

    $html = @"
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>JDS-Secure Sicherheitsbericht</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #0a0e17; color: #e0e0e0; padding: 40px; }
        .container { max-width: 1000px; margin: 0 auto; }
        .header { text-align: center; padding: 30px; background: linear-gradient(135deg, #0d1b2a, #1b2838); border-radius: 15px; margin-bottom: 30px; border: 1px solid #1e3a5f; }
        .header h1 { color: #00d4ff; font-size: 28px; }
        .header p { color: #8899aa; margin-top: 5px; }
        .card { background: #111927; border-radius: 12px; padding: 25px; margin-bottom: 20px; border: 1px solid #1e3a5f; }
        .card h2 { color: #00d4ff; margin-bottom: 15px; font-size: 18px; border-bottom: 1px solid #1e3a5f; padding-bottom: 10px; }
        .status-ok { color: #00e676; }
        .status-warn { color: #ffab00; }
        .status-err { color: #ff1744; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #1a2332; font-size: 13px; }
        th { color: #00d4ff; font-weight: 600; }
        .footer { text-align: center; color: #556677; margin-top: 30px; font-size: 12px; }
        .badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
        .badge-ok { background: #00e67622; color: #00e676; border: 1px solid #00e67644; }
        .badge-warn { background: #ffab0022; color: #ffab00; border: 1px solid #ffab0044; }
        .badge-err { background: #ff174422; color: #ff1744; border: 1px solid #ff174444; }
        .metric-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px; }
        .metric { background: #0d1b2a; padding: 20px; border-radius: 10px; text-align: center; }
        .metric .value { font-size: 32px; font-weight: 700; color: #00d4ff; }
        .metric .label { font-size: 12px; color: #8899aa; margin-top: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>JDS-Secure Sicherheitsbericht</h1>
            <p>Server: $serverName | $now</p>
            <p>JDS-Secure v$script:JDSVersion</p>
        </div>
        <div class="card">
            <h2>System-Uebersicht</h2>
            <div class="metric-grid">
                <div class="metric"><div class="value">$runningServices</div><div class="label">Active Dienste</div></div>
                <div class="metric"><div class="value">$processCount</div><div class="label">Prozesse</div></div>
                <div class="metric"><div class="value">$totalMem GB</div><div class="label">Arbeitsspeicher</div></div>
                <div class="metric"><div class="value">$failedLogins</div><div class="label">Fehlanmeldungen (24h)</div></div>
            </div>
        </div>
        <div class="card">
            <h2>Modul-Status (alle 17 Module)</h2>
            <table>
                <tr><th>Modul</th><th>Status</th></tr>
                $modulStatusRows
            </table>
        </div>
        <div class="card">
            <h2>Firewall-Status</h2>
            <table>
                <tr><th>Profil</th><th>Status</th><th>Eingehend</th><th>Ausgehend</th></tr>
                $fwRowsHtml
            </table>
        </div>
        <div class="card">
            <h2>Ransomware-Schutz</h2>
            <div class='metric-grid'>
                <div class='metric'><div class='value'>$($ransomResult.files_scanned)</div><div class='label'>Gescante Dateien</div></div>
                <div class='metric'><div class='value'>$($ransomResult.suspicious_findings)</div><div class='label'>Verdaechtige Funde</div></div>
                <div class='metric'><div class='value'>$($ransomResult.alerts_triggered)</div><div class='label'>Alarme</div></div>
                <div class='metric'><div class='value'>$($ransomResult.scan_duration_sec)s</div><div class='label'>Scan-Dauer</div></div>
            </div>
        </div>
        <div class="card">
            <h2>File-Integritat</h2>
            <div class='metric-grid'>
                <div class='metric'><div class='value'>$($integrityResult.checked)</div><div class='label'>Geprufte Eintraege</div></div>
                <div class='metric'><div class='value'>$($integrityResult.changes)</div><div class='label'>Aenderungen</div></div>
                <div class='metric'><div class='value'>$($integrityResult.critical)</div><div class='label'>Kritisch</div></div>
                <div class='metric'><div class='value'>$($integrityResult.new_files.Count)</div><div class='label'>Neue Dateien</div></div>
            </div>
        </div>
        <div class="card">
            <h2>Prozess-Security</h2>
            <div class='metric-grid'>
                <div class='metric'><div class='value'>$($processResult.total_processes)</div><div class='label'>Prozesse</div></div>
                <div class='metric'><div class='value'>$($processResult.blacklisted)</div><div class='label'>Blacklisted</div></div>
                <div class='metric'><div class='value'>$($processResult.suspicious)</div><div class='label'>Verdaechtig</div></div>
                <div class='metric'><div class='value'>$($processResult.high_resource)</div><div class='label'>Hohe Ressourcen</div></div>
            </div>
        </div>
        <div class="card">
            <h2>Netzwerk-Sicherheit</h2>
            <div class='metric-grid'>
                <div class='metric'><div class='value'>$($networkResult.open_ports)</div><div class='label'>Offene Ports</div></div>
                <div class='metric'><div class='value'>$($networkResult.suspicious_connections)</div><div class='label'>Verdaectige Verbindungen</div></div>
                <div class='metric'><div class='value'>$($networkResult.arp_anomalies)</div><div class='label'>ARP-Anomalien</div></div>
                <div class='metric'><div class='value'>$($networkResult.dns_issues)</div><div class='label'>DNS-Probleme</div></div>
            </div>
        </div>
        <div class="card">
            <h2>Vulnerability-Scan</h2>
            <div class='metric-grid'>
                <div class='metric'><div class='value'>$($vulnResult.critical)</div><div class='label'>Kritisch</div></div>
                <div class='metric'><div class='value'>$($vulnResult.warnings)</div><div class='label'>Warnungen</div></div>
                <div class='metric'><div class='value'>$($vulnResult.info)</div><div class='label'>Hinweise</div></div>
                <div class='metric'><div class='value'>$($vulnResult.total_findings)</div><div class='label'>Gesamt</div></div>
            </div>
        </div>
        <div class="card">
            <h2>Selbstschutz (JDS-Secure-Integritaet)</h2>
            <div class='metric-grid'>
                <div class='metric'><div class='value'>$($selfDefResult.threats)</div><div class='label'>Bedrohungen</div></div>
                <div class='metric'><div class='value'>$($selfDefResult.danger_threats)</div><div class='label'>Kritisch</div></div>
                <div class='metric'><div class='value'>$($selfDefResult.warning_threats)</div><div class='label'>Warnungen</div></div>
                <div class='metric'><div class='value'>$($selfDefResult.protections_active)</div><div class='label'>Aktive Schutzmassnahmen</div></div>
            </div>
        </div>
        <div class="card">
            <h2>Virenscan</h2>
            <div class='metric-grid'>
                <div class='metric'><div class='value'>$($virusResult.files_scanned)</div><div class='label'>Gescante Dateien</div></div>
                <div class='metric'><div class='value'>$($virusResult.threats_found)</div><div class='label'>Bedrohungen</div></div>
                <div class='metric'><div class='value'>$($virusResult.suspicious_found)</div><div class='label'>Verdaectig</div></div>
                <div class='metric'><div class='value'>$($virusResult.defender_threats)</div><div class='label'>Defender-Funde (24h)</div></div>
            </div>
        </div>
        <div class="card">
            <h2>Letzte Sicherheitsereignisse (24h)</h2>
            <table>
                <tr><th>Zeit</th><th>Ereignis-ID</th><th>Typ</th></tr>
                $eventRows
            </table>
        </div>
        <div class="card">
            <h2>Empfehlungen</h2>
            <ul style='margin-left: 20px; line-height: 2; color: #ccd;'>
                <li>$rec1</li>
                <li>$rec2</li>
                <li>$rec3</li>
                <li>$rec4</li>
                <li>$rec5</li>
                <li>$rec6</li>
                <li>$rec7</li>
                <li>$rec8</li>
            </ul>
        </div>
        <div class="footer">
            <p>Generiert von JDS-Secure v$script:JDSVersion | $now</p>
            <p>JDS Secure - Enterprise Security Suite | Alle Rechte vorbehalten</p>
        </div>
    </div>
</body>
</html>
"@

    Set-Content -Path $reportPath -Value $html -Encoding UTF8 -Force
    Write-Host "  Bericht exportiert: $reportPath" -ForegroundColor Green
    Start-Process $reportPath
}

function Edit-Configuration {
    param([hashtable]$Config)

    $configPath = "$script:ScriptPath\config\security-config.json"

    if (Test-Path $configPath) {
        notepad.exe $configPath
        Write-Host "  Konfiguration geoeffnet. Aenderungen werden beim naechsten Start wirksam." -ForegroundColor Green
        $reload = Read-Host "  Config jetzt verschluesselt speichern? (j/N)"
        if ($reload -eq "j") {
            $newConfig = Load-JDSConfig
            try {
                . "$script:ScriptPath\modules\security-hardening.ps1"
                $encrypted = Protect-JDSConfigSensitive -Config $newConfig
                $encrypted | ConvertTo-Json -Depth 10 | Set-Content -Path $configPath -Encoding UTF8 -Force
                Write-Host "  Config verschluesselt gespeichert." -ForegroundColor Green
            } catch { Write-Host "  Fehler bei Verschluesselung: $_" -ForegroundColor Red }
        }
    } else {
        Write-Host "  Keine Konfigurationsdatei gefunden." -ForegroundColor Yellow
    }
    pause
}
#endregion

#region Einstiegspunkt

# Beim Source-only-Modus (via jds-runner.ps1) nur Funktionen definieren, nichts ausfuehren
if (-not $global:JDSSkipEntry) {

# USB-Lizenzaktivierungspruefung
$script:IsUSB = $false
try {
    $drive = (Get-Item $script:ScriptPath).PSDrive
    $driveInfo = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DeviceID='$($drive.Name):'" -ErrorAction SilentlyContinue
    if ($driveInfo -and $driveInfo.DriveType -eq 2) { $script:IsUSB = $true }
} catch {}

if ($script:IsUSB -and $Mode -ne "Backup" -and $Mode -ne "Cleanup" -and $Mode -ne "Report") {
    $licFile = Join-Path $script:ScriptPath "data\.license"
    $activateScript = Join-Path $script:ScriptPath "activate.ps1"

    if (-not (Test-Path $licFile)) {
        if (Test-Path $activateScript) {
            Write-Host "  [LICENSE] Lizenzaktivierung erforderlich..." -ForegroundColor Yellow
            $ok = & $activateScript
            if (-not $ok) { exit 1 }
        }
    } else {
        try {
            $lic = Get-Content $licFile -Raw -Encoding UTF8 | ConvertFrom-Json
            if (-not $lic.activated -or -not $lic.hash) {
                Write-Host "  [LICENSE] Ungueltige Lizenzdatei. Bitte neu aktivieren." -ForegroundColor Red
                if (Test-Path $activateScript) { $ok = & $activateScript; if (-not $ok) { exit 1 } }
            }
        } catch {
            Write-Host "  [LICENSE] Lizenzfehler: $_" -ForegroundColor Red
        }
    }
}

# Zuerst security-hardening.ps1 laden (wird von Initialize-JDSSecure benoetigt)
$script:HardeningPath = "$script:ScriptPath\modules\security-hardening.ps1"
if (Test-Path $script:HardeningPath) {
    try { . $script:HardeningPath } catch { Write-Host "  [FEHLER] security-hardening.ps1: $_" -ForegroundColor Red }
}

if ($Mode -ne "Backup" -and $Mode -ne "Cleanup" -and $Mode -ne "Report") {
    $global:Config = Initialize-JDSSecure -Mode $Mode
} else {
    $global:Config = Load-JDSConfig
}

# Module auf Skript-Ebene laden (Funktionen bleiben nach Initialisierung erhalten)
$script:ModuleList = @(
    "$script:ScriptPath\modules\audit.ps1",
    "$script:ScriptPath\modules\firewall.ps1",
    "$script:ScriptPath\modules\ids.ps1",
    "$script:ScriptPath\modules\encryption.ps1",
    "$script:ScriptPath\modules\backup.ps1",
    "$script:ScriptPath\modules\honeypot.ps1",
    "$script:ScriptPath\modules\usb-security.ps1",
    "$script:ScriptPath\modules\gui.ps1",
    "$script:ScriptPath\modules\service.ps1",
    "$script:ScriptPath\modules\ransomware.ps1",
    "$script:ScriptPath\modules\file-integrity.ps1",
    "$script:ScriptPath\modules\process-security.ps1",
    "$script:ScriptPath\modules\network-security.ps1",
    "$script:ScriptPath\modules\vulnerability-scan.ps1",
    "$script:ScriptPath\modules\self-defense.ps1",
    "$script:ScriptPath\modules\incident-response.ps1",
    "$script:ScriptPath\modules\virus-scan.ps1",
    "$script:ScriptPath\modules\quarantine.ps1",
    "$script:ScriptPath\modules\gdpr.ps1"
)

foreach ($module in $script:ModuleList) {
    if (Test-Path $module) {
        try {
            . $module
            if ($Mode -eq "GUI" -or $Mode -eq "Interactive") {
                Write-Host "  [OK] Modul geladen: $(Split-Path $module -Leaf)" -ForegroundColor Green
            }
        } catch {
            Write-Host "  [FEHLER] Modul fehlgeschlagen: $(Split-Path $module -Leaf) - $_" -ForegroundColor Red
        }
    } else {
        if ($Mode -eq "GUI" -or $Mode -eq "Interactive") {
            Write-Host "  [WARN] Modul nicht gefunden: $module" -ForegroundColor Yellow
        }
    }
}

function Invoke-JDSMandatoryUpdateCheck {
    <#
        Verpflichtender Update-Check vor dem Start der interaktiven Oberflaeche.
        Laeuft unabhaengig davon, ueber welchen Weg JDS Secure gestartet wurde
        (JDS-Secure.exe, start.bat, start.vbs), da alle diese Wege letztlich
        hier ("jds-secure.ps1 -Mode GUI/Interactive") zusammenlaufen.
        Wird ein Update gefunden, wird es automatisch heruntergeladen und
        installiert (kein Nutzer-Dialog). Schlaegt die Pruefung oder Installation
        fehl, startet die vorhandene Version normal weiter.
    #>
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    # Manche Systeme/Gruppenrichtlinien erlauben Invoke-RestMethod standardmaessig
    # nur TLS 1.0/1.1 - moderne, Cloudflare-gestuetzte Server lehnen das ab und
    # die Anfrage schlaegt sonst still fehl.
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }

    $versionFile = Join-Path $script:ScriptPath "version.txt"
    $currentVersion = if (Test-Path $versionFile) { (Get-Content $versionFile -Raw).Trim() } else { "$script:JDSVersion.0" }

    $splash = New-Object System.Windows.Forms.Form
    $splash.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
    $splash.StartPosition = "CenterScreen"
    $splash.Size = New-Object System.Drawing.Size(360, 120)
    $splash.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
    $splash.TopMost = $true
    $splash.ShowInTaskbar = $false

    $title = New-Object System.Windows.Forms.Label
    $title.Text = "JDS SECURE"
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
    $title.ForeColor = [System.Drawing.Color]::FromArgb(0, 212, 255)
    $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $title.Dock = [System.Windows.Forms.DockStyle]::Top
    $title.Height = 44

    $statusLbl = New-Object System.Windows.Forms.Label
    $statusLbl.Text = "Pruefe auf Updates..."
    $statusLbl.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
    $statusLbl.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
    $statusLbl.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $statusLbl.Dock = [System.Windows.Forms.DockStyle]::Top
    $statusLbl.Height = 30

    $bar = New-Object System.Windows.Forms.ProgressBar
    $bar.Style = [System.Windows.Forms.ProgressBarStyle]::Marquee
    $bar.MarqueeAnimationSpeed = 30
    $bar.Dock = [System.Windows.Forms.DockStyle]::Bottom
    $bar.Height = 10

    $splash.Controls.Add($bar)
    $splash.Controls.Add($statusLbl)
    $splash.Controls.Add($title)

    $splash.Show()
    $splash.Refresh()

    $result = $null
    try {
        $uri = "https://joel-digitals.de/api/autoupdate/check/jds-secure/?current_version=$currentVersion"
        $result = Invoke-RestMethod -Uri $uri -Method Get -TimeoutSec 6 -UseBasicParsing
    } catch {
        $result = $null
    }

    if ($result -and $result.update_available -and $result.download_link) {
        try {
            $statusLbl.Text = "Update gefunden (v$($result.latest_version)) - wird installiert..."
            $splash.Refresh()

            $tempDir = Join-Path $env:TEMP "jds-update-$($result.latest_version)"
            if (Test-Path $tempDir) { Remove-Item $tempDir -Recurse -Force }
            New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
            $zipPath = "$tempDir.zip"

            $statusLbl.Text = "Lade Update herunter..."
            $splash.Refresh()
            Invoke-WebRequest -Uri $result.download_link -OutFile $zipPath -UseBasicParsing

            $statusLbl.Text = "Entpacke Update..."
            $splash.Refresh()
            Expand-Archive -Path $zipPath -DestinationPath $tempDir -Force

            $statusLbl.Text = "Installiere Update..."
            $splash.Refresh()

            $targetPath = $script:ScriptPath
            $installScript = Join-Path $tempDir "install.ps1"
            $installContent = @"
Start-Sleep -Seconds 2
try {
    Copy-Item -Path '$($tempDir.Replace("'", "''"))\*' -Destination '$($targetPath.Replace("'", "''"))' -Recurse -Force
} catch {}
Start-Process powershell.exe -ArgumentList '-NoProfile','-ExecutionPolicy','RemoteSigned','-File','$($targetPath.Replace("'", "''"))\jds-secure.ps1','-Mode','GUI'
"@
            Set-Content -Path $installScript -Value $installContent -Encoding UTF8 -Force

            Start-Process powershell.exe -ArgumentList @("-NoProfile", "-ExecutionPolicy", "RemoteSigned", "-WindowStyle", "Hidden", "-File", $installScript)

            $statusLbl.Text = "Update wird installiert. Neustart..."
            $splash.Refresh()
            Start-Sleep -Milliseconds 800
            $splash.Close()
            $splash.Dispose()
            exit
        } catch {
            $statusLbl.Text = "Update fehlgeschlagen - starte aktuelle Version..."
            $splash.Refresh()
            Start-Sleep -Milliseconds 1200
        }
    }

    $splash.Close()
    $splash.Dispose()
}

switch ($Mode) {
    "FullScan" {
        $null = Invoke-FullScan -Config $global:Config
    }
    "VirusScan" {
        $result = Invoke-VirusScan -Config $global:Config -ShowProgress $true -ScanType "full"
        Write-Host ""
        if ($result.status -eq "safe") { $color = "Green" } elseif ($result.status -eq "warn") { $color = "Yellow" } else { $color = "Red" }
        Write-Host "=== Scan-Ergebnisse ===" -ForegroundColor Cyan
        Write-Host "  Status: $($result.status)" -ForegroundColor $color
        Write-Host "  Dateien gescannt: $($result.files_scanned)"
        Write-Host "  Bedrohungen: $($result.threats_found)" -ForegroundColor $(if ($result.threats_found -gt 0) { "Red" } else { "Green" })
        Write-Host "  Verdaectig: $($result.suspicious_found)" -ForegroundColor $(if ($result.suspicious_found -gt 0) { "Yellow" } else { "Green" })
        Write-Host "  Fehler: $($result.errors)"
        Write-Host "  Dauer: $($result.scan_duration_sec)s"
        if ($result.threats_found -gt 0 -or $result.suspicious_found -gt 0) {
            Write-Host "  Details in der Logdatei" -ForegroundColor Yellow
        }
    }
    "Ransomware" {
        $result = Invoke-RansomwareScan -Config $global:Config -ShowProgress $true
        Write-Host ""
        if ($result.status -eq "safe") { $c = "Green" } elseif ($result.status -eq "warn") { $c = "Yellow" } else { $c = "Red" }
        Write-Host "=== Scan-Ergebnisse ===" -ForegroundColor Cyan
        Write-Host "  Status: $($result.status)" -ForegroundColor $c
        Write-Host "  Dateien gescannt: $($result.files_scanned)"
        Write-Host "  Groesse geprueft: $($result.total_size_mb) MB"
        Write-Host "  Verdaectige Funde: $($result.suspicious_findings)" -ForegroundColor $(if ($result.suspicious_findings -gt 0) { "Yellow" } else { "Green" })
        Write-Host "  Alarme: $($result.alerts_triggered)" -ForegroundColor $(if ($result.alerts_triggered -gt 0) { "Red" } else { "Green" })
        Write-Host "  Dauer: $($result.scan_duration_sec)s"
    }
    "Vulnerability" {
        $result = Invoke-VulnerabilityScan -Config $global:Config -ShowProgress $true
        Write-Host ""
        if ($result.status -eq "safe") { $c = "Green" } elseif ($result.status -eq "warn") { $c = "Yellow" } else { $c = "Red" }
        Write-Host "=== Scan-Ergebnisse ===" -ForegroundColor Cyan
        Write-Host "  Status: $($result.status)" -ForegroundColor $c
        Write-Host "  Funde gesamt: $($result.total_findings)"
        Write-Host "  Kritisch: $($result.critical)" -ForegroundColor $(if ($result.critical -gt 0) { "Red" } else { "Green" })
        Write-Host "  Warnungen: $($result.warnings)" -ForegroundColor $(if ($result.warnings -gt 0) { "Yellow" } else { "Green" })
        Write-Host "  Info: $($result.info)"
        Write-Host "  Dauer: $($result.scan_duration_sec)s"
    }
    "Firewall" {
        $null = Invoke-FirewallHardening -Config $global:Config
        $null = Invoke-FirewallScan -Config $global:Config
    }
    "IDS" {
        $null = Invoke-IDSMonitor -Config $global:Config
    }
    "Network" {
        $result = Invoke-NetworkSecurityScan -Config $global:Config -ShowProgress $true
        Write-Host ""
        if ($result.status -eq "safe") { $c = "Green" } elseif ($result.status -eq "warn") { $c = "Yellow" } else { $c = "Red" }
        Write-Host "=== Scan-Ergebnisse ===" -ForegroundColor Cyan
        Write-Host "  Status: $($result.status)" -ForegroundColor $c
        Write-Host "  Offene Ports: $($result.open_ports)" -ForegroundColor $(if ($result.open_ports -gt 0) { "Yellow" } else { "Green" })
        Write-Host "  Lauschende Dienste: $($result.listening_services)"
        Write-Host "  Verdaectige Verbindungen: $($result.suspicious_connections)" -ForegroundColor $(if ($result.suspicious_connections -gt 0) { "Red" } else { "Green" })
        Write-Host "  Freigaben: $($result.network_shares)"
        Write-Host "  Firewall-Regeln: $($result.firewall_rules)"
        Write-Host "  Dauer: $($result.scan_duration_sec)s"
    }
    "Process" {
        $result = Invoke-ProcessAudit -Config $global:Config -ShowProgress $true
        Write-Host ""
        if ($result.status -eq "safe") { $c = "Green" } elseif ($result.status -eq "warn") { $c = "Yellow" } else { $c = "Red" }
        Write-Host "=== Scan-Ergebnisse ===" -ForegroundColor Cyan
        Write-Host "  Status: $($result.status)" -ForegroundColor $c
        Write-Host "  Prozesse gesamt: $($result.total_processes)"
        Write-Host "  Blacklisted: $($result.blacklisted)" -ForegroundColor $(if ($result.blacklisted -gt 0) { "Red" } else { "Green" })
        Write-Host "  Verdaectig: $($result.suspicious)" -ForegroundColor $(if ($result.suspicious -gt 0) { "Yellow" } else { "Green" })
        Write-Host "  Hohe Ressourcen: $($result.high_resource)"
        Write-Host "  Dauer: $($result.scan_duration_sec)s"
    }
    "Integrity" {
        $result = Invoke-IntegrityCheck -Config $global:Config -ShowProgress $true
        Write-Host ""
        if ($result.status -eq "safe") { $c = "Green" } elseif ($result.status -eq "warn") { $c = "Yellow" } else { $c = "Red" }
        Write-Host "=== Scan-Ergebnisse ===" -ForegroundColor Cyan
        Write-Host "  Status: $($result.status)" -ForegroundColor $c
        Write-Host "  Geprueft: $($result.checked)"
        Write-Host "  Aenderungen: $($result.changes)" -ForegroundColor $(if ($result.changes -gt 0) { "Yellow" } else { "Green" })
        Write-Host "  Kritisch: $($result.critical)" -ForegroundColor $(if ($result.critical -gt 0) { "Red" } else { "Green" })
        Write-Host "  Neue Dateien: $($result.new_files)"
        Write-Host "  Geloscht: $($result.deleted_files)"
        Write-Host "  Dauer: $($result.scan_duration_sec)s"
    }
    "Encryption" {
        $null = Invoke-DataEncryption -Config $global:Config
    }
    "Honeypot" {
        $null = Invoke-HoneypotSetup -Config $global:Config
        $null = Invoke-HoneypotMonitor -Config $global:Config
    }
    "USB" {
        $null = Test-USBSecurity -Config $global:Config
    }
    "SelfDefense" {
        $null = Invoke-SelfDefenseCheck -Config $global:Config -ShowProgress $false
    }
    "Audit" {
        $null = Initialize-JDSAudit -Config $global:Config
        $null = Invoke-JDSAuditScan -Config $global:Config
    }
    "Quarantine" {
        Get-QuarantineSummary -Config $global:Config | Format-List | Out-Host
        Get-QuarantineList -Config $global:Config | Format-Table | Out-Host
    }
    "Incident" {
        $null = Test-IncidentResponse -Config $global:Config
    }
    "GDPR" {
        Get-GDPRBreachSummary -Config $global:Config | Format-List | Out-Host
        Test-GDPRRetentionPolicies -Config $global:Config | Format-List | Out-Host
    }
    "GUI" {
        try { Invoke-JDSMandatoryUpdateCheck } catch { Write-Host "  [WARN] Update-Check uebersprungen: $_" -ForegroundColor Yellow }
        if ($NoGUI) { Show-MainMenu -Config $global:Config }
        else {
            try {
                Show-JDSGUI -Config $global:Config
            } catch {
                Write-Host "`n  ================ GUI-FEHLER ================" -ForegroundColor Red
                Write-Host "  $_" -ForegroundColor Red
                Write-Host "  ===========================================" -ForegroundColor Red
                Write-Host "`n  Bitte diesen Fehler an Joel Digitals melden." -ForegroundColor Yellow
                Write-Host "  Druecke Enter um ins Konsolen-Menue zu wechseln..." -ForegroundColor Gray
                $null = Read-Host
                Show-MainMenu -Config $global:Config
            }
        }
    }
    "Interactive" {
        try { Invoke-JDSMandatoryUpdateCheck } catch { Write-Host "  [WARN] Update-Check uebersprungen: $_" -ForegroundColor Yellow }
        Show-MainMenu -Config $global:Config
    }
    "Service" {
        Start-ServiceMode -Config $global:Config
    }
    "QuickScan" {
        $scanResult = Invoke-FullScan -Config $global:Config -ShowProgress $false
        Invoke-RansomwareScan -Config $global:Config | Out-Null
        Invoke-ProcessAudit -Config $global:Config | Out-Null
        Invoke-NetworkSecurityScan -Config $global:Config | Out-Null
        Invoke-VulnerabilityScan -Config $global:Config | Out-Null
        Invoke-SelfDefenseCheck -Config $global:Config | Out-Null
        Invoke-AutoRespond -Config $global:Config -ScanResults $scanResult
        Write-Host "  QuickScan completed." -ForegroundColor Green
    }
    "Backup" {
        $result = Invoke-BackupSystem -Config $global:Config
        if ($result) { Write-Host "  Backup completed." -ForegroundColor Green }
        else { Write-Host "  Backup failed." -ForegroundColor Red }
    }
    "Cleanup" {
        Invoke-BackupCleanup -Config $global:Config
        Write-Host "  Cleanup completed." -ForegroundColor Green
    }
    "Report" {
        Export-SecurityReport -Config $global:Config
    }
}
} # Ende JDSSkipEntry-Guard
#endregion
