﻿function Initialize-Quarantine {
    param([hashtable]$Config)
    $cfg = $Config.quarantine
    if (-not $cfg.enabled) { return }

    $quarantinePath = if ($cfg.path) { $cfg.path } else { Join-Path $Config.general.data_path "quarantine" }
    if (-not (Test-Path $quarantinePath)) {
        New-Item -ItemType Directory -Path $quarantinePath -Force | Out-Null
    }

    $logPath = Join-Path $quarantinePath "quarantine-log.json"
    $script:QuarantineLog = @()
    if (Test-Path $logPath) {
        try { $script:QuarantineLog = Get-Content $logPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { }
    }
    if (-not $script:QuarantineLog -or $script:QuarantineLog -isnot [array]) { $script:QuarantineLog = @() }

    $script:QuarantinePath = $quarantinePath
    $script:QuarantineLogPath = $logPath

    return @{ path = $quarantinePath; stored = $script:QuarantineLog.Count }
}

function Move-ToQuarantine {
    param(
        [hashtable]$Config,
        [string]$FilePath,
        [string]$Reason = "Unbekannt",
        [string]$Severity = "warn",
        [string]$Source = "manual"
    )
    $cfg = $Config.quarantine
    if (-not $cfg.enabled) { return @{ success = $false; reason = "Quarantaene deaktiviert" } }
    if (-not (Test-Path $FilePath)) { return @{ success = $false; reason = "Datei nicht gefunden" } }

    $quarantinePath = if ($script:QuarantinePath) { $script:QuarantinePath } else { Join-Path $Config.general.data_path "quarantine" }

    $fileItem = Get-Item $FilePath
    $fileHash = $null
    try {
        $stream = [System.IO.File]::OpenRead($FilePath)
        $sha256 = [System.Security.Cryptography.SHA256]::Create()
        $hashBytes = $sha256.ComputeHash($stream)
        $stream.Close()
        $fileHash = [BitConverter]::ToString($hashBytes) -replace '-', ''
    } catch { }

    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $safeName = [System.IO.Path]::GetFileNameWithoutExtension($fileItem.Name) -replace '[^a-zA-Z0-9_\-\.]', '_'
    $quarantineFileName = "${timestamp}_${safeName}.${timestamp}.quarantine"
    $quarantineFilePath = Join-Path $quarantinePath $quarantineFileName

    try {
        $acl = Get-Acl -Path $FilePath -ErrorAction SilentlyContinue
        $originalPerms = if ($acl) { $acl.Sddl } else { "" }

        Move-Item -Path $FilePath -Destination $quarantineFilePath -Force -ErrorAction Stop

        try {
            $qAcl = Get-Acl -Path $quarantineFilePath -ErrorAction SilentlyContinue
            $qAcl.SetAccessRuleProtection($true, $false)
            $everyone = [System.Security.Principal.NTAccount]::new("Everyone")
            $denyRule = New-Object System.Security.AccessControl.FileSystemAccessRule($everyone, "ExecuteFile", "Deny")
            $qAcl.AddAccessRule($denyRule)
            Set-Acl -Path $quarantineFilePath -AclObject $qAcl -ErrorAction SilentlyContinue
        } catch { }

        $record = @{
            id = [System.Guid]::NewGuid().ToString("N").Substring(0, 12)
            original_path = $fileItem.FullName
            quarantined_path = $quarantineFilePath
            quarantine_date = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
            file_name = $fileItem.Name
            file_size = $fileItem.Length
            file_hash = $fileHash
            reason = $Reason
            severity = $Severity
            source = $Source
            original_permissions = $originalPerms
            restored = $false
            restored_date = $null
        }

        $script:QuarantineLog += $record
        Save-QuarantineLog
        Write-JDSLog "CRITICAL" "QUARANTAENE: $($fileItem.Name) isoliert - $Reason (Quelle: $Source)"

        return @{ success = $true; quarantine_id = $record.id; quarantined_path = $quarantineFilePath }
    } catch {
        Write-JDSLog "ERROR" "QUARANTAENE: Fehler beim Isolieren von $FilePath : $_"
        return @{ success = $false; reason = "$_" }
    }
}

function Restore-QuarantineItem {
    param(
        [hashtable]$Config,
        [string]$QuarantineId
    )
    $cfg = $Config.quarantine
    if (-not $cfg.enabled) { return @{ success = $false; reason = "Quarantaene deaktiviert" } }

    $record = $script:QuarantineLog | Where-Object { $_.id -eq $QuarantineId -and -not $_.restored }
    if (-not $record) { return @{ success = $false; reason = "Eintrag nicht gefunden oder bereits wiederhergestellt" } }

    if (-not (Test-Path $record.quarantined_path)) { return @{ success = $false; reason = "Quarantaene-Datei nicht mehr vorhanden" } }

    try {
        $restorePath = $record.original_path
        $restoreDir = Split-Path $restorePath -Parent
        if (-not (Test-Path $restoreDir)) { New-Item -ItemType Directory -Path $restoreDir -Force | Out-Null }

        if (Test-Path $restorePath) {
            $backupPath = "${restorePath}.${(Get-Date -Format 'yyyyMMdd_HHmmss')}.backup"
            Move-Item -Path $restorePath -Destination $backupPath -Force
        }

        Move-Item -Path $record.quarantined_path -Destination $restorePath -Force

        if ($record.original_permissions) {
            try {
                $newAcl = Get-Acl -Path $restorePath -ErrorAction SilentlyContinue
                $newAcl.SetSecurityDescriptorSddlForm($record.original_permissions)
                Set-Acl -Path $restorePath -AclObject $newAcl -ErrorAction SilentlyContinue
            } catch { }
        }

        $record.restored = $true
        $record.restored_date = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        Save-QuarantineLog
        Write-JDSLog "INFO" "QUARANTAENE: $($record.file_name) wiederhergestellt"

        return @{ success = $true; restored_path = $restorePath }
    } catch {
        Write-JDSLog "ERROR" "QUARANTAENE: Fehler bei Wiederherstellung: $_"
        return @{ success = $false; reason = "$_" }
    }
}

function Get-QuarantineList {
    param([hashtable]$Config)
    if (-not $script:QuarantineLog) { return @() }
    return $script:QuarantineLog | Sort-Object -Property quarantine_date -Descending
}

function Get-QuarantineSummary {
    param([hashtable]$Config)
    if (-not $script:QuarantineLog) { return @{ total = 0; active = 0; restored = 0 } }
    $total = $script:QuarantineLog.Count
    $active = ($script:QuarantineLog | Where-Object { -not $_.restored }).Count
    $restored = ($script:QuarantineLog | Where-Object { $_.restored }).Count
    $size = 0
    foreach ($r in $script:QuarantineLog) {
        if (Test-Path $r.quarantined_path) { try { $size += (Get-Item $r.quarantined_path).Length } catch { } }
    }
    return @{ total = $total; active = $active; restored = $restored; total_size_mb = [Math]::Round($size / 1MB, 2) }
}

function Clear-Quarantine {
    param(
        [hashtable]$Config,
        [int]$OlderThanDays = 90
    )
    $cfg = $Config.quarantine
    if (-not $cfg.enabled) { return @{ deleted = 0 } }

    $cutoff = (Get-Date).AddDays(-$OlderThanDays)
    $toDelete = $script:QuarantineLog | Where-Object { $_.restored -and [DateTime]::ParseExact($_.restored_date, "yyyy-MM-dd HH:mm:ss", $null) -lt $cutoff }
    $deleted = 0
    foreach ($rec in $toDelete) {
        if (Test-Path $rec.quarantined_path) {
            try { Remove-Item -Path $rec.quarantined_path -Force -ErrorAction SilentlyContinue; $deleted++ } catch { }
        }
    }
    $script:QuarantineLog = $script:QuarantineLog | Where-Object { $_.id -notin ($toDelete.id) }
    Save-QuarantineLog
    Write-JDSLog "INFO" "QUARANTAENE: $deleted alte Quarantaene-Dateien bereinigt (aetter als ${OlderThanDays}Tage)"
    return @{ deleted = $deleted }
}

function Save-QuarantineLog {
    $logPath = if ($script:QuarantineLogPath) { $script:QuarantineLogPath } else { Join-Path $script:QuarantinePath "quarantine-log.json" }
    $script:QuarantineLog | ConvertTo-Json -Depth 5 | Set-Content -Path $logPath -Encoding UTF8 -Force
}

function Start-QuarantineCleanupService {
    param([hashtable]$Config)
    $cfg = $Config.quarantine
    if (-not $cfg.enabled) { return }
    $retentionDays = if ($cfg.retention_days) { $cfg.retention_days } else { 90 }
    while ($true) {
        Start-Sleep -Seconds 86400
        $null = Clear-Quarantine -Config $Config -OlderThanDays $retentionDays
    }
}
