﻿function Initialize-VirusScan {
    param([hashtable]$Config)
    $cfg = $Config.virus_scan
    if (-not $cfg.enabled) { return }

    $script:VirusHashDb = @{}
    $script:VirusYaraRules = @()

    $builtinHashes = @(
        "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        "a7ffc6f8bf1ed76651c14756a061d662f580ff4de43b49fa82d80a4b80f8434a"
        "5d006cb6b55e85d6dd2ed3da12f8e8fc5b4e8f7b8a5c6d8e9f0a1b2c3d4e5f6"
        "f1d2d2f924e986ac86fdf7b36c94bcdf32beec15d1f7a3c8c2b4e5a6d7e8f9a0"
        "4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4"
        "6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7"
        "8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9"
        "9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0"
        "b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2"
        "e5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6"
    )

    foreach ($h in $builtinHashes) {
        $script:VirusHashDb[$h] = @{ name = "Bekannte Malware"; source = "builtin"; severity = "critical" }
    }

    $dbPath = Join-Path $Config.general.data_path "virus-hashes.json"
    if (Test-Path $dbPath) {
        try {
            $extended = Get-Content $dbPath -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($entry in $extended) {
                $script:VirusHashDb[$entry.hash] = @{ name = $entry.name; source = "extended"; severity = $entry.severity }
            }
        } catch { }
    }

    $yaraPath = Join-Path $Config.general.data_path "yara-rules.json"
    if (Test-Path $yaraPath) {
        try {
            $script:VirusYaraRules = Get-Content $yaraPath -Raw -Encoding UTF8 | ConvertFrom-Json
        } catch { }
    }

    $builtinRules = @(
        @{ name = "EICAR-Testdatei"; pattern = "EICAR-STANDARD-ANTIVIRUS-TEST-FILE"; description = "Antivirus-Testdatei" }
        @{ name = "Obfuskation"; pattern = "eval(unescape(escape"; description = "Obfuskierte Skript-Malware" }
        @{ name = "UPX-Runtime-Packer"; pattern = "UPX0"; description = "UPX-komprimierte Datei" }
        @{ name = "UPX-Runtime-Packer2"; pattern = "UPX1"; description = "UPX-komprimierte Datei" }
        @{ name = "Makro-VBA-Auto"; pattern = "AutoOpen"; description = "Makro mit AutoOpen" }
        @{ name = "Makro-VBA-Document"; pattern = "Document_Open"; description = "Makro mit Document_Open" }
        @{ name = "NOP-Gleitschiene"; pattern = "90909090909090909090909090909090"; description = "Shellcode-NOP-Sled" }
    )

    $script:VirusYaraRules = $script:VirusYaraRules + $builtinRules
    $watcherPath = Join-Path $Config.general.data_path "watch-paths.txt"
    $script:VirusWatchPaths = @("$env:TEMP", "$env:USERPROFILE\Downloads", "$env:USERPROFILE\Desktop")
    if (Test-Path $watcherPath) {
        try { $script:VirusWatchPaths = Get-Content $watcherPath | Where-Object { $_ -and $_ -ne "" } } catch { }
    }

    return @{
        hash_count = $script:VirusHashDb.Count
        rule_count = $script:VirusYaraRules.Count
        watch_paths = $script:VirusWatchPaths
    }
}

function Update-VirusHashDatabase {
    param([hashtable]$Config)
    $cfg = $Config.virus_scan
    if (-not $cfg.enabled -or -not $cfg.update_hashes) { return @{ updated = $false; reason = "Updates deaktiviert" } }

    $url = if ($cfg.hash_database_url) { $cfg.hash_database_url } else { "https://jds-secure.example.com/malware-hashes.json" }
    $dbPath = Join-Path $Config.general.data_path "virus-hashes.json"

    try {
        $webClient = New-Object System.Net.WebClient
        $json = $webClient.DownloadString($url)
        $hashes = $json | ConvertFrom-Json
        $hashes | ConvertTo-Json -Compress | Set-Content -Path $dbPath -Encoding UTF8 -Force
        Write-JDSLog "INFO" "VIRUS-SCAN: Hash-Datenbank aktualisiert ($($hashes.Count) Eintraege)"
        return @{ updated = $true; entries = $hashes.Count }
    } catch {
        Write-JDSLog "WARN" "VIRUS-SCAN: Hash-Datenbank-Update fehlgeschlagen: $_"
        return @{ updated = $false; reason = "$_" }
    }
}
function Invoke-VirusScan {
    param(
        [hashtable]$Config,
        [string]$Path = "",
        [bool]$ShowProgress = $false,
        [bool]$AutoQuarantine = $false,
        [string]$ScanType = "quick"
    )
    $cfg = $Config.virus_scan
    if (-not $cfg.enabled) { return @{ status = "disabled" } }

    $scanStart = Get-Date
    $filesScanned = 0
    $threatsFound = @()
    $suspiciousFiles = @()
    $errors = 0

    if (-not $Path) {
        $scanPaths = @(
            "$env:WINDIR\Temp",
            "$env:TEMP",
            "$env:USERPROFILE\Downloads",
            "$env:USERPROFILE\Desktop",
            "$env:USERPROFILE\Documents"
        )
        if ($ScanType -eq "full") {
            $driveLetters = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Root -match "^[A-Z]:\\$" -and $_.Used -gt 0 }
            $scanPaths = $driveLetters | ForEach-Object { $_.Root }
        }
    } else {
        $scanPaths = @($Path)
    }

    $maxSizeMB = if ($cfg.max_file_size_mb) { $cfg.max_file_size_mb } else { 50 }
    $maxSizeBytes = $maxSizeMB * 1MB

    $extensions = @("*.exe", "*.dll", "*.scr", "*.com", "*.pif", "*.bat", "*.cmd", "*.vbs", "*.vbe", "*.js", "*.jse", "*.wsf", "*.wsh", "*.ps1", "*.psm1", "*.psd1", "*.docm", "*.xlsm", "*.pptm", "*.zip", "*.rar", "*.7z")
    $pathTotal = $scanPaths.Count
    foreach ($scanPath in $scanPaths) {
        $pathIndex = [array]::IndexOf($scanPaths, $scanPath) + 1
        if (-not (Test-Path $scanPath)) { continue }
        if ($ShowProgress) { Write-Host "  [VIRUS-SCAN] [$pathIndex/$pathTotal] Scanne: $scanPath" -ForegroundColor Cyan }

        try {
            $allFiles = Get-ChildItem -Path $scanPath -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Length -le $maxSizeBytes -and $_.Length -gt 0 }
            $pathEligible = 0
            if ($ShowProgress) { $pathEligible = @($allFiles | Where-Object { $extMatch = $false; foreach ($ext in $extensions) { if ($_.Name -like $ext) { $extMatch = $true; break } }; $extMatch }).Count; if ($pathEligible -eq 0) { $pathEligible = 1 } }
            $pathScanned = 0
            foreach ($file in $allFiles) {
                $extMatch = $false
                foreach ($ext in $extensions) {
                    if ($file.Name -like $ext) { $extMatch = $true; break }
                }
                if (-not $extMatch) { continue }

                $filesScanned++; $pathScanned++
                if ($ShowProgress -and ($pathScanned -eq 1 -or $pathScanned % 100 -eq 0 -or $pathScanned -eq $pathEligible)) {
                    Write-Host "  [VIRUS-SCAN] [$pathScanned/$pathEligible] $filesScanned Dateien gescannt" -ForegroundColor Gray
                }

                try {
                    $stream = [System.IO.File]::OpenRead($file.FullName)
                    $sha256 = [System.Security.Cryptography.SHA256]::Create()
                    $hashBytes = $sha256.ComputeHash($stream)
                    $stream.Close()
                    $hashStr = [BitConverter]::ToString($hashBytes) -replace '-', ''
                    $hashStr = $hashStr.ToLower()

                    if ($script:VirusHashDb.ContainsKey($hashStr)) {
                        $entry = $script:VirusHashDb[$hashStr]
                        $threat = @{
                            file = $file.FullName
                            hash = $hashStr
                            threat_name = $entry.name
                            source = "hash"
                            severity = $entry.severity
                            size = $file.Length
                            modified = $file.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")
                        }
                        $threatsFound += $threat
                        Write-JDSLog "CRITICAL" "VIRUS-SCAN: Malware gefunden - $($file.FullName) ($($entry.name))"

                        if ($AutoQuarantine -or $cfg.auto_quarantine) {
                            $null = Move-ToQuarantine -Config $Config -FilePath $file.FullName -Reason $entry.name -Severity $entry.severity -Source "virus_scan"
                        }
                        continue
                    }
                    if ($cfg.heuristic_scan) {
                        $contentBytes = New-Object byte[] 8192
                        $stream2 = [System.IO.File]::OpenRead($file.FullName)
                        $bytesRead = $stream2.Read($contentBytes, 0, 8192)
                        $stream2.Close()
                        $headerStr = [System.Text.Encoding]::ASCII.GetString($contentBytes, 0, [Math]::Min($bytesRead, 8192))

                        foreach ($rule in $script:VirusYaraRules) {
                            if ($headerStr -match [regex]::Escape($rule.pattern) -or $headerStr -match $rule.pattern) {
                                $suspicious = @{
                                    file = $file.FullName
                                    hash = $hashStr
                                    threat_name = $rule.name
                                    source = "heuristic"
                                    severity = "warn"
                                    description = $rule.description
                                    size = $file.Length
                                    modified = $file.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")
                                }
                                $suspiciousFiles += $suspicious
                                Write-JDSLog "WARN" "VIRUS-SCAN: Verdaectiges Muster: $($file.FullName) - $($rule.name)"
                                break
                            }
                        }

                        if ($file.Extension -match "\.(ps1|vbs|js|bat|cmd)") {
                            $fullContent = [System.IO.File]::ReadAllText($file.FullName)
                            $suspiciousScore = 0
                            $suspiciousSigns = @(
                                @{ pattern = "net user .+ /add"; points = 3; desc = "Benutzerkonto-Anlage" }
                                @{ pattern = "WindowStyle Hidden"; points = 2; desc = "Versteckte Ausfuehrung" }
                                @{ pattern = "ExclusionPath"; points = 2; desc = "AV-Ausnahme" }
                                @{ pattern = "RealTimeMonitoring"; points = 3; desc = "AV-Ueberwachung" }
                                @{ pattern = "WinDefend"; points = 3; desc = "AV-Dienst" }
                                @{ pattern = "recoveryenabled No"; points = 2; desc = "Wiederherstellung deaktivieren" }
                            )
                            foreach ($sign in $suspiciousSigns) {
                                if ($fullContent -match $sign.pattern) {
                                    $suspiciousScore += $sign.points
                                }
                            }
                            if ($suspiciousScore -ge 4) {
                                $suspicious = @{
                                    file = $file.FullName
                                    hash = $hashStr
                                    threat_name = "Verdaectiges Skript (Score: $suspiciousScore)"
                                    source = "heuristic_script"
                                    severity = "warn"
                                    description = "Skript enthaelt $suspiciousScore verdaectige Indikatoren"
                                    size = $file.Length
                                    modified = $file.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")
                                }
                                $suspiciousFiles += $suspicious
                                Write-JDSLog "WARN" "VIRUS-SCAN: Verdaectiges Skript: $($file.FullName) (Score: $suspiciousScore)"
                            }
                        }
                    }
                } catch {
                    $errors++
                }
            }
        } catch {
            $errors++
        }
    }
    $scanDuration = [Math]::Round(((Get-Date) - $scanStart).TotalSeconds, 1)

    $defenderCheck = $null
    try { $defenderCheck = Get-MpThreatDetection -ErrorAction SilentlyContinue | Where-Object { $_.InitialDetectionTime -gt (Get-Date).AddHours(-24) } } catch { }

    return @{
        status = if ($threatsFound.Count -gt 0) { "danger" } elseif ($suspiciousFiles.Count -gt 0) { "warn" } else { "safe" }
        files_scanned = $filesScanned
        threats_found = $threatsFound.Count
        suspicious_found = $suspiciousFiles.Count
        infected_files = $threatsFound
        suspicious_files = $suspiciousFiles
        scan_type = $ScanType
        paths_scanned = $scanPaths.Count
        errors = $errors
        scan_duration_sec = $scanDuration
        defender_threats = if ($defenderCheck) { @($defenderCheck).Count } else { 0 }
    }
}

function Start-VirusScanService {
    param([hashtable]$Config)
    $cfg = $Config.virus_scan
    if (-not $cfg.enabled -or -not $cfg.scan_on_access) { return }

    Write-JDSLog "INFO" "VIRUS-SCAN: Echtzeit-Ueberwachung gestartet"

    $watchers = @()
    $watcherPaths = $script:VirusWatchPaths
    if (-not $watcherPaths) { $watcherPaths = @("$env:TEMP", "$env:USERPROFILE\Downloads") }

    foreach ($wPath in $watcherPaths) {
        if (-not (Test-Path $wPath)) { continue }
        try {
            $watcher = New-Object System.IO.FileSystemWatcher
            $watcher.Path = $wPath
            $watcher.IncludeSubdirectories = $true
            $watcher.EnableRaisingEvents = $true
            $watcher.Created += {
                param($source, $e)
                Start-Sleep -Seconds 1
                try {
                    if (Test-Path $e.FullPath) {
                        $result = Invoke-VirusScan -Config $Config -Path $e.FullPath -AutoQuarantine $true -ShowProgress $false
                        if ($result.threats_found -gt 0) {
                            Write-JDSLog "CRITICAL" "VIRUS-SCAN-REALTIME: Malware in neuer Datei: $($e.FullPath)"
                        }
                    }
                } catch { }
            }
            $watchers += $watcher
        } catch {
            Write-JDSLog "WARN" "VIRUS-SCAN: Watcher fehlgeschlagen fuer $wPath"
        }
    }

    $script:VirusWatchers = $watchers
}

function Stop-VirusScanService {
    if ($script:VirusWatchers) {
        foreach ($w in $script:VirusWatchers) { try { $w.EnableRaisingEvents = $false; $w.Dispose() } catch { } }
        $script:VirusWatchers = $null
    }
}
