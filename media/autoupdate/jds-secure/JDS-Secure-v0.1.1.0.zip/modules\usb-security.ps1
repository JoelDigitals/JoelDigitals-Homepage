﻿function Invoke-USBProtection {
    param([hashtable]$Config)

    $usb = $Config.usb_security
    if (-not $usb.enabled) { Write-JDSLog "WARN" "USB Security module is disabled"; return }

    Write-JDSLog "INFO" "Configuring USB security..."

    try {
        if ($usb.autorun_disabled) {
            $autorunPaths = @(
                "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer",
                "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer"
            )
            foreach ($path in $autorunPaths) {
                if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null }
                Set-ItemProperty -Path $path -Name "NoDriveTypeAutoRun" -Value 0xFF -Type DWord -Force
            }

            Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name "NoAutorun" -Value 1 -Type DWord -Force

            try {
                $service = Get-Service -Name "ShellHWDetection" -ErrorAction SilentlyContinue
                if ($service -and $service.Status -eq "Running") {
                    Stop-Service -Name "ShellHWDetection" -Force -ErrorAction SilentlyContinue
                    Set-Service -Name "ShellHWDetection" -StartupType Disabled -ErrorAction SilentlyContinue
                }
            } catch {}

            Write-JDSLog "INFO" "AutoRun deaktiviert"
        }

        if ($usb.block_usb_storage) {
            $usbStoragePath = "HKLM:\SYSTEM\CurrentControlSet\Services\USBSTOR"
            if (Test-Path $usbStoragePath) {
                Set-ItemProperty -Path $usbStoragePath -Name "Start" -Value 4 -Type DWord -Force
                Write-JDSLog "INFO" "USB-Massenspeicher blockiert (Start=4)"
            }

            $removablePath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices"
            if (-not (Test-Path $removablePath)) { New-Item -Path $removablePath -Force | Out-Null }
            Set-ItemProperty -Path $removablePath -Name "Deny_All" -Value 1 -Type DWord -Force

            Write-JDSLog "INFO" "Wechseldatentraeger blockiert"
        }

        if ($usb.whitelist_mode -and $usb.allowed_usb_devices.Count -gt 0) {
            $devicePath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions"
            if (-not (Test-Path $devicePath)) { New-Item -Path $devicePath -Force | Out-Null }

            Set-ItemProperty -Path $devicePath -Name "DenyDeviceIDs" -Value 1 -Type DWord -Force
            Set-ItemProperty -Path $devicePath -Name "DenyDeviceIDsRetroactive" -Value 1 -Type DWord -Force

            $allowPath = "$devicePath\AllowDeviceIDs"
            if (-not (Test-Path $allowPath)) { New-Item -Path $allowPath -Force | Out-Null }

            $counter = 0
            foreach ($deviceId in $usb.allowed_usb_devices) {
                Set-ItemProperty -Path $allowPath -Name "$counter" -Value $deviceId -Force
                $counter++
            }

            Write-JDSLog "INFO" "USB-Whitelist mit $($usb.allowed_usb_devices.Count) Geraet(en) aktiviert"
        }

        if ($usb.usb_scan_on_connect) {
            $scanScript = @"
`$watcher = New-Object System.Management.ManagementEventWatcher
`$query = "SELECT * FROM Win32_VolumeChangeEvent WHERE EventType = 2"
`$watcher.Query = `$query
`$watcher.Start()

Register-ObjectEvent -InputObject `$watcher -EventName "EventArrived" -Action {
    `$drive = `$Event.SourceEventArgs.NewEvent.DriveName
    `$entry = "[USB-SCAN] $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - New drive detected: `$drive"
    `$entry | Out-File -FilePath "$($PSScriptRoot)\..\logs\usb-scan.log" -Append

    try {
        `$scanResult = & "`$env:WINDIR\System32\MSHTA.exe" "javascript:new ActiveXObject('WScript.Shell').Run('',0,false);close();" 2>`$null
        `$entry2 = "[USB-SCAN] $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - Scanning `$drive"
        `$entry2 | Out-File -FilePath "$($PSScriptRoot)\..\logs\usb-scan.log" -Append
    } catch {
        `$entry3 = "[USB-SCAN] $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - Scan failed: `$_"
        `$entry3 | Out-File -FilePath "$($PSScriptRoot)\..\logs\usb-scan.log" -Append
    }
} | Out-Null
"@
            $scanScriptPath = "$PSScriptRoot\..\tools\usb-scanner.ps1"
            Set-Content -Path $scanScriptPath -Value $scanScript -Force
            Write-JDSLog "INFO" "USB-Scan-on-Connect script created"
        }

        if ($usb.encrypt_usb) {
            $encScript = @"
param([string]`$DriveLetter)

if (-not `$DriveLetter) {
    Write-Host "Usage: .\encrypt-usb.ps1 D (where D is drive letter)"
    exit 1
}

`$drive = "`$DriveLetter`:"
`$bitlockerDrive = Get-BitLockerVolume -MountPoint `$drive -ErrorAction SilentlyContinue

if (-not `$bitlockerDrive) {
    Write-Host "Aktiviere BitLocker auf `$drive..."
    try {
        Enable-BitLocker -MountPoint `$drive -RecoveryPasswordProtector -SkipHardwareTest -UsedSpaceOnly
        Write-Host "BitLocker wurde aktiviert - Recovery-Key wurde gespeichert"
    } catch {
        Write-Host "FEHLER: BitLocker konnte nicht aktiviert werden: `$_"
    }
} elseif (`$bitlockerDrive.ProtectionStatus -eq 0) {
    Write-Host "BitLocker ist auf `$drive deaktiviert - aktiviere..."
    Resume-BitLocker -MountPoint `$drive
} else {
    Write-Host "BitLocker ist bereits auf `$drive aktiv"
}
"@
            $encScriptPath = "$PSScriptRoot\..\tools\encrypt-usb.ps1"
            Set-Content -Path $encScriptPath -Value $encScript -Force
            Write-JDSLog "INFO" "USB-encryption script created"
        }

        Write-JDSLog "INFO" "USB security configuration completed"

        $alerts = @{
            type = "Info"
            title = "USB-Sicherheit aktiv"
            message = "USB-Sicherheitsrichtlinien wurden angewendet"
        }
        Send-JDSAlert $Config $alerts

    } catch {
        Write-JDSLog "ERROR" "USB security configuration failed: $_"
        throw
    }
}

function Test-USBSecurity {
    param([hashtable]$Config)

    Write-JDSLog "INFO" "Testing USB security configuration..."

    $results = @()

    $usbStoragePath = "HKLM:\SYSTEM\CurrentControlSet\Services\USBSTOR"
    if (Test-Path $usbStoragePath) {
        $startValue = Get-ItemProperty -Path $usbStoragePath -Name "Start" -ErrorAction SilentlyContinue
        $results += [PSCustomObject]@{
            Test = "USB Storage Disabled"
            Status = if ($startValue.Start -eq 4) { "Pass" } else { "Fail" }
            Detail = "USBSTOR Start value: $($startValue.Start)"
        }
    }

    $autorunPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer"
    if (Test-Path $autorunPath) {
        $noDriveType = Get-ItemProperty -Path $autorunPath -Name "NoDriveTypeAutoRun" -ErrorAction SilentlyContinue
        $results += [PSCustomObject]@{
            Test = "AutoRun Disabled"
            Status = if ($noDriveType.NoDriveTypeAutoRun -eq 0xFF) { "Pass" } else { "Fail" }
            Detail = "NoDriveTypeAutoRun value: $($noDriveType.NoDriveTypeAutoRun)"
        }
    }

    $results += [PSCustomObject]@{
        Test = "USB Whitelist Mode"
        Status = if ($Config.usb_security.whitelist_mode) { "Pass" } else { "Info" }
        Detail = "Whitelist mode: $($Config.usb_security.whitelist_mode)"
    }

    $results | Format-Table -AutoSize | Out-String | Write-Host

    return $results
}

function Invoke-USBDeploy {
    param(
        [string]$TargetPath,
        [hashtable]$Config
    )

    Write-JDSLog "INFO" "Deploying JDS-Secure to USB drive: $TargetPath"

    try {
        if (-not (Test-Path $TargetPath)) {
            Write-JDSLog "ERROR" "Target path not found: $TargetPath"
            return $false
        }

        $exclude = @("logs\*.log", "backup\*", "*.pdb", "*.tmp")
        $sourcePath = "$PSScriptRoot\.."

        Copy-Item -Path "$sourcePath\*" -Destination $TargetPath -Recurse -Force -Exclude $exclude

        $autorunContent = @"
[autorun]
label=JDS-Secure Enterprise
icon=jds-secure.ico
"@
        Set-Content -Path "$TargetPath\autorun.inf" -Value $autorunContent -Force

        $startupScript = @"
Start-Process PowerShell.exe -ArgumentList '-NoProfile -File ""$TargetPath\jds-secure.ps1"" -Mode Service'
"@
        $startupPath = "$TargetPath\start-jds-secure.ps1"
        Set-Content -Path $startupPath -Value $startupScript -Force

        Write-JDSLog "INFO" "Deployment to USB completed successfully"
        return $true
    } catch {
        Write-JDSLog "ERROR" "USB deployment failed: $_"
        return $false
    }
}


