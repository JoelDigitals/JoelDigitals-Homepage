# JDS Secure - Administrator-Handbuch

**Version 2.0 | Umfassendes Sicherheitssystem fur KMU**

---

## Inhaltsverzeichnis

1. [Architektur](#1-architektur)
2. [Konfiguration](#2-konfiguration)
3. [Backup-System](#3-backup-system)
4. [Server-Betrieb](#4-server-betrieb)
5. [Sicherheitsmodule](#5-sicherheitsmodule)
6. [Monitoring & Alarme](#6-monitoring--alarme)
7. [Wartung](#7-wartung)
8. [Notfall-Wiederherstellung](#8-notfall-wiederherstellung)
9. [Anhang: Port-Referenz](#9-anhang-port-referenz)

---

## 1. Architektur

### 1.1 Systemaufbau

```
                    +------------------+
                    |   JDS Secure     |
                    |   GUI/Console    |
                    +--------+---------+
                             |
              +--------------+--------------+
              |              |              |
     +--------v-------+  +--v--------+  +--v--------+
     |  Service-Modus |  |  Tasks    |  |  Manuell  |
     |  (Windows      |  |  (Scheduled|  |  (USB/    |
     |   Dienst)      |  |   Tasks)  |  |   CLI)    |
     +--------+-------+  +-----+-----+  +-----+-----+
              |                 |              |
     +--------v-----------------v--------------v------+
|              Module-Schicht (12 Module)        |
|  Firewall | IDS | Encryption | Backup | Audit |
|  Honeypot | USB-Security | Alerting           |
|  Ransomware | File-Integrity | Process-Sec    |
|  Network-Security | Vulnerability-Scan        |
     +-------------------+---------------------------+
                          |
     +--------------------v--------------------------+
     |           Windows-System-Schicht               |
     |  Firewall | EventLog | Registry | Services    |
     |  BitLocker | EFS | FileSystem | ScheduledTasks |
     +------------------------------------------------+
```

### 1.2 Datenflusse

```
Kundendaten (C:\CustomerData)
    |
    +--> [Verschlusselung] --> Geschutzte Daten
    |
    +--> [Backup] --> Verschlusseltes ZIP --> Ziel (D:\JDS-Backup)
    |
    +--> [Audit] --> Zugriffsprotokoll --> Log-Datei

Sicherheitsereignisse
    |
    +--> [IDS] --> Bedrohung erkannt? --> Alarm (Email/Popup/Log)
    |
    +--> [Firewall] --> Angriff erkannt? --> Blockieren + Log
    |
    +--> [Honeypot] --> Zugriff auf Fake-Daten? --> Alarm
```

---

## 2. Konfiguration

### 2.1 Konfigurationsdatei

Die zentrale Konfiguration erfolgt uber `config/security-config.json`:

```json
{
    "general": {
        "server_mode": true,
        "install_path": "C:\\Program Files\\JDS-Secure",
        "data_path": "C:\\ProgramData\\JDS-Secure"
    },
    "backup": {
        "schedule": "daily",
        "time": "02:00",
        "retention_days": 30,
        "destinations": {
            "primary": {
                "type": "external_drive",
                "path": "D:\\JDS-Backup",
                "encrypted": true
            }
        }
    }
}
```

### 2.2 Konfiguration uber GUI

Das GUI bietet unter "Einstellungen" einen einfachen Schalter fur jedes Modul. Fur erweiterte Einstellungen muss die JSON-Datei direkt bearbeitet werden.

### 2.3 Konfiguration uber PowerShell

```powershell
# Backup-Ziel andern
$config = Get-Content config\security-config.json -Raw | ConvertFrom-Json
$config.backup.destinations.primary.path = "E:\JDS-Backup"
$config | ConvertTo-Json -Depth 10 | Set-Content config\security-config.json -Encoding UTF8
```

---

## 3. Backup-System

### 3.1 Backup-Ziele

Das System unterstutzt mehrere Ziele parallel:

| Zieltyp | Pfad | Merkmale |
|---------|------|----------|
| Externe Festplatte | `D:\JDS-Backup` | Auto-Erkennung, BitLocker |
| USB-Stick | `E:\JDS-Backup` | Auto-Erkennung, portabel |
| Netzwerkfreigabe | `\\NAS\Backup\JDS` | SMB 3.0+, Domain-Anmeldung |
| Zweite Platte | `F:\JDS-Backup` | Intern, schnell |
| Benutzerdefiniert | Frei wahlbar | Maximale Flexibilitat |

### 3.2 Backup-Rotation

Die Rotation sorgt fur eine effiziente Speichernutzung:

```
Tag 1-7:  Tagliche Backups (7 Stuck)
Woche 1-4: Wochenliche Backups (4 Stuck)
Monat 1-3: Monatliche Backups (3 Stuck)
Jahr 1:    Jahrliche Backups (1 Stuck)
```

Die Rotation wird automatisch bei jedem Backup durchgefuhrt.

### 3.3 Backup-Uberwachung

Das System uberwacht regelmasig:

- **Erfolg/Misserfolg** des letzten Backups
- **Speicherplatz** auf dem Ziel-Laufwerk (Warnung bei <10 GB frei)
- **Planmassigkeit** (Alert bei verpasstem Backup)
- **Integritat** der Backup-Dateien (SHA256-Prufung)

### 3.4 Wiederherstellung

```powershell
# Backup-Liste anzeigen
Get-ChildItem D:\JDS-Backup -Directory | Sort-Object CreationTime -Descending

# Backup wiederherstellen
Restore-Backup -BackupPath "D:\JDS-Backup\JDS-Backup_2026-06-11_02-00-00"

# Einzelfile wiederherstellen
Expand-Archive -Path "D:\JDS-Backup\...\CustomerData.zip" -DestinationPath "C:\Restore"
```

---

## 4. Server-Betrieb

### 4.1 Windows-Dienst

Der Dienst `JDSSecure` lauft mit folgenden Eigenschaften:

| Eigenschaft | Wert |
|-------------|------|
| Name | JDSSecure |
| Anzeigename | JDS Secure Security Suite |
| Starttyp | Automatisch |
| Ausfuhren als | Lokales System |
| Wiederherstellung | Neustart nach 1 Min / 2 Min |

**Logging:** Der Dienst schreibt in das Windows-Ereignisprotokoll unter "JDS-Secure" und in `logs\service.log`.

### 4.2 Geplante Tasks

| Task | Zeitplan | Aktion |
|------|----------|--------|
| JDS-Secure-Scan | Standlich | Sicherheitsscan |
| JDS-Secure-Backup | Taglich 02:00 | Backup aller Daten |
| JDS-Secure-Cleanup | Sonntags 03:00 | Log-Rotation, Backup-Bereinigung |

### 4.3 Server-spezifische Hartung

Bei Server-Installation werden zusatzlich folgende Massnahmen durchgefuhrt:

1. **Windows-Firewall:** Alle Profile auf `blockinbound,allowoutbound`
2. **RDP-Schutz:** Brute-Force-Erkennung (5 Fehlversuche = Sperre)
3. **USB-Sperre:** Wechseldatentrager blockiert (optional)
4. **Audit-Policen:** Erweiterte Uberwachung aktiviert
5. **Scheduled Tasks:** Nur signierte Tasks erlaubt

### 4.4 Event Log Nutzung

Das System nutzt ein eigenes Event Log (`JDS-Secure`) fur:

- **Information:** Dienst gestartet/gestoppt, Backup erfolgreich, Scan durchgefuhrt
- **Warnung:** Wenig Speicherplatz, Konfigurationsfehler, Ubersprungene Tasks
- **Fehler:** Backup fehlgeschlagen, Dienstabsturz, Sicherheitsvorfall

---

## 5. Sicherheitsmodule

### 5.1 Firewall-Modul

```powershell
# Firewall hartung durchfuhren
Invoke-FirewallHardening -Config $Config

# Offene Ports scannen
Invoke-FirewallScan -Config $Config

# Firewall zurucksetzen
Invoke-FirewallReset
```

**Erkannte Angriffe:**
- Port-Scans auf ungewohnlichen Ports
- Brute-Force auf RDP (5+ Fehlversuche in 15 Min)
- Nicht autorisierte ausgehende Verbindungen
- Neue Firewall-Regeln (unerwartet)

### 5.2 Intrusion Detection (IDS)

```powershell
# Manuellen IDS-Scan starten
Invoke-IDSMonitor -Config $Config

# Kontinuierliche Uberwachung starten
Invoke-IDSContinuous -Config $Config -Interval 30
```

**Uberwachte Indikatoren:**
- Bekannte Hackertools (Mimikatz, Nmap, SQLmap, Hydra, etc.)
- Verdachtige Prozesse im Arbeitsspeicher
- Ungewohnliche offene Ports
- Geanderte AutoRun-Eintrage in der Registry
- Neue Scheduled Tasks in temp-Pfaden
- Geanderte Administratorgruppen-Mitgliedschaft
- Erhohte Fehlanmeldungen (>10 pro Stunde)

### 5.3 Datenverschlusselung

```powershell
# Verschlusselung aktivieren
Invoke-DataEncryption -Config $Config

# Einzelne Datei verschlusseln
Protect-File -FilePath "C:\CustomerData\wichtig.xlsx"

# Datei entschlusseln
Unprotect-File -EncryptedPath "C:\CustomerData\wichtig.xlsx.jdsenc"

# Sicheres Loschen
Invoke-SecureDelete -Path "C:\temp\sensitiv.pdf" -Passes 3
```

### 5.5 Ransomware-Schutz

```powershell
# Ransomware-Scan durchfuhren
Invoke-RansomwareScan -Config $Config -ShowProgress $true

# Daueruberwachung starten
Start-RansomwareMonitor -Config $Config

# Datei-Entropie messen
Measure-FileEntropy -Path "C:\verdaechtig.exe"
```

**Erkennungsmethoden:**
- **Bekannte Erweiterungen** (.cry, .locked, .encrypted, .ecc, .ezz)
- **Losegeldforderungen** (README.txt, HOW_TO_DECRYPT, !!!READ_ME*)
- **Massenanderungen** (>50 Dateien in 30 Minuten)
- **Entropie-Analyse** (256-Byte-Stichprobe, Grenzwert >7.5 Bit)
- **Korrupte Header** (DOC/XLS/PPT mit falschen Magic-Bytes)
- **Verdachtige Prozesse** (*ransom*, *encrypt*, *crypto*, *lock*)

**Automatische Gegenmassnahmen:**
1. Windows Defender aktivieren (falls deaktiviert)
2. Systemwiederherstellungspunkt erstellen
3. SMB-Freigaben schliesen (block_shares_on_alert)
4. Verdachtige Prozesse beenden (block_processes_on_alert)
5. Kritischer Alarm an Admin

### 5.6 File-Integritat (Tripwire)

```powershell
# Baseline erstellen
Invoke-IntegrityBaseline -Config $Config

# Integritatsprufung durchfuhren
Invoke-IntegrityCheck -Config $Config -ShowProgress $true

# Daueruberwachung starten
Invoke-IntegrityContinuous -Config $Config
```

**Uberwachte Objekte:**
- **Kritische Systemdateien** (hosts, networks, System32)
- **Geschaftsdaten** (BusinessData, CustomerData)
- **Registry-Keys** (AutoRun, Services, RunOnce)
- **Neue Dateien** in uberwachten Verzeichnissen

**Funktionsweise:**
1. `Invoke-IntegrityBaseline` erstellt SHA256-Hashes aller Dateien
2. `Invoke-IntegrityCheck` vergleicht aktuelle Hashes mit Baseline
3. Bei Abweichung: Warnung/Kritischer Alarm + optional Auto-Repair
4. Alte Baselines werden rotiert (keep_baselines = 10)

### 5.7 Prozess-Security

```powershell
# Prozess-Audit durchfuhren
Invoke-ProcessAudit -Config $Config -ShowProgress $true

# Daueruberwachung starten
Start-ProcessMonitor -Config $Config
```

**Blacklist (Auswahl):**
mimikatz, wireshark, nmap, sqlmap, hydra, john, hashcat, procdump, psexec, rdpwrap, anydesk, teamviewer, meterpreter, responder, impacket, bloodhound, certipy, laZagne

**Erkennungsmechanismen:**
- **Blacklist-Erkennung** mit Auto-Kill
- **Suspicious Parents** (cmd.exe von explorer -> verdachtig)
- **Ausfuhrung von Temp** (AppData, Temp, Downloads)
- **Unsigned Binaries** (Digital Signatur prufung)
- **Hohe Ressourcennutzung** (>100 CPU-Sekunden oder >500 MB RAM)
- **Netzwerk-Server-Prozesse** (Listening-Ports)
- **AutoRun-Eintrage** mit PowerShell/cmd-Befehlen
- **Neue Prozesse** in Echtzeit

### 5.8 Netzwerk-Security

```powershell
# Netzwerk-Scan durchfuhren
Invoke-NetworkSecurityScan -Config $Config -ShowProgress $true

# Netzwerk-Hartung anwenden
Invoke-NetworkDefense -Config $Config

# Daueruberwachung starten
Start-NetworkMonitor -Config $Config
```

**Analyse-Bereiche:**
- **Offene Ports** + zugehorige Prozesse
- **Establishierte Verbindungen** (externe IPs ausserhalb 192.168/10/172.16)
- **ARP-Tabelle** auf Spoofing prufen (mehrere IPs pro MAC)
- **DNS-Cache** auf blocklist-Domains und Local-Redirects
- **SMB-Freigaben** auf unsichere Namen prüfen
- **Firewall-Regeln** auf unerwartete Inbound-Erlaubnisse

**Automatische Hartung:**
1. **DNS-Blocklist** -> Malware-Domains in hosts-Datei (0.0.0.0)
2. **TCP/IP-Hartung** -> SynAttackProtect, ICMP-Redirect aus, IP-SourceRouting aus
3. **NetBIOS** uber TCP/IP deaktivieren (SMB-Device)
4. **Verbindungs-Auditing** aktivieren (Filtering Platform Connection)

### 5.9 Vulnerability-Scan

```powershell
# Schwachstellenscan durchfuhren
Invoke-VulnerabilityScan -Config $Config -ShowProgress $true

# Daueruberwachung starten
Start-VulnerabilityMonitor -Config $Config
```

**Geprufte Bereiche (20+ Checks):**

| Kategorie | Prufung | Schweregrad bei Fund |
|-----------|---------|---------------------|
| Patches | Letztes Update >30 Tage | WARN / DANGER |
| Protokolle | SMBv1 aktiv, TLS 1.2/1.3 fehlt | WARN |
| Konten | Gast aktiv, zu viele Admins | DANGER |
| Firewall | Profil deaktiviert | DANGER |
| Defender | Echtzeitschutz aus | DANGER |
| RDP | Nicht aktiviert | DANGER |
| Passwort-Policy | Leere Passworter erlaubt | DANGER |
| UAC | Deaktiviert | WARN |
| Auto-Logon | Automatischer Admin-Logon | WARN |
| LSA-Schutz | RunAsPPL nicht aktiv | WARN |
| Credential Guard | Nicht aktiviert | INFO |
| AppLocker | Nicht konfiguriert | INFO |
| Secure Boot | Nicht aktiv | WARN |
| BitLocker | Laufwerke unverschlusselt | WARN |

### 5.4 Honeypot

```powershell
# Honeypot einrichten
Invoke-HoneypotSetup -Config $Config

# Zugriffe uberwachen
Invoke-HoneypotMonitor -Config $Config

# Fake-Freigaben erstellen
Invoke-HoneypotShares -Config $Config
```

**Honeypot-Komponenten:**
- 3 Fake-Dateien mit scheinbaren Zugangsdaten
- Port-Listener auf 21, 23, 80, 443, 3389, 8080
- 4 Fake-Netzwerkfreigaben (Backup, Data, Admin, HR)
- Automatische Alarmierung bei Zugriff

---

## 6. Monitoring & Alarme

### 6.1 Alarm-Level

| Level | Beschreibung | Reaktion |
|-------|-------------|----------|
| Critical | Sicherheitsvorfall | Email + Popup + Log + Sound |
| Warning | Potenzielle Bedrohung | Email + Popup + Log |
| Info | Normales Ereignis | Nur Log |

### 6.2 Alarm-Kanale

- **Email:** Via SMTP an konfigurierte Empfanger
- **Popup:** Windows- MessageBox bei kritischen Ereignissen
- **Log:** In Datei und Windows-Event-Log
- **Sound:** Akustisches Signal bei kritischen Alarmen

### 6.3 Berichte

```powershell
# HTML-Sicherheitsbericht erstellen
Export-SecurityReport -Config $Config

# Audit-Bericht (letzte 24h)
New-JDSAuditReport -Config $Config -Hours 24
```

Der HTML-Bericht enthalt:
- Systemubersicht (Dienste, Prozesse, Speicher)
- Firewall-Status
- Modul-Status (alle 12 Module)
- Letzte Sicherheitsereignisse
- Ransomware-Indikatoren
- File-Integritatsstatus
- Prozess-Audit-Ergebnisse
- Netzwerk-Sicherheitsscan
- Vulnerability-Scan-Ergebnisse
- Empfehlungen (5 priorisierte Massnahmen)

---

## 7. Wartung

### 7.1 Regelmasige Aufgaben

| Intervall | Aufgabe |
|-----------|---------|
| Taglich | Backup-Logs prufen, Speicherplatz kontrollieren |
| Wochentlich | Sicherheitsbericht erstellen, Alarme auswerten |
| Monatlich | Vollstandigen Scan durchfuhren, Recovery testen |
| Quartalsweise | Backup-Wiederherstellung testen, Konfiguration prufen |

### 7.2 Log-Rotation

Logs werden automatisch nach 90 Tagen geloscht (einstellbar in `config.audit.log_retention_days`).

### 7.3 Update

```powershell
# Neues Update einspielen:
# 1. Neue Version herunterladen
# 2. Dienst stoppen
Stop-Service JDSSecure

# 3. Dateien uberschreiben
Copy-Item "D:\Downloads\JDS-Secure-v2.1\*" "C:\Program Files\JDS-Secure" -Recurse -Force

# 4. Dienst starten
Start-Service JDSSecure
```

---

## 8. Notfall-Wiederherstellung

### 8.1 System nach Angriff wiederherstellen

```powershell
# 1. Dienst stoppen
Stop-Service JDSSecure -Force

# 2. Letztes gutes Backup einspielen
Restore-Backup -BackupPath "D:\JDS-Backup\JDS-Backup_vor_Angriff"

# 3. Firewall auf Maximum stellen
Invoke-FirewallHardening -Config $Config

# 4. Vollstandigen Scan durchfuhren
Invoke-IDSMonitor -Config $Config

# 5. Bericht erstellen
Export-SecurityReport -Config $Config
```

### 8.2 Daten wiederherstellen

```powershell
# Backup-Verzeichnis durchsuchen
Get-ChildItem D:\JDS-Backup -Recurse -Filter "*.zip" | Sort-Object LastWriteTime

# Komplettes Backup entpacken
Expand-Archive -Path "D:\JDS-Backup\JDS-Backup_2026-06-10_02-00-00\CustomerData.zip" -DestinationPath "C:\CustomerData_Restored"

# Verschlusseltes Backup entschlusseln
Unprotect-File -EncryptedPath "D:\JDS-Backup\JDS-Backup_2026-06-10_02-00-00\CustomerData.zip.enc" -OutputPath "C:\Restore\CustomerData.zip"
```

### 8.3 Notfall-Kontakt

Bei kritischen Problemen:
- Log-Dateien sichern: `C:\Program Files\JDS-Secure\logs\`
- Event-Viewer: `JDS-Secure` Log exportieren
- Backup-Dateien sichern

---

## 9. Anhang: Port-Referenz

### Verwendete Ports

| Port | Protokoll | Verwendung |
|------|-----------|-----------|
| 21 | TCP | Honeypot FTP (Fake) |
| 23 | TCP | Honeypot Telnet (Fake) |
| 80 | TCP | HTTP / Honeypot |
| 443 | TCP | HTTPS / Honeypot |
| 3389 | TCP | RDP (optional anderrbar) |
| 8080 | TCP | HTTP-Alt / Honeypot |
| 587 | TCP | SMTP (Alarm-E-Mails) |

### Zu uberwachende Ports (IDS)

| Port | Gefahr |
|------|--------|
| 4444 | Metasploit |
| 5555 | Android ADB / Backdoor |
| 6666 | IRC / Botnet |
| 7777 | Unbekannt / Backdoor |
| 8443 | Alternativer HTTPS |
| 9001 | Tor / Backdoor |
| 31337 | Elite / Backdoor |
| 1337 | Elite / Backdoor |

---

## Index

- **Backup-Konfiguration:** Siehe Abschnitt 3
- **Dienst-Installation:** Siehe Abschnitt 4.1
- **Fehlerbehebung:** Siehe `installationsanleitung.md` Abschnitt 8
- **GUI-Bedienung:** Siehe `schnellstart.md`
- **Konfigurationsdatei:** `config/security-config.json`
- **Log-Dateien:** `logs/` Verzeichnis
- **Service-Log:** `logs/service.log`
- **Setup:** `setup.ps1`
- **Deinstallation:** `uninstall.ps1`
