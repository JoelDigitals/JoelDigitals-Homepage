# JDS Secure - Schnellstart

**Sicherheitssystem fur KMU - In 5 Minuten einsatzbereit**

---

## 1. System vorbereiten

**Voraussetzungen:** Windows 10/11 oder Windows Server 2016+, PowerShell 5.1+

```powershell
# Execution Policy einmalig setzen (als Admin)
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Bypass
```

---

## 2. Ein-Klick-Installation (Empfohlen)

```powershell
# Der einfachste Weg - erkennt automatisch Server oder USB:
.\setup.ps1 -Easy

# Alternativ mit grafischem Assistenten:
.\setup.ps1 -GUI
```

**Was passiert automatisch:**
- Erkennt ob Administrator-Rechte vorhanden sind
- Server-Modus: Installiert Dienst + Tasks + Konfiguration
- USB-Modus: Kopiert alles auf den USB-Stick
- Startet Selbstdiagnose ("Funktioniert alles?")

---

## 3. Manuelle Installation

### Von USB-Stick starten (Mobil)

```powershell
.\deploy-to-usb.ps1 -DriveLetter E -EncryptDrive
```

### Auf Server installieren

```powershell
.\setup.ps1 -Mode Server -Auto
```

**Installiert:**
- Windows-Dienst: `JDSSecure` (Automatischer Start)
- 3 geplante Tasks: Scan (stundlich), Backup (02:00), Bereinigung (Sonntag)
- Daten-Pfad: `C:\ProgramData\JDS-Secure`

---

## 4. GUI bedienen

Nach dem Start sehen Sie das Dashboard mit:

| Bereich | Funktion |
|---------|----------|
| Status-Karten (16) | Live-Ubersicht aller 17 Module |
| Schnellaktionen (15) | Vollscan, Backup, Firewall, Ransomware, Vulnerability, Prozess, Integritat, Netzwerk, Selbstschutz, Virenscan, Quarantaene, DSGVO-Doku, Incident-Test, Service-Modus, Bericht |
| Backup-Tab | Ziel wahlen und Backup starten |
| Einstellungen | Module aktivieren/deaktivieren |

### Alle 17 Sicherheitsmodule:

| Modul | Beschreibung |
|-------|-------------|
| Firewall | Netzwerk-Hartung, Port-Scan, Brute-Force-Schutz |
| IDS | Intrusion Detection, Prozess-Uberwachung |
| Verschlusselung | AES-256, BitLocker, EFS, RSA-Zertifikate |
| Backup | Multi-Destination, Rotation, Versioning, SQL |
| Honeypot | Fake-Dateien, Port-Listener, Fake-Shares |
| USB-Security | USB-Sperre, AutoRun-Schutz, Whitelist |
| Ransomware-Schutz | Entropie, Massenanderungen, Auto-Kill |
| File-Integritat | SHA256-Baseline, Registry-Watch, Auto-Repair |
| Prozess-Security | Blacklist, Unsigned-Detect, Parent-Analyse |
| Netzwerk-Security | ARP-Spoofing, DNS-Block, TCP/IP-Hartung |
| Vulnerability-Scan | Patch-Check, Protokoll-Schwachstellen |
| Selbstschutz | Anti-Tamper, Heartbeat, ACL-Prufung |
| Incident-Response | Automatisierte Playbooks, Beweissicherung |
| Virenscan | SHA256-Signaturen, Heuristik, YARA-Regeln |
| Quarantaene | Isolierung, Wiederherstellung, Auto-Quarantaene |
| DSGVO | Datenschutz-Meldung (72h), Loschkonzept, TOM |
| Audit | Logging, E-Mail-Alarme, HTML-Berichte |

---

## 5. Backup-Ziel einrichten

Im GUI unter Tab "Backup":

```
[Externe Festplatte (D:)]  <- Empfohlen fur tagliche Backups
[USB-Stick (E:)]            <- Fur mobilen Einsatz
[Netzwerkfreigabe]          <- Fur Unternehmen mit NAS
[Benutzerdefiniert]         <- Eigener Pfad
```

---

## 6. Wichtige Befehle

| Befehl | Wirkung |
|--------|---------|
| `.\jds-secure.ps1` | GUI starten (Standard) |
| `.\jds-secure.ps1 -Mode QuickScan` | Schnellscan (alle Module) |
| `.\jds-secure.ps1 -Mode Service` | Hintergrundbetrieb |
| `.\jds-secure.ps1 -Mode Backup` | Nur Backup ausfuhren |
| `.\jds-secure.ps1 -Mode Cleanup` | Backup-Bereinigung |
| `.\jds-secure.ps1 -Mode Report` | Sicherheitsbericht |
| `.\setup.ps1` | Setup-Assistent |
| `.\setup.ps1 -Easy` | Ein-Klick-Installation |
| `.\setup.ps1 -GUI` | Grafischer Assistent |
| `.\setup.ps1 -Mode Server -Auto` | Stille Server-Installation |
| `.\uninstall.ps1` | Deinstallation |

---

## 7. Rechtssicherheit (DSGVO)

JDS Secure unterstutzt Sie bei der DSGVO-Compliance:

- **Art. 30**: Automatisches Verarbeitungsverzeichnis
- **Art. 32**: Technisch-organisatorische Massnahmen (TOM)
- **Art. 33**: 72h-Meldewesen bei Datenschutzverletzungen
- **Art. 17**: Loschkonzept mit automatischer Datenbereinigung
- **Art. 5**: Datenminimierung durch Aufbewahrungsfristen

Im Menupunkt **DSGVO** (Option 20) konnen Sie:
1. Datenschutzverletzung melden mit Frist-Tracking
2. Datenbereinigung durchfuhren
3. Vollstandige Dokumentation exportieren (HTML)

---

## Notizen

- Admin-Rechte fur Firewall, BitLocker und Dienst-Installation
- Log-Dateien: `logs\jds-audit.log`
- Konfiguration: `config\security-config.json`
- Alle Skripte sind UTF-8 mit BOM kodiert
