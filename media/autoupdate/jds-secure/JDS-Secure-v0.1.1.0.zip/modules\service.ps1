﻿function Install-JDSService {
    param([hashtable]$Config)

    $srv = $Config.server
    Write-JDSLog "INFO" "Installing JDS Secure as Windows service..."

    try {
        $serviceName = $srv.service_name
        $existing = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
        if ($existing) {
            Write-JDSLog "WARN" "Service $serviceName existiert bereits. Entferne alten Dienst..."
            Stop-Service $serviceName -Force -ErrorAction SilentlyContinue
            & sc.exe delete $serviceName 2>&1 | Out-Null
            Start-Sleep -Seconds 2
        }

        $serviceScript = "$PSScriptRoot\..\tools\jds-service.ps1"
        if (-not (Test-Path $serviceScript)) {
            Write-JDSLog "ERROR" "Service script not found: $serviceScript"
            return $false
        }

        $installPath = $Config.general.install_path
        if (-not (Test-Path $installPath)) {
            New-Item -ItemType Directory -Path $installPath -Force | Out-Null
        }

        Copy-Item -Path "$PSScriptRoot\..\*" -Destination $installPath -Recurse -Force -Exclude @("backup", "logs")
        Write-JDSLog "INFO" "Copied files to $installPath"

        $nssmPath = "$PSScriptRoot\..\tools\nssm.exe"
        $useNssm = Test-Path $nssmPath

        if ($useNssm) {
            & $nssmPath install $serviceName "powershell.exe" "-ExecutionPolicy Bypass -File `"$installPath\tools\jds-service.ps1`"" 2>&1 | Out-Null
            & $nssmPath set $serviceName DisplayName $srv.service_display 2>&1 | Out-Null
            & $nssmPath set $serviceName Start $srv.service_start 2>&1 | Out-Null
            & $nssmPath set $serviceName AppStdout "$installPath\logs\service-output.log" 2>&1 | Out-Null
            & $nssmPath set $serviceName AppStderr "$installPath\logs\service-error.log" 2>&1 | Out-Null
            & $nssmPath set $serviceName AppRotateFiles 1 2>&1 | Out-Null
            & $nssmPath set $serviceName AppRotateBytes 10485760 2>&1 | Out-Null
        } else {
            $serviceBinary = "powershell.exe"
            $serviceArgs = "-ExecutionPolicy Bypass -File `"$installPath\tools\jds-service.ps1`""

            $scParams = @(
                "create", $serviceName,
                "binPath=`"$serviceBinary $serviceArgs`"",
                "displayName=", $srv.service_display,
                "start=", $srv.service_start.ToLower(),
                "type=", "own"
            )
            & sc.exe $scParams 2>&1 | Out-Null

            & sc.exe description $serviceName "JDS Secure - Umfassendes Sicherheitssystem fuer KMU. Firewall, IDS, Backup, Verschlusselung." 2>&1 | Out-Null

            $recovery = $srv.recovery
            & sc.exe failure $serviceName reset=$($recovery.reset_after_days * 86400) actions=$($recovery.first_failure)/60000/$($recovery.second_failure)/120000/$($recovery.subsequent_failures)/300000 2>&1 | Out-Null
        }

        if ($srv.run_as_user) {
            $securePass = ConvertTo-SecureString $srv.run_as_password -AsPlainText -Force
            $cred = New-Object System.Management.Automation.PSCredential($srv.run_as_user, $securePass)
            if ($useNssm) {
                & $nssmPath set $serviceName ObjectName $srv.run_as_user $srv.run_as_password 2>&1 | Out-Null
            } else {
                & sc.exe config $serviceName obj="$($srv.run_as_user)" password="$($srv.run_as_password)" 2>&1 | Out-Null
            }
        }

        $eventLog = $srv.event_log
        if ($eventLog.enabled) {
            try {
                $eventSource = $serviceName
                if (-not [System.Diagnostics.EventLog]::SourceExists($eventSource)) {
                    [System.Diagnostics.EventLog]::CreateEventSource($eventSource, $eventLog.log_name)
                }
                Write-JDSLog "INFO" "Event log source created: $eventSource"
            } catch {
                Write-JDSLog "WARN" "Could not create event log source (Admin rights needed): $_"
            }
        }

        $tasks = $srv.scheduled_tasks
        if ($tasks.enabled) {
            Install-JDSScheduledTasks -Config $Config -InstallPath $installPath
        }

        Start-Service $serviceName -ErrorAction SilentlyContinue
        Write-JDSLog "INFO" "Service $serviceName installed and started"

        $alerts = @{
            type = "Info"
            title = "JDS Secure installiert"
            message = "Windows-Dienst '$serviceName' wurde installiert und gestartet"
        }
        Send-JDSAlert $Config $alerts

        return $true
    } catch {
        Write-JDSLog "ERROR" "Service installation failed: $_"
        return $false
    }
}

function Install-JDSScheduledTasks {
    param([hashtable]$Config, [string]$InstallPath = "")

    if (-not $InstallPath) { $InstallPath = $Config.general.install_path }
    $tasks = $Config.server.scheduled_tasks

    Write-JDSLog "INFO" "Creating scheduled tasks..."

    try {
        $existing = Get-ScheduledTask -TaskName $tasks.scan_task -ErrorAction SilentlyContinue
        if ($existing) { Unregister-ScheduledTask -TaskName $tasks.scan_task -Confirm:$false -ErrorAction SilentlyContinue }

        $scanAction = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-ExecutionPolicy Bypass -File `"$InstallPath\jds-secure.ps1`" -Mode QuickScan -NoGUI"
        $scanTrigger = New-ScheduledTaskTrigger -Daily -At "00:00"
        Register-ScheduledTask -TaskName $tasks.scan_task -Action $scanAction -Trigger $scanTrigger -RunLevel Highest -Description "JDS Secure - Regelmassiger Sicherheitsscan" -Force | Out-Null
        Write-JDSLog "INFO" "Scheduled task created: $($tasks.scan_task)"
    } catch { Write-JDSLog "WARN" "Could not create scan task: $_" }

    try {
        $existing = Get-ScheduledTask -TaskName $tasks.backup_task -ErrorAction SilentlyContinue
        if ($existing) { Unregister-ScheduledTask -TaskName $tasks.backup_task -Confirm:$false -ErrorAction SilentlyContinue }

        $backupAction = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-ExecutionPolicy Bypass -File `"$InstallPath\jds-secure.ps1`" -Mode Backup -NoGUI"
        $backupTime = $tasks.backup_time -split ':'
        $backupTrigger = New-ScheduledTaskTrigger -Daily -At "$($backupTime[0]):$($backupTime[1])"
        Register-ScheduledTask -TaskName $tasks.backup_task -Action $backupAction -Trigger $backupTrigger -RunLevel Highest -Description "JDS Secure - Automatisches Backup" -Force | Out-Null
        Write-JDSLog "INFO" "Scheduled task created: $($tasks.backup_task)"
    } catch { Write-JDSLog "WARN" "Could not create backup task: $_" }

    try {
        $existing = Get-ScheduledTask -TaskName $tasks.cleanup_task -ErrorAction SilentlyContinue
        if ($existing) { Unregister-ScheduledTask -TaskName $tasks.cleanup_task -Confirm:$false -ErrorAction SilentlyContinue }

        $cleanupAction = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-ExecutionPolicy Bypass -File `"$InstallPath\jds-secure.ps1`" -Mode Cleanup -NoGUI"
        $daysOfWeek = @("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        $dayIndex = [array]::IndexOf($daysOfWeek, $tasks.cleanup_day)
        $cleanupTrigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $tasks.cleanup_day -At $tasks.cleanup_time
        Register-ScheduledTask -TaskName $tasks.cleanup_task -Action $cleanupAction -Trigger $cleanupTrigger -RunLevel Highest -Description "JDS Secure - Log- und Backup-Bereinigung" -Force | Out-Null
        Write-JDSLog "INFO" "Scheduled task created: $($tasks.cleanup_task)"
    } catch { Write-JDSLog "WARN" "Could not create cleanup task: $_" }

    Write-JDSLog "INFO" "Scheduled tasks installation completed"
}

function Uninstall-JDSService {
    param([hashtable]$Config)

    $serviceName = $Config.server.service_name

    Write-JDSLog "WARN" "Uninstalling JDS Secure service..."

    try {
        $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
        if ($service) {
            Stop-Service $serviceName -Force -ErrorAction SilentlyContinue
            & sc.exe delete $serviceName 2>&1 | Out-Null
            Start-Sleep -Seconds 2
            Write-JDSLog "INFO" "Service $serviceName removed"
        }

        $tasks = $Config.server.scheduled_tasks
        $taskNames = @($tasks.scan_task, $tasks.backup_task, $tasks.cleanup_task)
        foreach ($taskName in $taskNames) {
            try {
                $task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
                if ($task) {
                    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
                    Write-JDSLog "INFO" "Scheduled task removed: $taskName"
                }
            } catch {}
        }

        try {
            $eventSource = $serviceName
            if ([System.Diagnostics.EventLog]::SourceExists($eventSource)) {
                [System.Diagnostics.EventLog]::DeleteEventSource($eventSource)
                Write-JDSLog "INFO" "Event log source removed"
            }
        } catch {}

        Write-JDSLog "INFO" "Service uninstallation completed"
        return $true
    } catch {
        Write-JDSLog "ERROR" "Service uninstallation failed: $_"
        return $false
    }
}

function Test-JDSService {
    $serviceName = "JDSSecure"
    $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($service) {
        return [PSCustomObject]@{
            Installed = $true
            Status = $service.Status
            StartType = $service.StartType
            DisplayName = $service.DisplayName
        }
    }
    return [PSCustomObject]@{ Installed = $false }
}


