﻿function Initialize-RansomwareProtection {
    param([hashtable]$Config)
    $cfg = $Config.ransomware
    if (-not $cfg.enabled) { return }

    $monitorDirs = if ($cfg.monitor_directories -and $cfg.monitor_directories.Count -gt 0) { $cfg.monitor_directories } else { @("$env:USERPROFILE\Documents", "$env:USERPROFILE\Desktop", "C:\BusinessData", "C:\CustomerData") }

    $knownExtensions = @(".cry", ".locked", ".encrypted", ".enc", ". ransomware", ".ecc", ".ezz", ".exx", ".zzz", ".abc", ".xyz", ".aaa", ".micro", ".encryptedRSA", ".decrypt", ".how_to_decrypt", ".README", ".README.txt", ".readme", ".readme.txt", ".HELP", ".help")

    $knownFiles = @("README_*.txt", "README_*.html", "HOW_TO_DECRYPT*", "DECRYPT_INSTRUCTIONS*", "DECRYPT_FILES*", "HELP_DECRYPT*", "!!!READ_ME*", "RECOVERY_KEY*")

    $highRiskExtensions = @(".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".pdf", ".jpg", ".jpeg", ".png", ".gif", ".tif", ".tiff", ".raw", ".bmp", ".zip", ".rar", ".7z", ".tar", ".gz", ".sql", ".mdb", ".accdb", ".dbf", ".csv", ".xml", ".json", ".txt", ".rtf", ".msg", ".eml", ".ost", ".pst", ".dwg", ".dxf", ".psd", ".ai", ".indd", ".qbb", ".qbo", ".qbw", ".qbx", ".qwc", ".p12", ".pfx", ".key", ".csr", ".crt", ".cer", ".pem", ".git", ".svn", ".htaccess", ".config", ".env", ".yml", ".yaml", ".ini")

    return @{
        monitor_dirs = $monitorDirs
        known_extensions = $knownExtensions
        known_files = $knownFiles
        high_risk_extensions = $highRiskExtensions
    }
}

function Invoke-RansomwareScan {
    param([hashtable]$Config, [bool]$ShowProgress = $false)
    $cfg = $Config.ransomware
    if (-not $cfg.enabled) { return @{ status = "disabled"; message = "Ransomware-Schutz deaktiviert" } }

    $rt = Initialize-RansomwareProtection -Config $Config
    $alerts = @()
    $suspicious = @()
    $scanStart = Get-Date

    if ($ShowProgress) { Write-Host "  [RANSOMWARE] Scanne nach Ransomware-Indikatoren..." -ForegroundColor Cyan }

    if ($cfg.scan_mass_renames -or $cfg.scan_recent_changes) {
        $allDirs = $rt.monitor_dirs
        $fileCount = 0
        $totalSize = 0
        $newExtensions = @{}
        $recentChanges = @()

        foreach ($dir in $allDirs) {
            if (-not (Test-Path $dir)) { continue }
            try {
                $files = Get-ChildItem $dir -Recurse -File -ErrorAction SilentlyContinue -Depth 3
                foreach ($file in $files) {
                    $fileCount++
                    $totalSize += $file.Length

                    if ($cfg.detect_new_extensions) {
                        $ext = $file.Extension.ToLower()
                        if ($ext -match '^\.(cry|locked|encrypt|ecc|ezz|exx|zzz|abc|aaa|micro|how_to|readme|help|decrypt)$') {
                            $suspicious += @{ type = "known_extension"; file = $file.FullName; ext = $ext }
                        }
                    }

                    if ($cfg.detect_high_change_rate) {
                        if ($file.LastWriteTime -gt (Get-Date).AddMinutes(-30)) {
                            $recentChanges += $file
                        }
                    }

                    if ($cfg.detect_encrypted_headers) {
                        try {
                            $stream = $file.OpenRead()
                            $bytes = New-Object byte[] 16
                            $bytesRead = $stream.Read($bytes, 0, [Math]::Min(16, $file.Length))
                            $stream.Close()
                            if ($bytesRead -ge 4) {
                                $header = [System.BitConverter]::ToString($bytes[0..3])
                                if ($header -ne "D0-CF-11-E0" -and $ext -match '^\.(doc|xls|ppt)$') {
                                    $suspicious += @{ type = "corrupted_header"; file = $file.FullName; header = $header }
                                }
                            }
                        } catch { }
                    }
                }
            } catch { }
        }

        if ($recentChanges.Count -gt 50 -and $cfg.detect_mass_changes) {
            $suspicious += @{ type = "mass_changes"; count = $recentChanges.Count; window = "30min" }
            $alerts += @{ type = "Warning"; title = "Massenhafte Dateiaenderungen"; message = "$($recentChanges.Count) Aenderungen in 30 Minuten - moeglicher Ransomware-Angriff" }
        }

        if ($cfg.detect_decrypt_files) {
            foreach ($dir in $allDirs) {
                if (-not (Test-Path $dir)) { continue }
                try {
                    foreach ($pattern in $rt.known_files) {
                        $matches = Get-ChildItem $dir -Filter $pattern -ErrorAction SilentlyContinue
                        foreach ($m in $matches) {
                            $suspicious += @{ type = "ransomware_note"; file = $m.FullName; pattern = $pattern }
                        }
                    }
                } catch { }
            }
        }

        if ($cfg.detect_entropy_high) {
            foreach ($dir in $allDirs) {
                if (-not (Test-Path $dir)) { continue }
                try {
                    $recentFiles = Get-ChildItem $dir -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -gt (Get-Date).AddHours(-1) -and $_.Length -gt 1024 }
                    foreach ($f in $recentFiles) {
                        try {
                            $stream = $f.OpenRead()
                            $buf = New-Object byte[] 256
                            $bytesRead = $stream.Read($buf, 0, [Math]::Min(256, $f.Length))
                            $stream.Close()
                            if ($bytesRead -eq 256) {
                                $freq = @{}
                                foreach ($b in $buf) { if (-not $freq.ContainsKey($b)) { $freq[$b] = 0 }; $freq[$b]++ }
                                $entropy = 0.0
                                foreach ($v in $freq.Values) {
                                    $p = $v / 256.0
                                    $entropy -= $p * [Math]::Log($p, 2)
                                }
                                if ($entropy -gt 7.5) {
                                    $suspicious += @{ type = "high_entropy"; file = $f.FullName; entropy = [Math]::Round($entropy, 2) }
                                }
                            }
                        } catch { }
                    }
                } catch { }
            }
        }

        if (Get-Process -Name "*ransom*", "*encrypt*", "*crypto*", "*lock*", "*bit*" -ErrorAction SilentlyContinue) {
            $suspicious += @{ type = "suspicious_process"; processes = (Get-Process -Name "*ransom*", "*encrypt*", "*crypto*", "*lock*", "*bit*" -ErrorAction SilentlyContinue | ForEach-Object { $_.ProcessName }) }
            $alerts += @{ type = "Critical"; title = "Verdaechtiger Prozess"; message = "Ransomware-aehnlicher Prozess erkannt!" }
        }

        foreach ($alert in $alerts) {
            $lvl = if ($alert.type -eq "Critical") { "ERROR" } elseif ($alert.type -eq "Warning") { "WARN" } else { "INFO" }
            Write-JDSLog $lvl "$($alert.title): $($alert.message)"
            Send-JDSAlert $Config $alert
        }
    }

    $result = @{
        status = if ($suspicious.Count -gt 0) { "danger" } elseif ($alerts.Count -gt 0) { "warn" } else { "safe" }
        files_scanned = $fileCount
        total_size_mb = [Math]::Round($totalSize / 1MB, 2)
        suspicious_findings = $suspicious.Count
        alerts_triggered = $alerts.Count
        scan_duration_sec = [Math]::Round(((Get-Date) - $scanStart).TotalSeconds, 1)
        details = $suspicious[0..5]
    }

    return $result
}

function Start-RansomwareMonitor {
    param([hashtable]$Config)
    $cfg = $Config.ransomware
    if (-not $cfg.enabled) { return }

    $interval = if ($cfg.monitor_interval_seconds) { $cfg.monitor_interval_seconds } else { 60 }
    $baselines = @{}

    foreach ($dir in $cfg.monitor_directories) {
        if (-not (Test-Path $dir)) { continue }
        try {
            $baselines[$dir] = @{
                file_count = (Get-ChildItem $dir -Recurse -File -ErrorAction SilentlyContinue).Count
                snapshot_time = Get-Date
            }
        } catch { }
    }

    while ($true) {
        Start-Sleep -Seconds $interval
        $result = Invoke-RansomwareScan -Config $Config -ShowProgress $false

        if ($result.status -eq "danger") {
            $alert = @{ type = "Critical"; title = "Ransomware-Alarm"; message = "Ransomware-Aktivitaet erkannt! $($result.suspicious_findings) verdaechtige Ereignisse." }
            Send-JDSAlert $Config $alert
            Write-JDSLog "CRITICAL" "RANSOMWARE: $($result.suspicious_findings) Indikatoren - Schutzmassnahmen werden eingeleitet"

            try { Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction SilentlyContinue } catch { }
            try { & "$env:WINDIR\system32\wbem\WMIC.exe" /namespace:\\root\default path SystemRestore call CreateRestorePoint "JDS-Ransomware-Defense", 0, 100 | Out-Null } catch { }

            if ($cfg.block_shares_on_alert) {
                try {
                    Get-SmbShare | Where-Object { $_.Name -ne "ADMIN$" -and $_.Name -ne "C$" -and $_.Name -ne "IPC$" } | Remove-SmbShare -Force -ErrorAction SilentlyContinue
                    Write-JDSLog "WARN" "RANSOMWARE: Dateifreigaben wurden gesperrt"
                } catch { }
            }

            if ($cfg.block_processes_on_alert) {
                try {
                    $suspProcNames = @("*ransom*", "*encrypt*", "*crypto*", "*lock*", "*bit*", "*decrypt*", "*coder*", "*crypt*")
                    foreach ($pn in $suspProcNames) {
                        Get-Process -Name $pn -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
                    }
                    Write-JDSLog "WARN" "RANSOMWARE: Verdaectige Prozesse wurden beendet"
                } catch { }
            }
        } elseif ($result.status -eq "warn") {
            Write-JDSLog "WARN" "RANSOMWARE: $($result.suspicious_findings) verdaechtige Dateien gefunden"
        }
    }
}

function Measure-FileEntropy {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return -1 }
    try {
        $stream = [System.IO.File]::OpenRead($Path)
        $buf = New-Object byte[] 4096
        $totalRead = 0
        $freq = @{}
        while (($bytesRead = $stream.Read($buf, 0, 4096)) -gt 0) {
            $totalRead += $bytesRead
            for ($i = 0; $i -lt $bytesRead; $i++) { if (-not $freq.ContainsKey($buf[$i])) { $freq[$buf[$i]] = 0 }; $freq[$buf[$i]]++ }
        }
        $stream.Close()
        if ($totalRead -eq 0) { return -1 }
        $entropy = 0.0
        foreach ($v in $freq.Values) {
            $p = $v / $totalRead
            if ($p -gt 0) { $entropy -= $p * [Math]::Log($p, 2) }
        }
        return [Math]::Round($entropy, 2)
    } catch { return -1 }
}
