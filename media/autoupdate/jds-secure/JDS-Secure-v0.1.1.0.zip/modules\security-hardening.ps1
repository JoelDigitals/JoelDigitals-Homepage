﻿function Initialize-JDSHardening {
    param([hashtable]$Config)
    $cfg = $Config.security_hardening
    if (-not $cfg.enabled) { return @{ status = "disabled" } }

    $manifestPath = Join-Path $Config.general.install_path "config\module-manifest.json"
    $script:JDSManifestPath = $manifestPath

    $script:JDSSigningKey = $null

    $signingKeyPath = Join-Path $Config.general.data_path ".jds-key"
    if (Test-Path $signingKeyPath) {
        try { $script:JDSSigningKey = [System.IO.File]::ReadAllBytes($signingKeyPath) } catch { }
    }

    $integrityResult = Test-JDSModuleIntegrity -Config $Config

    return @{
        manifest_exists = (Test-Path $manifestPath)
        modules_verified = $integrityResult.verified
        modules_total = $integrityResult.total
        tampered = $integrityResult.tampered
        config_encrypted = (Test-Path $signingKeyPath)
    }
}

function New-JDSModuleManifest {
    param([hashtable]$Config)
    $moduleDir = Join-Path $Config.general.install_path "modules"
    if (-not (Test-Path $moduleDir)) { return @{ success = $false; reason = "Module-Verzeichnis nicht gefunden" } }

    $manifest = @()
    $modules = Get-ChildItem -Path $moduleDir -Filter "*.ps1" -ErrorAction SilentlyContinue
    foreach ($m in $modules) {
        try {
            $stream = [System.IO.File]::OpenRead($m.FullName)
            $sha256 = [System.Security.Cryptography.SHA256]::Create()
            $hashBytes = $sha256.ComputeHash($stream)
            $stream.Close()
            $hashStr = [BitConverter]::ToString($hashBytes) -replace '-', ''
            $manifest += @{
                file = $m.Name
                path = $m.FullName
                hash = $hashStr.ToLower()
                size = $m.Length
                last_modified = $m.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")
            }
        } catch { }
    }

    $manifestPath = Join-Path $Config.general.install_path "config\module-manifest.json"
    $manifest | ConvertTo-Json -Depth 5 | Set-Content -Path $manifestPath -Encoding UTF8 -Force

    $jdsPaths = @(
        (Join-Path $Config.general.install_path "jds-secure.ps1"),
        (Join-Path $Config.general.install_path "config\security-config.json"),
        (Join-Path $Config.general.install_path "tools\jds-service.ps1")
    )
    $coreManifest = @()
    foreach ($p in $jdsPaths) {
        if (Test-Path $p) {
            try {
                $stream = [System.IO.File]::OpenRead($p)
                $sha256 = [System.Security.Cryptography.SHA256]::Create()
                $hashBytes = $sha256.ComputeHash($stream)
                $stream.Close()
                $hashStr = [BitConverter]::ToString($hashBytes) -replace '-', ''
                $coreManifest += @{
                    file = (Split-Path $p -Leaf)
                    path = $p
                    hash = $hashStr.ToLower()
                }
            } catch { }
        }
    }
    $corePath = Join-Path $Config.general.install_path "config\core-manifest.json"
    $coreManifest | ConvertTo-Json -Depth 5 | Set-Content -Path $corePath -Encoding UTF8 -Force

    try {
        Add-Type -AssemblyName System.Security -ErrorAction Stop
        $signingKey = New-Object byte[] 32
        $rng = [System.Security.Cryptography.RNGCryptoServiceProvider]::Create()
        $rng.GetBytes($signingKey)
        $dpapiBytes = [System.Security.Cryptography.ProtectedData]::Protect($signingKey, $null, [System.Security.Cryptography.DataProtectionScope]::LocalMachine)
        $keyPath = Join-Path $Config.general.data_path ".jds-key"
        $null = New-Item -ItemType Directory -Path (Split-Path $keyPath -Parent) -Force -ErrorAction SilentlyContinue
        [System.IO.File]::WriteAllBytes($keyPath, $dpapiBytes)
        $script:JDSSigningKey = $signingKey
    } catch {
        Write-Host "  [INFO] HARDENING: DPAPI nicht verfuegbar (wird uebersprungen)" -ForegroundColor Yellow
    }

    Write-Host "  [INFO] HARDENING: Modul-Manifest erstellt ($($manifest.Count) Module, $($coreManifest.Count) Kern-Dateien)" -ForegroundColor Green
    return @{ success = $true; modules = $manifest.Count; core = $coreManifest.Count }
}
function Test-JDSModuleIntegrity {
    param([hashtable]$Config)
    $manifestPath = Join-Path $Config.general.install_path "config\module-manifest.json"
    $corePath = Join-Path $Config.general.install_path "config\core-manifest.json"

    $verified = 0; $total = 0; $tampered = @()

    if (Test-Path $manifestPath) {
        try {
            $manifest = Get-Content $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($entry in $manifest) {
                $total++
                if (Test-Path $entry.path) {
                    try {
                        $stream = [System.IO.File]::OpenRead($entry.path)
                        $sha256 = [System.Security.Cryptography.SHA256]::Create()
                        $hashBytes = $sha256.ComputeHash($stream)
                        $stream.Close()
                        $currentHash = ([BitConverter]::ToString($hashBytes) -replace '-', '').ToLower()
                        if ($currentHash -eq $entry.hash) { $verified++ }
                        else { $tampered += @{ file = $entry.file; path = $entry.path; expected = $entry.hash; actual = $currentHash } }
                    } catch { $tampered += @{ file = $entry.file; path = $entry.path; error = "$_" } }
                } else { $tampered += @{ file = $entry.file; path = $entry.path; error = "not_found" } }
            }
        } catch { }
    }

    if (Test-Path $corePath) {
        try {
            $coreManifest = Get-Content $corePath -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($entry in $coreManifest) {
                $total++
                if (Test-Path $entry.path) {
                    try {
                        $stream = [System.IO.File]::OpenRead($entry.path)
                        $sha256 = [System.Security.Cryptography.SHA256]::Create()
                        $hashBytes = $sha256.ComputeHash($stream)
                        $stream.Close()
                        $currentHash = ([BitConverter]::ToString($hashBytes) -replace '-', '').ToLower()
                        if ($currentHash -eq $entry.hash) { $verified++ }
                        else { $tampered += @{ file = $entry.file; path = $entry.path; expected = $entry.hash; actual = $currentHash } }
                    } catch { $tampered += @{ file = $entry.file; path = $entry.path; error = "$_" } }
                } else { $tampered += @{ file = $entry.file; path = $entry.path; error = "not_found" } }
            }
        } catch { }
    }

    if ($tampered.Count -gt 0) {
        foreach ($t in $tampered) {
            Write-Host "  [CRITICAL] HARDENING: Integritaetsverletzung - $($t.file) ($($t.error))" -ForegroundColor Red
        }
    }

    return @{ verified = $verified; total = $total; tampered = $tampered.Count; tampered_details = $tampered }
}

function Protect-JDSConfigSensitive {
    param([hashtable]$Config)
    $cfg = $Config.security_hardening
    if (-not $cfg.enabled -or -not $cfg.encrypt_config) { return $Config }

    $sensitiveFields = @("smtp_password", "password", "run_as_password", "api_key", "secret")

    function Encrypt-Value {
        param([string]$Value)
        if ([string]::IsNullOrEmpty($Value) -or $Value -match "^\*") { return $Value }
        try {
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($Value)
            $encrypted = [System.Security.Cryptography.ProtectedData]::Protect($bytes, $null, [System.Security.Cryptography.DataProtectionScope]::LocalMachine)
            return "*DPAPI:" + [Convert]::ToBase64String($encrypted)
        } catch { return $Value }
    }

    function Walk-Hashtable {
        param([hashtable]$Hash)
        foreach ($key in $Hash.Keys) {
            if ($Hash[$key] -is [hashtable]) { Walk-Hashtable -Hash $Hash[$key] }
            elseif ($Hash[$key] -is [string] -and $sensitiveFields -contains $key) {
                $Hash[$key] = Encrypt-Value -Value $Hash[$key]
            }
        }
    }

    $ConfigCopy = $Config.Clone()
    Walk-Hashtable -Hash $ConfigCopy
    return $ConfigCopy
}

function Unprotect-JDSConfigSensitive {
    param([hashtable]$Config)
    $cfg = $Config.security_hardening
    if (-not $cfg.enabled -or -not $cfg.encrypt_config) { return $Config }

    $ConfigCopy = $Config.Clone()

    function Decrypt-Value {
        param([string]$Value)
        if ([string]::IsNullOrEmpty($Value) -or $Value -notmatch "^\*DPAPI:") { return $Value }
        try {
            $b64 = $Value.Substring(7)
            $bytes = [Convert]::FromBase64String($b64)
            $decrypted = [System.Security.Cryptography.ProtectedData]::Unprotect($bytes, $null, [System.Security.Cryptography.DataProtectionScope]::LocalMachine)
            return [System.Text.Encoding]::UTF8.GetString($decrypted)
        } catch { return $Value }
    }

    $sensitiveFields = @("smtp_password", "password", "run_as_password", "api_key", "secret")

    function Walk-Hashtable2 {
        param([hashtable]$Hash)
        foreach ($key in @($Hash.Keys)) {
            if ($Hash[$key] -is [hashtable]) { Walk-Hashtable2 -Hash $Hash[$key] }
            elseif ($Hash[$key] -is [string] -and $sensitiveFields -contains $key) {
                $Hash[$key] = Decrypt-Value -Value $Hash[$key]
            }
        }
    }

    Walk-Hashtable2 -Hash $ConfigCopy
    return $ConfigCopy
}
function Start-JDSWatchdog {
    param([hashtable]$Config)
    $cfg = $Config.security_hardening
    if (-not $cfg.enabled -or -not $cfg.watchdog_enabled) { return }

    Write-Host "  [INFO] HARDENING: Watchdog gestartet (Prozess-Schutz)" -ForegroundColor Green

    $serviceName = "JDSSecure"
    $scriptName = "jds-secure.ps1"

    $query = "SELECT * FROM Win32_ProcessStopTrace WHERE ProcessName LIKE '%$scriptName%' OR ProcessName LIKE '%$serviceName%'"

    try {
        $watchdogJob = Start-Job -Name "JDS-Watchdog" -ScriptBlock {
            param($svcName, $cfgPath)
            while ($true) {
                $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
                if ($svc -and $svc.Status -ne "Running") {
                    try {
                        Start-Service -Name $svcName -ErrorAction SilentlyContinue
                    } catch { }
                }
                $jdsProcess = Get-Process -Name "powershell" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match "jds-secure" -or $_.CommandLine -match "jds-service" }
                if (-not $jdsProcess -and (Get-Service $svcName -ErrorAction SilentlyContinue)) {
                    try { Start-Service -Name $svcName -ErrorAction SilentlyContinue } catch { }
                }
                Start-Sleep -Seconds 30
            }
        } -ArgumentList $serviceName, $Config.general.install_path

        $script:JDSWatchdogJob = $watchdogJob
    } catch {
        Write-Host "  [WARN] HARDENING: Watchdog konnte nicht gestartet werden: $_" -ForegroundColor Yellow
    }
}

function Stop-JDSWatchdog {
    if ($script:JDSWatchdogJob) {
        try { Stop-Job $script:JDSWatchdogJob -ErrorAction SilentlyContinue; Remove-Job $script:JDSWatchdogJob -Force -ErrorAction SilentlyContinue } catch { }
        $script:JDSWatchdogJob = $null
    }
}

function Get-JDSHardeningStatus {
    param([hashtable]$Config)
    $cfg = $Config.security_hardening

    $status = @{
        config_encrypted = $false
        manifest_exists = $false
        modules_verified = 0
        modules_total = 0
        tampered = 0
        watchdog_running = $false
        log_signing_active = $false
        overall_status = "safe"
    }

    if (-not $cfg.enabled) { $status.overall_status = "disabled"; return $status }

    $manifestPath = Join-Path $Config.general.install_path "config\module-manifest.json"
    $status.manifest_exists = Test-Path $manifestPath

    $status.watchdog_running = $null -ne $script:JDSWatchdogJob
    $status.log_signing_active = $cfg.sign_logs -eq $true

    $keyPath = Join-Path $Config.general.data_path ".jds-key"
    $status.config_encrypted = Test-Path $keyPath

    if ($status.manifest_exists) {
        $integrity = Test-JDSModuleIntegrity -Config $Config
        $status.modules_verified = $integrity.verified
        $status.modules_total = $integrity.total
        $status.tampered = $integrity.tampered
    }

    if ($status.tampered -gt 0) { $status.overall_status = "danger" }
    elseif (-not $status.config_encrypted) { $status.overall_status = "warn" }
    elseif (-not $status.watchdog_running) { $status.overall_status = "warn" }
    else { $status.overall_status = "safe" }

    return $status
}

function Protect-JDSLog {
    param(
        [hashtable]$Config,
        [string]$LogFilePath
    )
    $cfg = $Config.security_hardening
    if (-not $cfg.enabled -or -not $cfg.sign_logs) { return }

    if (-not (Test-Path $LogFilePath)) { return }

    try {
        $logContent = Get-Content -Path $LogFilePath -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
        if (-not $logContent) { return }
        $logBytes = [System.Text.Encoding]::UTF8.GetBytes($logContent)
        $hmac = New-Object System.Security.Cryptography.HMACSHA256
        if ($script:JDSSigningKey) {
            $hmac.Key = $script:JDSSigningKey
        } else {
            $keyPath = Join-Path $Config.general.data_path ".jds-key"
            if (Test-Path $keyPath) {
                try {
                    $dpapiBytes = [System.IO.File]::ReadAllBytes($keyPath)
                    $keyBytes = [System.Security.Cryptography.ProtectedData]::Unprotect($dpapiBytes, $null, [System.Security.Cryptography.DataProtectionScope]::LocalMachine)
                    $hmac.Key = $keyBytes
                } catch { return }
            } else { return }
        }
        $hashBytes = $hmac.ComputeHash($logBytes)
        $signature = [Convert]::ToBase64String($hashBytes)
        $sigLine = "--- JDS-SIG: $signature ---"
        $existingLines = Get-Content -Path $LogFilePath -Encoding UTF8 -ErrorAction SilentlyContinue
        $existingLines = $existingLines | Where-Object { $_ -notmatch "^--- JDS-SIG:" }
        $existingLines + $sigLine | Set-Content -Path $LogFilePath -Encoding UTF8 -Force
    } catch { }
}

function Test-JDSLogIntegrity {
    param(
        [hashtable]$Config,
        [string]$LogFilePath
    )
    if (-not (Test-Path $LogFilePath)) { return @{ valid = $true; reason = "no_log" } }

    try {
        $lines = Get-Content -Path $LogFilePath -Encoding UTF8 -ErrorAction SilentlyContinue
        $sigLine = $lines | Where-Object { $_ -match "^--- JDS-SIG:" }
        if (-not $sigLine) { return @{ valid = $true; reason = "no_sig" } }

        $storedSig = ($sigLine -replace "^--- JDS-SIG: ", "") -replace " ---$", ""
        $contentLines = $lines | Where-Object { $_ -notmatch "^--- JDS-SIG:" }
        $content = $contentLines -join "`r`n"
        $contentBytes = [System.Text.Encoding]::UTF8.GetBytes($content)

        $hmac = New-Object System.Security.Cryptography.HMACSHA256
        if ($script:JDSSigningKey) {
            $hmac.Key = $script:JDSSigningKey
        } else {
            $keyPath = Join-Path $Config.general.data_path ".jds-key"
            if (Test-Path $keyPath) {
                $dpapiBytes = [System.IO.File]::ReadAllBytes($keyPath)
                $keyBytes = [System.Security.Cryptography.ProtectedData]::Unprotect($dpapiBytes, $null, [System.Security.Cryptography.DataProtectionScope]::LocalMachine)
                $hmac.Key = $keyBytes
            } else { return @{ valid = $true; reason = "no_key" } }
        }
        $expectedSig = [Convert]::ToBase64String($hmac.ComputeHash($contentBytes))
        $valid = $storedSig -eq $expectedSig
        return @{ valid = $valid; reason = if ($valid) { "ok" } else { "signature_mismatch" } }
    } catch { return @{ valid = $true; reason = "error" } }
}

function Repair-JDSInstallation {
    param([hashtable]$Config)
    Write-Host "  [WARN] HARDENING: Automatische Reparatur gestartet" -ForegroundColor Yellow

    $issues = @()
    $fixed = 0

    $manifestPath = Join-Path $Config.general.install_path "config\module-manifest.json"
    $corePath = Join-Path $Config.general.install_path "config\core-manifest.json"

    if (-not (Test-Path $manifestPath)) {
        $result = New-JDSModuleManifest -Config $Config
        if ($result.success) { $fixed++; $issues += "Neues Modul-Manifest erstellt" }
    }

    $integrity = Test-JDSModuleIntegrity -Config $Config
    if ($integrity.tampered -gt 0) {
        foreach ($t in $integrity.tampered_details) {
            if ($t.error -eq "not_found") {
                Write-Host "  [CRITICAL] HARDENING: Modul $($t.file) fehlt - kann nicht repariert werden" -ForegroundColor Red
                $issues += "Modul $($t.file) fehlt (manuelle Reparatur erforderlich)"
            }
        }
        $result = New-JDSModuleManifest -Config $Config
        if ($result.success) { $fixed++; $issues += "Manifest neu erstellt" }
    }

    $svc = Get-Service -Name "JDSSecure" -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -ne "Running") {
        try { Start-Service -Name "JDSSecure" -ErrorAction SilentlyContinue; $fixed++ } catch { }
    }

    return @{
        issues_found = $issues.Count
        issues = $issues
        fixed = $fixed
    }
}
