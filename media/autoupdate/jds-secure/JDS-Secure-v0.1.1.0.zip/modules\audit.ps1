﻿function Initialize-JDSAudit {
    param([hashtable]$Config)

    $audit = $Config.audit
    if (-not $audit.enabled) { Write-JDSLog "WARN" "Audit module is disabled"; return }

    Write-JDSLog "INFO" "Initializing audit system..."

    try {
        $logDir = Split-Path $audit.log_file -Parent
        $fullLogDir = if ([System.IO.Path]::IsPathRooted($audit.log_file)) {
            $logDir
        } else {
            "$PSScriptRoot\..\$logDir"
        }

        if (-not (Test-Path $fullLogDir)) {
            New-Item -ItemType Directory -Path $fullLogDir -Force | Out-Null
        }

        $auditPolicies = @{
            "AuditAccountLogon" = "SuccessAndFailure"
            "AuditLogon" = "SuccessAndFailure"
            "AuditObjectAccess" = "SuccessAndFailure"
            "AuditPrivilegeUse" = "SuccessAndFailure"
            "AuditProcessCreation" = "SuccessAndFailure"
            "AuditSystemEvents" = "SuccessAndFailure"
            "AuditAccountManage" = "SuccessAndFailure"
            "AuditDirectoryServiceAccess" = "SuccessAndFailure"
            "AuditPolicyChange" = "SuccessAndFailure"
        }

        foreach ($policy in $auditPolicies.Keys) {
            try {
                $currentSetting = auditpol /get /subcategory:"$policy" 2>$null
                if ($currentSetting -notmatch $auditPolicies[$policy]) {
                    auditpol /set /subcategory:"$policy" /success:enable /failure:enable 2>$null | Out-Null
                    Write-JDSLog "INFO" "Set audit policy: $policy = $($auditPolicies[$policy])"
                }
            } catch {}
        }

        Write-JDSLog "INFO" "Audit system initialized with enhanced logging policies"

    } catch {
        Write-JDSLog "ERROR" "Audit initialization failed: $_"
    }
}

function Write-JDSLog {
    param(
        [string]$Level,
        [string]$Message
    )

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] [$Level] $Message"

    $config = Get-JDSConfig -ErrorAction SilentlyContinue
    $logFile = if ($config -and $config.audit -and $config.audit.log_file) {
        $lf = $config.audit.log_file
        if ([System.IO.Path]::IsPathRooted($lf)) { $lf }
        else { "$PSScriptRoot\..\$lf" }
    } else {
        "$PSScriptRoot\..\logs\jds-audit.log"
    }

    try {
        $logDir = Split-Path $logFile -Parent
        if (-not (Test-Path $logDir)) {
            New-Item -ItemType Directory -Path $logDir -Force | Out-Null
        }
        Add-Content -Path $logFile -Value $logEntry -Encoding UTF8
    } catch {}

    switch ($Level) {
        "ERROR"   { Write-Host $logEntry -ForegroundColor Red }
        "WARN"    { Write-Host $logEntry -ForegroundColor Yellow }
        "INFO"    { Write-Host $logEntry -ForegroundColor Green }
        "CRITICAL" { Write-Host $logEntry -ForegroundColor DarkRed -BackgroundColor White }
        default   { Write-Host $logEntry }
    }
}

function Get-JDSConfig {
    $configPath = "$PSScriptRoot\..\config\security-config.json"
    if (Test-Path $configPath) {
        try {
            return Get-Content $configPath -Raw | ConvertFrom-Json
        } catch {
            return $null
        }
    }
    return $null
}

function Invoke-JDSAuditScan {
    param([hashtable]$Config)

    $audit = $Config.audit
    Write-JDSLog "INFO" "Running audit scan..."

    $findings = @()

    try {
        if ($audit.audit_user_actions) {
            $recentLogons = Get-WinEvent -FilterHashtable @{LogName='Security'; ID=4624} -MaxEvents 100 -ErrorAction SilentlyContinue |
                Where-Object { $_.TimeCreated -gt (Get-Date).AddHours(-1) }

            $adminLogons = $recentLogons | Where-Object {
                $_.Message -match "Administrator" -or $_.Properties[5].Value -match "Admin"
            }

            if ($adminLogons.Count -gt 0) {
                Write-JDSLog "INFO" "$($adminLogons.Count) Administrator-Logon(s) in der letzten Stunde"
            }
        }

        if ($audit.audit_process_creation) {
            $newProcesses = Get-WinEvent -FilterHashtable @{LogName='Security'; ID=4688} -MaxEvents 50 -ErrorAction SilentlyContinue |
                Where-Object { $_.TimeCreated -gt (Get-Date).AddMinutes(-15) }

            foreach ($proc in $newProcesses) {
                if ($proc.Message -match "Creator Process Name:\s+(.+)" -and $Matches[1] -match "powershell|cmd|wscript|cscript") {
                    Write-JDSLog "INFO" "New process: $($Matches[1])"
                }
            }
        }

        $eventLogs = @("Security", "Application", "System", "Windows PowerShell")
        $errors = 0
        foreach ($log in $eventLogs) {
            try {
                $recentErrors = Get-WinEvent -LogName $log -MaxEvents 200 -ErrorAction SilentlyContinue |
                    Where-Object { $_.LevelDisplayName -eq "Error" -and $_.TimeCreated -gt (Get-Date).AddHours(-24) }

                $errors += $recentErrors.Count
            } catch {}
        }

        if ($errors -gt 0) {
            Write-JDSLog "INFO" "$errors Error-Ereignisse in den letzten 24h in Event-Logs"
        }

        if ($audit.audit_admin_actions) {
            $adminChanges = Get-WinEvent -FilterHashtable @{LogName='Security'; ID=4732,4733,4728,4729,4756} -MaxEvents 50 -ErrorAction SilentlyContinue |
                Where-Object { $_.TimeCreated -gt (Get-Date).AddHours(-24) }

            if ($adminChanges.Count -gt 0) {
                Write-JDSLog "WARN" "$($adminChanges.Count) Gruppenmitgliedschaftsaenderungen in den letzten 24h"
                $findings += "Admin group changes detected: $($adminChanges.Count)"
            }
        }

        if ($audit.audit_file_access) {
            try {
                $fileAudit = Get-WinEvent -FilterHashtable @{LogName='Security'; ID=4663} -MaxEvents 100 -ErrorAction SilentlyContinue |
                    Where-Object { $_.TimeCreated -gt (Get-Date).AddHours(-1) }

                $sensitiveAccess = $fileAudit | Where-Object {
                    $_.Message -match "CustomerData|ClientData|BusinessData|Kunden"
                }

                if ($sensitiveAccess.Count -gt 0) {
                    Write-JDSLog "WARN" "$($sensitiveAccess.Count) Zugriffe auf sensible Daten in der letzten Stunde"
                    $findings += "Sensitive file access detected: $($sensitiveAccess.Count) times"
                }
            } catch {}
        }

        Write-JDSLog "INFO" "Audit scan completed"

        return [PSCustomObject]@{
            ScanTime = Get-Date
            Findings = $findings
            ErrorCount = $errors
        }
    } catch {
        Write-JDSLog "ERROR" "Audit scan failed: $_"
        return $null
    }
}

function Send-JDSAlert {
    param(
        [hashtable]$Config,
        [hashtable]$Alert
    )

    $alertConfig = $Config.alerts
    $severity = $Alert.type

    if (-not $alertConfig.$severity) { return }

    $alertSettings = $alertConfig.$severity
    $message = "[JDS-Secure] $($Alert.title): $($Alert.message)"

    if ($alertSettings.log) {
        Write-JDSLog $Alert.type $Alert.message
    }

    # Bewusst KEIN Popup-Fenster hier: Send-JDSAlert wird auch aus
    # Hintergrund-Loops (Service-Modus, geplante Tasks) aufgerufen, in denen
    # ein wiederkehrender Zustand sonst alle paar Minuten ein neues Popup
    # erzeugen wuerde. Alarme landen stattdessen im Audit-Log und werden im
    # Dashboard (Tab "Ereignisse & Quarantaene") angezeigt und verwaltet.

    if ($alertSettings.sound) {
        try {
            [System.Console]::Beep(1000, 500)
        } catch {}
    }

    if ($alertSettings.email -and $Config.audit.send_email_alerts) {
        try {
            Send-JDSAlertEmail -Config $Config -Alert $Alert
        } catch {
            Write-JDSLog "WARN" "Failed to send alert email: $_"
        }
    }
}

function Send-JDSAlertEmail {
    param(
        [hashtable]$Config,
        [hashtable]$Alert
    )

    $audit = $Config.audit
    if (-not $audit.smtp_server -or -not $audit.alert_recipients) { return }

    try {
        $mailParams = @{
            SmtpServer = $audit.smtp_server
            Port = $audit.smtp_port
            From = "jds-secure@$($env:COMPUTERNAME).local"
            To = $audit.alert_recipients
            Subject = "[JDS-Secure] $($Alert.type): $($Alert.title)"
            Body = "JDS-Secure Alert`n`nDatum: $(Get-Date -Format 'dd.MM.yyyy HH:mm:ss')`nServer: $env:COMPUTERNAME`nTyp: $($Alert.type)`nTitel: $($Alert.title)`nNachricht: $($Alert.message)"
        }

        if ($audit.smtp_user) {
            $securePass = ConvertTo-SecureString $audit.smtp_password -AsPlainText -Force
            $credential = New-Object System.Management.Automation.PSCredential($audit.smtp_user, $securePass)
            $mailParams.Credential = $credential
            $mailParams.UseSsl = $true
        }

        Send-MailMessage @mailParams -ErrorAction SilentlyContinue
    } catch {}
}

function New-JDSAuditReport {
    param(
        [hashtable]$Config,
        [int]$Hours = 24
    )

    Write-JDSLog "INFO" "Generating audit report for last $Hours hours..."

    try {
        $report = @{
            GeneratedAt = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            ServerName = $env:COMPUTERNAME
            Period = "Last $Hours hours"
            LogonEvents = @()
            AdminChanges = @()
            FailedLogons = 0
            SuccessfulLogons = 0
            ServiceChanges = 0
        }

        $failedLogons = Get-WinEvent -FilterHashtable @{LogName='Security'; ID=4625} -MaxEvents 1000 -ErrorAction SilentlyContinue |
            Where-Object { $_.TimeCreated -gt (Get-Date).AddHours(-$Hours) }
        $report.FailedLogons = $failedLogons.Count

        $successLogons = Get-WinEvent -FilterHashtable @{LogName='Security'; ID=4624} -MaxEvents 1000 -ErrorAction SilentlyContinue |
            Where-Object { $_.TimeCreated -gt (Get-Date).AddHours(-$Hours) }
        $report.SuccessfulLogons = $successLogons.Count

        $serviceInstalls = Get-WinEvent -FilterHashtable @{LogName='System'; ID=7045} -MaxEvents 100 -ErrorAction SilentlyContinue |
            Where-Object { $_.TimeCreated -gt (Get-Date).AddHours(-$Hours) }
        $report.ServiceChanges = $serviceInstalls.Count

        $reportPath = "$PSScriptRoot\..\logs\audit-report_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
        $report | ConvertTo-Json -Depth 10 | Set-Content $reportPath -Force -Encoding UTF8

        Write-JDSLog "INFO" "Audit report saved to: $reportPath"

        return $report
    } catch {
        Write-JDSLog "ERROR" "Failed to generate audit report: $_"
        return $null
    }
}


