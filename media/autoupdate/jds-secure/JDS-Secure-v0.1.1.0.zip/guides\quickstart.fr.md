# JDS Secure - Guide de demarrage rapide (Francais)

## Installation

```powershell
.\setup.ps1 -Easy
```

Ou avec assistant graphique :

```powershell
.\setup.ps1 -GUI
```

## Lancement

```powershell
.\jds-secure.ps1 -Mode GUI          # Interface graphique (recommande)
.\jds-secure.ps1 -Mode Interactive  # Menu console
.\jds-secure.ps1 -Mode Service      # Service d'arriere-plan (14 daemons)
.\jds-secure.ps1 -Mode QuickScan    # Analyse rapide
```

## Commandes rapides

| Action | Commande |
|--------|----------|
| Analyse complete | `Invoke-FullScan` |
| Sauvegarde | `Invoke-BackupSystem` |
| Renforcer pare-feu | `Invoke-FirewallHardening` |
| Signalement RGPD | `New-GDPRBreachNotification` |
| Analyse antivirus | `Invoke-VirusScan -ScanType quick` |
| Rapport de securite | `Export-SecurityReport` |

## Obligations RGPD

- **Art. 33**: Notification de violation via menu 19
- **Art. 30**: Registre des traitements via menu RGPD (option 4)
- **Art. 32**: Documentation MTO via menu RGPD (option 5)
- **Art. 17**: Effacement des donnees via nettoyage (option 2)

## Configuration requise

- Windows 10/11 ou Windows Server 2016+
- PowerShell 5.1+
- Droits d'administrateur pour l'installation du pare-feu/service

---

## Clause de non-responsabilite

Ce logiciel est fourni "en l'etat", sans garantie d'aucune sorte. Il assiste
dans le respect des normes de securite et des exigences RGPD mais ne constitue
pas un conseil juridique. Une consultation professionnelle aupres d'un delegue
a la protection des donnees et d'un conseiller juridique est requise avant
toute utilisation en production. L'auteur decline toute responsabilite en cas
de dommages decoulant de son utilisation.
