﻿function Show-JDSGUI {
    param([hashtable]$Config)

    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    Add-Type -AssemblyName System.Management

    $script:guiConfig = $Config
    $script:guiRunning = $true
    $script:scanResults = @{}

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "JDS Secure - Enterprise Security Suite v$script:JDSVersion"
    $form.Size = New-Object System.Drawing.Size(1100, 1050)
    $form.StartPosition = "CenterScreen"
    $form.MinimumSize = New-Object System.Drawing.Size(900, 800)
    $form.WindowState = [System.Windows.Forms.FormWindowState]::Maximized
    $form.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
    $form.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Regular)
    try { $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon("powershell.exe") } catch { }

    function Get-StatusColor {
        param([string]$Status)
        switch ($Status) {
            "safe"  { return [System.Drawing.Color]::FromArgb(0, 230, 118) }
            "warn"  { return [System.Drawing.Color]::FromArgb(255, 171, 0) }
            "danger" { return [System.Drawing.Color]::FromArgb(255, 23, 68) }
            "info"  { return [System.Drawing.Color]::FromArgb(0, 212, 255) }
            default { return [System.Drawing.Color]::FromArgb(100, 116, 139) }
        }
    }

    function Get-StatusIcon {
        param([string]$Status)
        switch ($Status) {
            "safe"  { return [char]0x2713 }   # check mark
            "warn"  { return [char]0x26A0 }   # warning triangle
            "danger" { return [char]0x2715 }  # heavy X
            "info"  { return [char]0x2139 }   # info
            default { return [char]0x2022 }   # bullet
        }
    }

    function New-RoundedRectPath {
        param([System.Drawing.Rectangle]$Rect, [int]$Radius = 12)
        $d = $Radius * 2
        $path = New-Object System.Drawing.Drawing2D.GraphicsPath
        $path.AddArc($Rect.X, $Rect.Y, $d, $d, 180, 90)
        $path.AddArc($Rect.Right - $d, $Rect.Y, $d, $d, 270, 90)
        $path.AddArc($Rect.Right - $d, $Rect.Bottom - $d, $d, $d, 0, 90)
        $path.AddArc($Rect.X, $Rect.Bottom - $d, $d, $d, 90, 90)
        $path.CloseFigure()
        return $path
    }

    function New-RoundedPanel {
        param([int]$X, [int]$Y, [int]$W, [int]$H, [string]$Color = "#1E293B", [int]$Radius = 14, [string]$BlendColor = "#0F172A")
        $panel = New-Object System.Windows.Forms.Panel
        $panel.Location = New-Object System.Drawing.Point($X, $Y)
        $panel.Size = New-Object System.Drawing.Size($W, $H)
        $panel.BackColor = [System.Drawing.ColorTranslator]::FromHtml($BlendColor)
        $panel.BorderStyle = [System.Windows.Forms.BorderStyle]::None
        $fillColor = [System.Drawing.ColorTranslator]::FromHtml($Color)
        $panel.Add_Paint({
            param($sender, $e)
            $e.Graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
            $rect = New-Object System.Drawing.Rectangle(0, 0, ($sender.Width - 1), ($sender.Height - 1))
            $gp = New-RoundedRectPath -Rect $rect -Radius $Radius
            $brush = New-Object System.Drawing.SolidBrush($fillColor)
            $e.Graphics.FillPath($brush, $gp)
            $brush.Dispose()
            $gp.Dispose()
        }.GetNewClosure())
        return $panel
    }

    function New-StatusCard {
        param([int]$X, [int]$Y, [int]$W, [string]$Title, [string]$Value, [string]$Status = "info")
        $card = New-RoundedPanel -X $X -Y $Y -W $W -H 90 -Color "#1E293B"

        $iconLabel = New-Object System.Windows.Forms.Label
        $iconLabel.Text = Get-StatusIcon $Status
        $iconLabel.Location = New-Object System.Drawing.Point(15, 12)
        $iconLabel.Size = New-Object System.Drawing.Size(30, 30)
        $iconLabel.Font = New-Object System.Drawing.Font("Segoe UI", 18, [System.Drawing.FontStyle]::Bold)
        $iconLabel.ForeColor = Get-StatusColor $Status
        $card.Controls.Add($iconLabel)

        $titleLabel = New-Object System.Windows.Forms.Label
        $titleLabel.Text = $Title
        $titleLabel.Location = New-Object System.Drawing.Point(50, 12)
        $titleLabel.Size = New-Object System.Drawing.Size($W - 60, 22)
        $titleLabel.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
        $titleLabel.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
        $card.Controls.Add($titleLabel)

        $valueLabel = New-Object System.Windows.Forms.Label
        $valueLabel.Text = $Value
        $valueLabel.Location = New-Object System.Drawing.Point(50, 38)
        $valueLabel.Size = New-Object System.Drawing.Size($W - 60, 40)
        $valueLabel.Font = New-Object System.Drawing.Font("Segoe UI", 20, [System.Drawing.FontStyle]::Bold)
        $valueLabel.ForeColor = Get-StatusColor $Status
        $card.Controls.Add($valueLabel)

        return $card
    }

    function New-ActionButton {
        param([int]$X, [int]$Y, [int]$W, [int]$H, [string]$Text, [string]$Color = "#0EA5E9", [scriptblock]$ClickAction, [int]$Radius = 8)
        $btn = New-Object System.Windows.Forms.Button
        $btn.Location = New-Object System.Drawing.Point($X, $Y)
        $btn.Size = New-Object System.Drawing.Size($W, $H)
        $btn.Text = $Text
        $btn.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $btn.FlatAppearance.BorderSize = 0
        $baseColor = [System.Drawing.ColorTranslator]::FromHtml($Color)
        $hoverColor = [System.Drawing.Color]::FromArgb(
            [Math]::Min(255, $baseColor.R + 25),
            [Math]::Min(255, $baseColor.G + 25),
            [Math]::Min(255, $baseColor.B + 25)
        )
        $btn.BackColor = $baseColor
        $btn.ForeColor = [System.Drawing.Color]::White
        $btn.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
        $btn.Cursor = [System.Windows.Forms.Cursors]::Hand
        $btn.Add_Click($ClickAction)
        $btn.Add_MouseEnter({ $this.BackColor = $hoverColor }.GetNewClosure())
        $btn.Add_MouseLeave({ $this.BackColor = $baseColor }.GetNewClosure())
        $btnPath = New-RoundedRectPath -Rect (New-Object System.Drawing.Rectangle(0, 0, $W, $H)) -Radius $Radius
        $btn.Region = New-Object System.Drawing.Region($btnPath)
        return $btn
    }

    function New-SectionLabel {
        param([int]$X, [int]$Y, [int]$W, [string]$Text)
        $lbl = New-Object System.Windows.Forms.Label
        $lbl.Text = $Text
        $lbl.Location = New-Object System.Drawing.Point($X, $Y)
        $lbl.Size = New-Object System.Drawing.Size($W, 25)
        $lbl.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
        $lbl.ForeColor = [System.Drawing.Color]::FromArgb(0, 212, 255)
        return $lbl
    }

    function Invoke-JDSUpdateCheck {
        param([switch]$Silent)

        try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }

        $versionFile = Join-Path $script:ScriptPath "version.txt"
        $currentVersion = if (Test-Path $versionFile) { (Get-Content $versionFile -Raw).Trim() } else { "$script:JDSVersion.0" }

        try {
            $uri = "https://joel-digitals.de/api/autoupdate/check/jds-secure/?current_version=$currentVersion"
            $result = Invoke-RestMethod -Uri $uri -Method Get -TimeoutSec 6 -UseBasicParsing
        } catch {
            $updateStatusLabel.Text = "Update-Pruefung nicht moeglich"
            $updateStatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(100, 116, 139)
            if (-not $Silent) {
                [System.Windows.Forms.MessageBox]::Show("Update-Pruefung fehlgeschlagen:`n$($_.Exception.Message)", "JDS Secure - Autoupdate", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
            }
            return
        }

        if ($result.update_available) {
            $updateStatusLabel.Text = "Update verfuegbar: v$($result.latest_version)"
            $updateStatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(255, 171, 0)
            $msg = "Eine neue Version ist verfuegbar!`n`nInstalliert: v$currentVersion`nNeu:        v$($result.latest_version)`n`n$($result.release_notes)`n`nJetzt Download-Seite oeffnen?"
            $choice = [System.Windows.Forms.MessageBox]::Show($msg, "JDS Secure - Update verfuegbar", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Information)
            if ($choice -eq [System.Windows.Forms.DialogResult]::Yes -and $result.download_link) {
                Start-Process $result.download_link
            }
        } else {
            $updateStatusLabel.Text = "Aktuell (v$currentVersion)"
            $updateStatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(0, 230, 118)
            if (-not $Silent) {
                [System.Windows.Forms.MessageBox]::Show("Sie verwenden bereits die aktuelle Version (v$currentVersion).", "JDS Secure - Autoupdate", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
            }
        }
    }

    function Update-Dashboard {
        $fwEnabled = $script:guiConfig.firewall.enabled
        $idsEnabled = $script:guiConfig.ids.enabled
        $encEnabled = $script:guiConfig.encryption.enabled
        $bkpEnabled = $script:guiConfig.backup.enabled
        $hpEnabled = $script:guiConfig.honeypot.enabled
        $rswEnabled = $script:guiConfig.ransomware.enabled
        $fiEnabled = $script:guiConfig.file_integrity.enabled
        $psEnabled = $script:guiConfig.process_security.enabled
        $nsEnabled = $script:guiConfig.network_security.enabled
        $vsEnabled = $script:guiConfig.vulnerability_scan.enabled
        $sdEnabled = $script:guiConfig.self_defense.enabled
        $vcEnabled = $script:guiConfig.virus_scan.enabled
        $qcEnabled = $script:guiConfig.quarantine.enabled
        $gdEnabled = $script:guiConfig.gdpr.enabled
        $shEnabled = $script:guiConfig.security_hardening.enabled

        try {
            $fwStatus = Get-NetFirewallProfile -Profile Domain -ErrorAction SilentlyContinue
            $fwActive = $fwStatus -and $fwStatus.Enabled
        } catch { $fwActive = $false }

        try {
            $running = (Get-Service | Where-Object { $_.Status -eq 'Running' }).Count
        } catch { $running = 0 }

        try {
            $failedLogins = (Get-WinEvent -FilterHashtable @{LogName='Security'; ID=4625} -MaxEvents 500 -ErrorAction SilentlyContinue | Where-Object { $_.TimeCreated -gt (Get-Date).AddHours(-24) }).Count
        } catch { $failedLogins = 0 }

        $statusFW = if ($fwActive) { "safe" } else { "warn" }
        $statusIDS = if ($idsEnabled) { "safe" } else { "warn" }
        $statusEnc = if ($encEnabled) { "safe" } else { "warn" }
        $statusBkp = if ($bkpEnabled) { "safe" } else { "warn" }
        $statusLogins = if ($failedLogins -gt 10) { "danger" } elseif ($failedLogins -gt 5) { "warn" } else { "safe" }

        $dashboardPanel.Controls.Clear()

        $title = New-SectionLabel -X 20 -Y 10 -W 400 -Text "System-Status"
        $dashboardPanel.Controls.Add($title)

        $dashboardPanel.Controls.Add((New-StatusCard -X 20 -Y 40 -W 215 -Title "Firewall" -Value $(if ($fwActive) { "AKTIV" } else { "INAKTIV" }) -Status $statusFW))
        $dashboardPanel.Controls.Add((New-StatusCard -X 245 -Y 40 -W 215 -Title "IDS-UEberwachung" -Value $(if ($idsEnabled) { "AKTIV" } else { "AUS" }) -Status $statusIDS))
        $dashboardPanel.Controls.Add((New-StatusCard -X 470 -Y 40 -W 215 -Title "Verschluesselung" -Value $(if ($encEnabled) { "AKTIV" } else { "AUS" }) -Status $statusEnc))
        $dashboardPanel.Controls.Add((New-StatusCard -X 20 -Y 140 -W 215 -Title "Backup" -Value $(if ($bkpEnabled) { "BEREIT" } else { "AUS" }) -Status $statusBkp))
        $dashboardPanel.Controls.Add((New-StatusCard -X 245 -Y 140 -W 215 -Title "Fehlanmeldungen" -Value "$failedLogins" -Status $statusLogins))
        $dashboardPanel.Controls.Add((New-StatusCard -X 470 -Y 140 -W 215 -Title "Aktive Dienste" -Value "$running" -Status "info"))

        $dashboardPanel.Controls.Add((New-StatusCard -X 20 -Y 240 -W 215 -Title "Ransomware-Schutz" -Value $(if ($rswEnabled) { "AKTIV" } else { "AUS" }) -Status $(if ($rswEnabled) { "safe" } else { "warn" })))
        $dashboardPanel.Controls.Add((New-StatusCard -X 245 -Y 240 -W 215 -Title "File-Integritaet" -Value $(if ($fiEnabled) { "AKTIV" } else { "AUS" }) -Status $(if ($fiEnabled) { "safe" } else { "warn" })))
        $dashboardPanel.Controls.Add((New-StatusCard -X 470 -Y 240 -W 215 -Title "Prozess-Security" -Value $(if ($psEnabled) { "AKTIV" } else { "AUS" }) -Status $(if ($psEnabled) { "safe" } else { "warn" })))
        $dashboardPanel.Controls.Add((New-StatusCard -X 20 -Y 340 -W 215 -Title "Netzwerk-Security" -Value $(if ($nsEnabled) { "AKTIV" } else { "AUS" }) -Status $(if ($nsEnabled) { "safe" } else { "warn" })))
        $dashboardPanel.Controls.Add((New-StatusCard -X 245 -Y 340 -W 215 -Title "Vulnerability-Scan" -Value $(if ($vsEnabled) { "AKTIV" } else { "AUS" }) -Status $(if ($vsEnabled) { "safe" } else { "warn" })))
        $dashboardPanel.Controls.Add((New-StatusCard -X 470 -Y 340 -W 215 -Title "Honeypot" -Value $(if ($hpEnabled) { "AKTIV" } else { "AUS" }) -Status $(if ($hpEnabled) { "safe" } else { "warn" })))
        $dashboardPanel.Controls.Add((New-StatusCard -X 20 -Y 440 -W 215 -Title "Selbstschutz" -Value $(if ($sdEnabled) { "AKTIV" } else { "AUS" }) -Status $(if ($sdEnabled) { "safe" } else { "warn" })))
        $dashboardPanel.Controls.Add((New-StatusCard -X 245 -Y 440 -W 215 -Title "Virenscan" -Value $(if ($vcEnabled) { "AKTIV" } else { "AUS" }) -Status $(if ($vcEnabled) { "safe" } else { "warn" })))
        $dashboardPanel.Controls.Add((New-StatusCard -X 470 -Y 440 -W 215 -Title "DSGVO-Compliance" -Value $(if ($gdEnabled) { "AKTIV" } else { "AUS" }) -Status $(if ($gdEnabled) { "safe" } else { "warn" })))
        $dashboardPanel.Controls.Add((New-StatusCard -X 20 -Y 540 -W 215 -Title "Quarantaene" -Value $(if ($qcEnabled) { "AKTIV" } else { "AUS" }) -Status $(if ($qcEnabled) { "safe" } else { "warn" })))
        $dashboardPanel.Controls.Add((New-StatusCard -X 245 -Y 540 -W 215 -Title "Eigen-Sicherheit" -Value $(if ($shEnabled) { "GESICHERT" } else { "OFFEN" }) -Status $(if ($shEnabled) { "safe" } else { "warn" })))

        $actionsTitle = New-SectionLabel -X 20 -Y 660 -W 400 -Text "Schnellaktionen"
        $dashboardPanel.Controls.Add($actionsTitle)

        $dashboardPanel.Controls.Add((New-ActionButton -X 20 -Y 695 -W 150 -H 32 -Text "Vollscan" -Color "#0EA5E9" -ClickAction {
            Invoke-FullScan -Config $script:guiConfig -ShowProgress $true
            Update-Dashboard
        }))
        $dashboardPanel.Controls.Add((New-ActionButton -X 180 -Y 695 -W 150 -H 32 -Text "Backup jetzt" -Color "#10B981" -ClickAction {
            Invoke-BackupSystem -Config $script:guiConfig
            [System.Windows.Forms.MessageBox]::Show("Backup abgeschlossen!", "JDS Secure", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        }))
        $dashboardPanel.Controls.Add((New-ActionButton -X 340 -Y 695 -W 150 -H 32 -Text "Firewall haerten" -Color "#F59E0B" -ClickAction {
            Invoke-FirewallHardening -Config $script:guiConfig
            Update-Dashboard
        }))
        $dashboardPanel.Controls.Add((New-ActionButton -X 20 -Y 735 -W 150 -H 32 -Text "Ransomware-Check" -Color "#EF4444" -ClickAction {
            Invoke-RansomwareScan -Config $script:guiConfig -ShowProgress $true
            Update-Dashboard
        }))
        $dashboardPanel.Controls.Add((New-ActionButton -X 180 -Y 735 -W 150 -H 32 -Text "Vulnerability-Scan" -Color "#8B5CF6" -ClickAction {
            Invoke-VulnerabilityScan -Config $script:guiConfig -ShowProgress $true
            Update-Dashboard
        }))
        $dashboardPanel.Controls.Add((New-ActionButton -X 340 -Y 735 -W 150 -H 32 -Text "Prozess-Audit" -Color "#EC4899" -ClickAction {
            Invoke-ProcessAudit -Config $script:guiConfig -ShowProgress $true
            Update-Dashboard
        }))
        $dashboardPanel.Controls.Add((New-ActionButton -X 20 -Y 775 -W 150 -H 32 -Text "Integritaet" -Color "#6366F1" -ClickAction {
            Invoke-IntegrityCheck -Config $script:guiConfig -ShowProgress $true
            Update-Dashboard
        }))
        $dashboardPanel.Controls.Add((New-ActionButton -X 180 -Y 775 -W 150 -H 32 -Text "Netzwerk-Scan" -Color "#14B8A6" -ClickAction {
            Invoke-NetworkSecurityScan -Config $script:guiConfig -ShowProgress $true
            Update-Dashboard
        }))
        $dashboardPanel.Controls.Add((New-ActionButton -X 340 -Y 775 -W 150 -H 32 -Text "Selbstschutz" -Color "#475569" -ClickAction {
            Invoke-SelfDefenseCheck -Config $script:guiConfig -ShowProgress $true
            Update-Dashboard
        }))
        $dashboardPanel.Controls.Add((New-ActionButton -X 20 -Y 815 -W 150 -H 32 -Text "Virenscan" -Color "#DC2626" -ClickAction {
            Invoke-VirusScan -Config $script:guiConfig -ShowProgress $true -ScanType "quick"
            Update-Dashboard
        }))
        $dashboardPanel.Controls.Add((New-ActionButton -X 180 -Y 815 -W 150 -H 32 -Text "Quarantaene" -Color "#D97706" -ClickAction {
            $tabControl.SelectedTab = $tabEvents
        }))
        $dashboardPanel.Controls.Add((New-ActionButton -X 340 -Y 815 -W 150 -H 32 -Text "DSGVO-Doku" -Color "#059669" -ClickAction {
            Export-GDPRDocumentation -Config $script:guiConfig -Type "overview"
            [System.Windows.Forms.MessageBox]::Show("DSGVO-Dokumentation exportiert", "JDS Secure", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        }))
        $dashboardPanel.Controls.Add((New-ActionButton -X 20 -Y 855 -W 150 -H 32 -Text "Incident-Test" -Color "#475569" -ClickAction {
            Test-IncidentResponse -Config $script:guiConfig
            [System.Windows.Forms.MessageBox]::Show("Incident-Response Test abgeschlossen", "JDS Secure", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        }))
        $dashboardPanel.Controls.Add((New-ActionButton -X 180 -Y 855 -W 150 -H 32 -Text "Service-Modus" -Color "#6366F1" -ClickAction {
            Start-Job -Name "JDS-GUI-Service" -ScriptBlock {
                param($c)
                . "$using:script:ScriptPath\modules\audit.ps1"
                . "$using:script:ScriptPath\modules\ids.ps1"
                . "$using:script:ScriptPath\modules\backup.ps1"
                . "$using:script:ScriptPath\modules\honeypot.ps1"
                . "$using:script:ScriptPath\modules\ransomware.ps1"
                . "$using:script:ScriptPath\modules\file-integrity.ps1"
                . "$using:script:ScriptPath\modules\process-security.ps1"
                . "$using:script:ScriptPath\modules\network-security.ps1"
                . "$using:script:ScriptPath\modules\vulnerability-scan.ps1"
                . "$using:script:ScriptPath\modules\self-defense.ps1"
                . "$using:script:ScriptPath\modules\virus-scan.ps1"
                . "$using:script:ScriptPath\modules\quarantine.ps1"
                . "$using:script:ScriptPath\modules\gdpr.ps1"
                while ($true) {
                    Invoke-IDSMonitor -Config $c | Out-Null
                    Invoke-JDSAuditScan -Config $c | Out-Null
                    Invoke-RansomwareScan -Config $c | Out-Null
                    Invoke-ProcessAudit -Config $c | Out-Null
                    Invoke-VirusScan -Config $c -ScanType "quick" | Out-Null
                    Start-Sleep -Seconds 120
                }
            } -ArgumentList $script:guiConfig | Out-Null
            [System.Windows.Forms.MessageBox]::Show("Service-Modus gestartet (Hintergrund)", "JDS Secure", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        }))
        $dashboardPanel.Controls.Add((New-ActionButton -X 340 -Y 855 -W 150 -H 32 -Text "Bericht" -Color "#F97316" -ClickAction {
            Export-SecurityReport -Config $script:guiConfig
        }))

        $infoTitle = New-SectionLabel -X 20 -Y 910 -W 400 -Text "Letzte Ereignisse"
        $dashboardPanel.Controls.Add($infoTitle)

        try {
            $events = Get-WinEvent -LogName Security -MaxEvents 12 -ErrorAction SilentlyContinue | Where-Object { $_.TimeCreated -gt (Get-Date).AddHours(-24) }
            $y = 940
            foreach ($evt in $events) {
                $evtLabel = New-Object System.Windows.Forms.Label
                $evtLabel.Text = "$($evt.TimeCreated.ToString('HH:mm')) [$($evt.Id)] $($evt.LevelDisplayName)"
                $evtLabel.Location = New-Object System.Drawing.Point(25, $y)
                $evtLabel.Size = New-Object System.Drawing.Size(660, 20)
                $evtLabel.Font = New-Object System.Drawing.Font("Segoe UI", 8.5)
                $c = if ($evt.LevelDisplayName -eq "Error") { [System.Drawing.Color]::FromArgb(255, 100, 100) } elseif ($evt.LevelDisplayName -eq "Warning") { [System.Drawing.Color]::FromArgb(255, 200, 100) } else { [System.Drawing.Color]::FromArgb(148, 163, 184) }
                $evtLabel.ForeColor = $c
                $dashboardPanel.Controls.Add($evtLabel)
                $y += 20
                if ($y -gt 760) { break }
            }
        } catch {}
    }

    function Build-BackupTab {
        $backupPanel.Controls.Clear()

        $title = New-SectionLabel -X 20 -Y 15 -W 400 -Text "Backup-Einstellungen"
        $backupPanel.Controls.Add($title)

        $destLabel = New-Object System.Windows.Forms.Label
        $destLabel.Text = "Backup-Ziel waehlen:"
        $destLabel.Location = New-Object System.Drawing.Point(20, 55)
        $destLabel.Size = New-Object System.Drawing.Size(200, 22)
        $destLabel.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
        $backupPanel.Controls.Add($destLabel)

        $destCombo = New-Object System.Windows.Forms.ComboBox
        $destCombo.Location = New-Object System.Drawing.Point(20, 80)
        $destCombo.Size = New-Object System.Drawing.Size(350, 25)
        $destCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
        $destCombo.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59)
        $destCombo.ForeColor = [System.Drawing.Color]::White
        $destCombo.Items.AddRange(@("Externe Festplatte (D:)", "USB-Stick (E:)", "Netzwerkfreigabe", "Zweite interne Festplatte", "Benutzerdefiniert"))
        $destCombo.SelectedIndex = 0
        $backupPanel.Controls.Add($destCombo)

        $pathLabel = New-Object System.Windows.Forms.Label
        $pathLabel.Text = "Ziel-Pfad:"
        $pathLabel.Location = New-Object System.Drawing.Point(20, 115)
        $pathLabel.Size = New-Object System.Drawing.Size(200, 22)
        $pathLabel.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
        $backupPanel.Controls.Add($pathLabel)

        $pathBox = New-Object System.Windows.Forms.TextBox
        $pathBox.Location = New-Object System.Drawing.Point(20, 140)
        $pathBox.Size = New-Object System.Drawing.Size(350, 25)
        $pathBox.Text = $script:guiConfig.backup.destination
        $pathBox.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59)
        $pathBox.ForeColor = [System.Drawing.Color]::White
        $pathBox.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
        $backupPanel.Controls.Add($pathBox)

        $destCombo.Add_SelectedIndexChanged({
            switch ($destCombo.SelectedIndex) {
                0 { $pathBox.Text = "D:\JDS-Backup" }
                1 { $pathBox.Text = "E:\JDS-Backup" }
                2 { $pathBox.Text = "\\SERVER\Backup\JDS" }
                3 { $pathBox.Text = "F:\JDS-Backup" }
                4 { $pathBox.Text = $script:guiConfig.backup.destination }
            }
        })

        $quellenTitle = New-SectionLabel -X 20 -Y 180 -W 400 -Text "Zu sichernde Daten"
        $backupPanel.Controls.Add($quellenTitle)

        $checkItems = @(
            @{Name="CustomerData"; Path="C:\CustomerData"; Default=$true},
            @{Name="ClientData"; Path="C:\ClientData"; Default=$true},
            @{Name="BusinessData"; Path="C:\BusinessData"; Default=$true},
            @{Name="Benutzerprofile"; Path="C:\Users"; Default=$false}
        )

        $checkboxes = @{}
        $yPos = 210
        foreach ($item in $checkItems) {
            $cb = New-Object System.Windows.Forms.CheckBox
            $cb.Text = "$($item.Name) ($($item.Path))"
            $cb.Location = New-Object System.Drawing.Point(25, $yPos)
            $cb.Size = New-Object System.Drawing.Size(350, 22)
            $cb.Checked = $item.Default -or ($script:guiConfig.backup.source_paths -contains $item.Path)
            $cb.ForeColor = [System.Drawing.Color]::FromArgb(203, 213, 225)
            $cb.BackColor = [System.Drawing.Color]::Transparent
            $cb.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
            $backupPanel.Controls.Add($cb)
            $checkboxes[$item.Path] = $cb
            $yPos += 27
        }

        $encCB = New-Object System.Windows.Forms.CheckBox
        $encCB.Text = "Backup verschluesseln"
        $encCB.Location = New-Object System.Drawing.Point(25, 340)
        $encCB.Size = New-Object System.Drawing.Size(200, 22)
        $encCB.Checked = $script:guiConfig.backup.encrypted
        $encCB.ForeColor = [System.Drawing.Color]::FromArgb(203, 213, 225)
        $backupPanel.Controls.Add($encCB)

        $compCB = New-Object System.Windows.Forms.CheckBox
        $compCB.Text = "Komprimieren (ZIP)"
        $compCB.Location = New-Object System.Drawing.Point(25, 365)
        $compCB.Size = New-Object System.Drawing.Size(200, 22)
        $compCB.Checked = $script:guiConfig.backup.compression
        $compCB.ForeColor = [System.Drawing.Color]::FromArgb(203, 213, 225)
        $backupPanel.Controls.Add($compCB)

        $buttonY = 410
        $backupPanel.Controls.Add((New-ActionButton -X 20 -Y $buttonY -W 180 -H 45 -Text "Backup jetzt starten" -Color "#10B981" -ClickAction {
            $sources = @()
            foreach ($kv in $checkboxes.GetEnumerator()) {
                if ($kv.Value.Checked) { $sources += $kv.Key }
            }
            if ($sources.Count -eq 0) {
                [System.Windows.Forms.MessageBox]::Show("Bitte mindestens eine Datenquelle waehlen.", "Hinweis", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
                return
            }
            $script:guiConfig.backup.source_paths = $sources
            $script:guiConfig.backup.destination = $pathBox.Text
            $script:guiConfig.backup.encrypted = $encCB.Checked
            $script:guiConfig.backup.compression = $compCB.Checked
            Invoke-BackupSystem -Config $script:guiConfig
            [System.Windows.Forms.MessageBox]::Show("Backup abgeschlossen nach:`n$($pathBox.Text)", "JDS Secure - Backup", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        }))

        $backupPanel.Controls.Add((New-ActionButton -X 215 -Y $buttonY -W 180 -H 45 -Text "Einstellungen speichern" -Color "#6366F1" -ClickAction {
            $script:guiConfig.backup.destination = $pathBox.Text
            $script:guiConfig.backup.encrypted = $encCB.Checked
            $script:guiConfig.backup.compression = $compCB.Checked
            $sources = @()
            foreach ($kv in $checkboxes.GetEnumerator()) {
                if ($kv.Value.Checked) { $sources += $kv.Key }
            }
            $script:guiConfig.backup.source_paths = $sources
            Save-JDSConfig -Config $script:guiConfig
            [System.Windows.Forms.MessageBox]::Show("Einstellungen gespeichert!", "JDS Secure", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        }))

        $infoPanel = New-RoundedPanel -X 420 -Y 55 -W 470 -H 350 -Color "#0F1729"
        $infoTitle2 = New-Object System.Windows.Forms.Label
        $infoTitle2.Text = "Backup-Uebersicht"
        $infoTitle2.Location = New-Object System.Drawing.Point(15, 12)
        $infoTitle2.Size = New-Object System.Drawing.Size(440, 25)
        $infoTitle2.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
        $infoTitle2.ForeColor = [System.Drawing.Color]::FromArgb(0, 212, 255)
        $infoPanel.Controls.Add($infoTitle2)

        $bkpDir = $script:guiConfig.backup.destination
        $lastBackups = if (Test-Path $bkpDir) { Get-ChildItem $bkpDir -Directory | Sort-Object CreationTime -Descending | Select-Object -First 5 } else { @() }

        $infoLines = @(
            "Letzte Backups:"
        )
        if ($lastBackups.Count -gt 0) {
            foreach ($b in $lastBackups) {
                $infoLines += "  - $($b.Name) ($($b.CreationTime.ToString('dd.MM.yyyy HH:mm')))"
            }
        } else {
            $infoLines += "  - Keine Backups gefunden"
        }

        $infoLines += ""
        $infoLines += "Empfohlenes Ziel: Externe Festplatte (D:)"
        $infoLines += "Fassungsvermoegen: ausreichend fuer KMU"
        $infoLines += "Verschluesselung: AES-256 / BitLocker"

        $infoText = New-Object System.Windows.Forms.Label
        $infoText.Text = $infoLines -join "`n"
        $infoText.Location = New-Object System.Drawing.Point(20, 45)
        $infoText.Size = New-Object System.Drawing.Size(430, 290)
        $infoText.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
        $infoText.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
        $infoPanel.Controls.Add($infoText)

        $backupPanel.Controls.Add($infoPanel)
    }

    function Build-SettingsTab {
        $settingsPanel.Controls.Clear()

        $title = New-SectionLabel -X 20 -Y 15 -W 400 -Text "Einstellungen"
        $settingsPanel.Controls.Add($title)

        $items = @(
            @{Label="Firewall aktiv"; Key="firewall.enabled"; Type="switch"},
            @{Label="IDS aktiv"; Key="ids.enabled"; Type="switch"},
            @{Label="Verschluesselung aktiv"; Key="encryption.enabled"; Type="switch"},
            @{Label="Backup aktiv"; Key="backup.enabled"; Type="switch"},
            @{Label="Honeypot aktiv"; Key="honeypot.enabled"; Type="switch"},
            @{Label="Audit-Logging aktiv"; Key="audit.enabled"; Type="switch"},
            @{Label="USB-Sicherheit aktiv"; Key="usb_security.enabled"; Type="switch"}
        )

        $toggles = @{}
        $yPos = 55
        foreach ($item in $items) {
            $lbl = New-Object System.Windows.Forms.Label
            $lbl.Text = $item.Label
            $lbl.Location = New-Object System.Drawing.Point(25, $yPos)
            $lbl.Size = New-Object System.Drawing.Size(250, 25)
            $lbl.ForeColor = [System.Drawing.Color]::FromArgb(203, 213, 225)
            $lbl.Font = New-Object System.Drawing.Font("Segoe UI", 10)
            $settingsPanel.Controls.Add($lbl)

            $keys = $item.Key -split '\.'
            $currentVal = $script:guiConfig
            foreach ($k in $keys) { $currentVal = $currentVal[$k] }

            $toggle = New-Object System.Windows.Forms.CheckBox
            $toggle.Location = New-Object System.Drawing.Point(290, $yPos + 2)
            $toggle.Size = New-Object System.Drawing.Size(50, 20)
            $toggle.Checked = $currentVal
            $toggle.ForeColor = [System.Drawing.Color]::White
            $settingsPanel.Controls.Add($toggle)
            $toggles[$item.Key] = $toggle

            $yPos += 32
        }

        $saveBtn = New-ActionButton -X 20 -Y ($yPos + 15) -W 220 -H 45 -Text "Einstellungen speichern" -Color "#10B981" -ClickAction {
            foreach ($kv in $toggles.GetEnumerator()) {
                $keys = $kv.Key -split '\.'
                $current = $script:guiConfig
                for ($i = 0; $i -lt $keys.Count - 1; $i++) { $current = $current[$keys[$i]] }
                $current[$keys[-1]] = $kv.Value.Checked
            }
            Save-JDSConfig -Config $script:guiConfig
            [System.Windows.Forms.MessageBox]::Show("Einstellungen gespeichert!", "JDS Secure", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
            Update-Dashboard
        }
        $settingsPanel.Controls.Add($saveBtn)

        $aboutBox = New-RoundedPanel -X 420 -Y 55 -W 470 -H 350 -Color "#0F1729"
        $aboutTitle = New-Object System.Windows.Forms.Label
        $aboutTitle.Text = "Ueber JDS Secure"
        $aboutTitle.Location = New-Object System.Drawing.Point(15, 12)
        $aboutTitle.Size = New-Object System.Drawing.Size(440, 25)
        $aboutTitle.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
        $aboutTitle.ForeColor = [System.Drawing.Color]::FromArgb(0, 212, 255)
        $aboutBox.Controls.Add($aboutTitle)

        $aboutText = New-Object System.Windows.Forms.Label
        $aboutText.Text = @"
JDS Secure - Enterprise Security Suite v$script:JDSVersion

Umfassendes Sicherheitssystem fuer KMU.
Lauffaehig direkt vom USB-Stick.

Module:
- Firewall-Haertung & Netzwerkschutz
- Intrusion Detection System (IDS)
- Datenverschluesselung (AES-256)
- Automatisierte Backups
- Honeypot-System
- Audit & Monitoring
- USB-Sicherheit

Entwickelt von Joel Digitals
"@
        $aboutText.Location = New-Object System.Drawing.Point(20, 45)
        $aboutText.Size = New-Object System.Drawing.Size(430, 290)
        $aboutText.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
        $aboutText.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
        $aboutBox.Controls.Add($aboutText)

        $settingsPanel.Controls.Add($aboutBox)
    }

    function Build-EventsTab {
        $eventsPanel.Controls.Clear()

        $title = New-SectionLabel -X 20 -Y 15 -W 400 -Text "Quarantaene"
        $eventsPanel.Controls.Add($title)

        $qSummary = Get-QuarantineSummary -Config $script:guiConfig
        $summaryLbl = New-Object System.Windows.Forms.Label
        $summaryLbl.Text = "$($qSummary.active) aktiv - $($qSummary.restored) wiederhergestellt - $($qSummary.total_size_mb) MB belegt"
        $summaryLbl.Location = New-Object System.Drawing.Point(20, 45)
        $summaryLbl.Size = New-Object System.Drawing.Size(600, 22)
        $summaryLbl.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
        $summaryLbl.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
        $eventsPanel.Controls.Add($summaryLbl)

        $grid = New-Object System.Windows.Forms.DataGridView
        $grid.Location = New-Object System.Drawing.Point(20, 75)
        $grid.Size = New-Object System.Drawing.Size(1050, 260)
        $grid.BackgroundColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
        $grid.BorderStyle = [System.Windows.Forms.BorderStyle]::None
        $grid.ReadOnly = $true
        $grid.AllowUserToAddRows = $false
        $grid.AllowUserToDeleteRows = $false
        $grid.AllowUserToResizeRows = $false
        $grid.RowHeadersVisible = $false
        $grid.SelectionMode = [System.Windows.Forms.DataGridViewSelectionMode]::FullRowSelect
        $grid.MultiSelect = $false
        $grid.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnsMode]::Fill
        $grid.ColumnHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(30, 41, 59)
        $grid.ColumnHeadersDefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(0, 212, 255)
        $grid.ColumnHeadersHeight = 30
        $grid.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
        $grid.DefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(203, 213, 225)
        $grid.DefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(51, 65, 85)
        $grid.DefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::White
        $grid.EnableHeadersVisualStyles = $false
        $grid.BackgroundColor = [System.Drawing.Color]::FromArgb(15, 23, 42)

        $grid.Columns.Add("id", "ID") | Out-Null
        $grid.Columns.Add("file_name", "Datei") | Out-Null
        $grid.Columns.Add("reason", "Grund") | Out-Null
        $grid.Columns.Add("quarantine_date", "Datum") | Out-Null
        $grid.Columns.Add("status", "Status") | Out-Null
        $grid.Columns["id"].Visible = $false

        $items = Get-QuarantineList -Config $script:guiConfig
        foreach ($item in $items) {
            $status = if ($item.restored) { "Wiederhergestellt" } else { "Aktiv" }
            $grid.Rows.Add($item.id, $item.file_name, $item.reason, $item.quarantine_date, $status) | Out-Null
        }
        $eventsPanel.Controls.Add($grid)

        $restoreBtn = New-ActionButton -X 20 -Y 345 -W 230 -H 34 -Text "Ausgewaehltes wiederherstellen" -Color "#10B981" -ClickAction {
            if ($grid.SelectedRows.Count -eq 0) {
                [System.Windows.Forms.MessageBox]::Show("Bitte zuerst einen Eintrag in der Liste auswaehlen.", "Hinweis", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
                return
            }
            $qid = $grid.SelectedRows[0].Cells["id"].Value
            $result = Restore-QuarantineItem -Config $script:guiConfig -QuarantineId $qid
            if ($result.success) {
                [System.Windows.Forms.MessageBox]::Show("Datei wiederhergestellt.", "JDS Secure", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
            } else {
                [System.Windows.Forms.MessageBox]::Show("Fehler: $($result.reason)", "JDS Secure", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
            }
            Build-EventsTab
        }
        $eventsPanel.Controls.Add($restoreBtn)

        $refreshBtn = New-ActionButton -X 260 -Y 345 -W 130 -H 34 -Text "Aktualisieren" -Color "#334155" -ClickAction {
            Build-EventsTab
        }
        $eventsPanel.Controls.Add($refreshBtn)

        $eventsTitle = New-SectionLabel -X 20 -Y 400 -W 500 -Text "Letzte Ereignisse (Warnungen & Fehler)"
        $eventsPanel.Controls.Add($eventsTitle)

        $logBox = New-Object System.Windows.Forms.RichTextBox
        $logBox.Location = New-Object System.Drawing.Point(20, 430)
        $logBox.Size = New-Object System.Drawing.Size(1050, 190)
        $logBox.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
        $logBox.ForeColor = [System.Drawing.Color]::FromArgb(203, 213, 225)
        $logBox.Font = New-Object System.Drawing.Font("Segoe UI", 9)
        $logBox.ReadOnly = $true
        $logBox.BorderStyle = [System.Windows.Forms.BorderStyle]::None

        $logPath = if ($script:guiConfig.audit.log_file) {
            if ([System.IO.Path]::IsPathRooted($script:guiConfig.audit.log_file)) { $script:guiConfig.audit.log_file } else { Join-Path $script:ScriptPath $script:guiConfig.audit.log_file }
        } else {
            Join-Path $script:ScriptPath "logs\jds-audit.log"
        }

        if (Test-Path $logPath) {
            try {
                $lines = Get-Content $logPath -Tail 500 -ErrorAction SilentlyContinue | Where-Object { $_ -match '\[(WARN|ERROR|CRITICAL)\]' } | Select-Object -Last 40
                if ($lines.Count -eq 0) {
                    $logBox.SelectionColor = [System.Drawing.Color]::FromArgb(0, 230, 118)
                    $logBox.AppendText("Keine aktuellen Warnungen oder Fehler.`n")
                } else {
                    foreach ($line in $lines) {
                        $color = if ($line -match '\[(CRITICAL|ERROR)\]') { [System.Drawing.Color]::FromArgb(255, 23, 68) } else { [System.Drawing.Color]::FromArgb(255, 171, 0) }
                        $logBox.SelectionStart = $logBox.TextLength
                        $logBox.SelectionColor = $color
                        $logBox.AppendText("$line`n")
                    }
                }
            } catch { }
        } else {
            $logBox.SelectionColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
            $logBox.AppendText("Noch keine Log-Datei vorhanden.`n")
        }
        $eventsPanel.Controls.Add($logBox)
    }

    # Header / Branding-Leiste
    $headerPanel = New-Object System.Windows.Forms.Panel
    $headerPanel.Dock = [System.Windows.Forms.DockStyle]::Top
    $headerPanel.Height = 64
    $headerPanel.BackColor = [System.Drawing.Color]::FromArgb(11, 17, 32)

    $logoLabel = New-Object System.Windows.Forms.Label
    $logoLabel.Text = "JDS SECURE"
    $logoLabel.Font = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)
    $logoLabel.ForeColor = [System.Drawing.Color]::FromArgb(0, 212, 255)
    $logoLabel.Location = New-Object System.Drawing.Point(20, 7)
    $logoLabel.Size = New-Object System.Drawing.Size(240, 28)
    $headerPanel.Controls.Add($logoLabel)

    $subLabel = New-Object System.Windows.Forms.Label
    $subLabel.Text = "by Joel Digitals - Enterprise Security Suite"
    $subLabel.Font = New-Object System.Drawing.Font("Segoe UI", 8.5)
    $subLabel.ForeColor = [System.Drawing.Color]::FromArgb(100, 116, 139)
    $subLabel.Location = New-Object System.Drawing.Point(22, 36)
    $subLabel.Size = New-Object System.Drawing.Size(320, 18)
    $headerPanel.Controls.Add($subLabel)

    $updateStatusLabel = New-Object System.Windows.Forms.Label
    $updateStatusLabel.Text = "Update-Status wird geprueft..."
    $updateStatusLabel.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $updateStatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
    $updateStatusLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $updateStatusLabel.Location = New-Object System.Drawing.Point(600, 22)
    $updateStatusLabel.Size = New-Object System.Drawing.Size(280, 20)
    $updateStatusLabel.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
    $headerPanel.Controls.Add($updateStatusLabel)

    $updateBtn = New-ActionButton -X 890 -Y 16 -W 190 -H 32 -Text "Nach Updates suchen" -Color "#334155" -ClickAction {
        Invoke-JDSUpdateCheck
    }
    $updateBtn.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
    $headerPanel.Controls.Add($updateBtn)

    # Main Tab Control
    $tabControl = New-Object System.Windows.Forms.TabControl
    $tabControl.Dock = [System.Windows.Forms.DockStyle]::Fill
    $tabControl.Font = New-Object System.Drawing.Font("Segoe UI", 11)
    $tabControl.Appearance = [System.Windows.Forms.TabAppearance]::FlatButtons
    $tabControl.ItemSize = New-Object System.Drawing.Size(180, 40)
    $tabControl.Padding = New-Object System.Drawing.Point(10, 0)
    $tabControl.DrawMode = [System.Windows.Forms.TabDrawMode]::OwnerDrawFixed

    $tabControl.Add_DrawItem({
        param($sender, $e)
        $g = $e.Graphics
        $tabPage = $sender.TabPages[$e.Index]
        $bounds = $e.Bounds
        $brush = if ($e.State -eq [System.Windows.Forms.DrawItemState]::Selected) {
            New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(30, 41, 59))
        } else {
            New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(15, 23, 42))
        }
        $g.FillRectangle($brush, $bounds)
        $textBrush = if ($e.State -eq [System.Windows.Forms.DrawItemState]::Selected) {
            New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(0, 212, 255))
        } else {
            New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(148, 163, 184))
        }
        $g.DrawString($tabPage.Text, $sender.Font, $textBrush, ($bounds.X + 10), ($bounds.Y + 8))
        if ($e.State -eq [System.Windows.Forms.DrawItemState]::Selected) {
            $g.DrawLine((New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(0, 212, 255))), $bounds.X + 5, $bounds.Bottom - 2, $bounds.Right - 5, $bounds.Bottom - 2)
        }
    })

    # Tab 1: Dashboard
    $tabDashboard = New-Object System.Windows.Forms.TabPage
    $tabDashboard.Text = "  Dashboard  "
    $tabDashboard.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
    $dashboardPanel = New-Object System.Windows.Forms.Panel
    $dashboardPanel.Location = New-Object System.Drawing.Point(0, 0)
    $dashboardPanel.Size = New-Object System.Drawing.Size(1090, 600)
    $dashboardPanel.AutoScroll = $true
    $dashboardPanel.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
    $tabDashboard.Controls.Add($dashboardPanel)
    $tabControl.TabPages.Add($tabDashboard)

    # Tab 2: Backup
    $tabBackup = New-Object System.Windows.Forms.TabPage
    $tabBackup.Text = "  Backup  "
    $tabBackup.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
    $backupPanel = New-Object System.Windows.Forms.Panel
    $backupPanel.Location = New-Object System.Drawing.Point(0, 0)
    $backupPanel.Size = New-Object System.Drawing.Size(1090, 600)
    $backupPanel.AutoScroll = $true
    $backupPanel.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
    $tabBackup.Controls.Add($backupPanel)
    $tabControl.TabPages.Add($tabBackup)

    # Tab 3: Settings
    $tabSettings = New-Object System.Windows.Forms.TabPage
    $tabSettings.Text = "  Einstellungen  "
    $tabSettings.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
    $settingsPanel = New-Object System.Windows.Forms.Panel
    $settingsPanel.Location = New-Object System.Drawing.Point(0, 0)
    $settingsPanel.Size = New-Object System.Drawing.Size(1090, 600)
    $settingsPanel.AutoScroll = $true
    $settingsPanel.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
    $tabSettings.Controls.Add($settingsPanel)
    $tabControl.TabPages.Add($tabSettings)

    # Tab 4: Ereignisse & Quarantaene
    $tabEvents = New-Object System.Windows.Forms.TabPage
    $tabEvents.Text = "  Ereignisse & Quarantaene  "
    $tabEvents.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
    $eventsPanel = New-Object System.Windows.Forms.Panel
    $eventsPanel.Location = New-Object System.Drawing.Point(0, 0)
    $eventsPanel.Size = New-Object System.Drawing.Size(1090, 600)
    $eventsPanel.AutoScroll = $true
    $eventsPanel.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
    $tabEvents.Controls.Add($eventsPanel)
    $tabControl.TabPages.Add($tabEvents)

    $form.Controls.Add($tabControl)
    $form.Controls.Add($headerPanel)

    # Status Bar
    $statusBar = New-Object System.Windows.Forms.StatusStrip
    $statusBar.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
    $statusBar.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
    $statusBar.Font = New-Object System.Drawing.Font("Segoe UI", 9)

    $statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
    $statusLabel.Text = "JDS Secure v$script:JDSVersion - Bereit"
    $statusLabel.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
    $statusBar.Items.Add($statusLabel)

    $statusServer = New-Object System.Windows.Forms.ToolStripStatusLabel
    $statusServer.Text = "Server: $env:COMPUTERNAME"
    $statusServer.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
    $statusBar.Items.Add($statusServer)

    $statusTime = New-Object System.Windows.Forms.ToolStripStatusLabel
    $statusTime.Text = (Get-Date -Format "dd.MM.yyyy HH:mm")
    $statusTime.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
    $statusBar.Items.Add($statusTime)

    $form.Controls.Add($statusBar)

    # Initialize tabs
    Update-Dashboard
    Build-BackupTab
    Build-SettingsTab
    Build-EventsTab

    # Timer for periodic updates
    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 30000
    $timer.Add_Tick({
        if ($tabControl.SelectedTab -eq $tabDashboard) {
            Update-Dashboard
        }
        $statusTime.Text = (Get-Date -Format "dd.MM.yyyy HH:mm")
    })
    $timer.Start()

    # Handle tab switching
    $tabControl.Add_SelectedIndexChanged({
        switch ($tabControl.SelectedIndex) {
            0 { Update-Dashboard }
            1 { Build-BackupTab }
            2 { Build-SettingsTab }
            3 { Build-EventsTab }
        }
    })

    $form.Add_Shown({
        $form.Activate()
        Invoke-JDSUpdateCheck -Silent
    })
    $form.Add_Closing({
        $timer.Stop()
        $script:guiRunning = $false
    })

    [void]$form.ShowDialog()
}

function Save-JDSConfig {
    param([hashtable]$Config)

    $configPath = "$PSScriptRoot\..\config\security-config.json"
    try {
        $json = $Config | ConvertTo-Json -Depth 10
        Set-Content -Path $configPath -Value $json -Encoding UTF8 -Force
        Write-JDSLog "INFO" "Configuration saved"
    } catch {
        Write-JDSLog "ERROR" "Failed to save configuration: $_"
    }
}

function Invoke-FullScan {
    param([hashtable]$Config, [bool]$ShowProgress = $false)

    if ($ShowProgress) {
        $progressForm = New-Object System.Windows.Forms.Form
        $progressForm.Text = "JDS Secure - System-Scan"
        $progressForm.Size = New-Object System.Drawing.Size(450, 200)
        $progressForm.StartPosition = "CenterScreen"
        $progressForm.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
        $progressForm.ControlBox = $false
        $progressForm.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
        $progressForm.TopMost = $true

        $label = New-Object System.Windows.Forms.Label
        $label.Text = "Scanne System..."
        $label.Location = New-Object System.Drawing.Point(20, 20)
        $label.Size = New-Object System.Drawing.Size(410, 25)
        $label.ForeColor = [System.Drawing.Color]::FromArgb(0, 212, 255)
        $label.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
        $progressForm.Controls.Add($label)

        $bar = New-Object System.Windows.Forms.ProgressBar
        $bar.Location = New-Object System.Drawing.Point(20, 60)
        $bar.Size = New-Object System.Drawing.Size(410, 30)
        $bar.Style = [System.Windows.Forms.ProgressBarStyle]::Marquee
        $bar.ForeColor = [System.Drawing.Color]::FromArgb(0, 212, 255)
        $progressForm.Controls.Add($bar)

        $status = New-Object System.Windows.Forms.Label
        $status.Text = "Initialisiere..."
        $status.Location = New-Object System.Drawing.Point(20, 100)
        $status.Size = New-Object System.Drawing.Size(410, 50)
        $status.ForeColor = [System.Drawing.Color]::FromArgb(148, 163, 184)
        $progressForm.Controls.Add($status)

        $progressForm.Show()

        $status.Text = "[1/6] Firewall-Scan..."
        [System.Windows.Forms.Application]::DoEvents()

        try { Invoke-FirewallScan -Config $Config } catch {}

        $status.Text = "[2/6] IDS-Scan..."
        [System.Windows.Forms.Application]::DoEvents()
        try { Invoke-IDSMonitor -Config $Config } catch {}

        $status.Text = "[3/6] Auditing..."
        [System.Windows.Forms.Application]::DoEvents()
        try { Initialize-JDSAudit -Config $Config; Invoke-JDSAuditScan -Config $Config } catch {}

        $status.Text = "[4/6] Datenverschluesselung..."
        [System.Windows.Forms.Application]::DoEvents()
        try { Invoke-DataEncryption -Config $Config } catch {}

        $status.Text = "[5/6] USB-Sicherheit..."
        [System.Windows.Forms.Application]::DoEvents()
        try { Invoke-USBProtection -Config $Config } catch {}

        $status.Text = "[6/6] Honeypot..."
        [System.Windows.Forms.Application]::DoEvents()
        try { Invoke-HoneypotSetup -Config $Config } catch {}

        $status.Text = "Scan abgeschlossen!"
        $bar.Style = [System.Windows.Forms.ProgressBarStyle]::Blocks
        $bar.Value = 100

        $closeBtn = New-ActionButton -X 140 -Y 130 -W 160 -H 35 -Text "Schliessen" -Color "#0EA5E9" -ClickAction { $progressForm.Close() }
        $progressForm.Controls.Add($closeBtn)

    } else {
        Write-JDSLog "INFO" "Starting full system scan..."
        try { Invoke-FirewallScan -Config $Config } catch {}
        try { Invoke-IDSMonitor -Config $Config } catch {}
        try { Initialize-JDSAudit -Config $Config; Invoke-JDSAuditScan -Config $Config } catch {}
        try { Invoke-DataEncryption -Config $Config } catch {}
        try { Invoke-USBProtection -Config $Config } catch {}
        try { Invoke-HoneypotSetup -Config $Config } catch {}
        Write-JDSLog "INFO" "Full scan completed"
    }
}
