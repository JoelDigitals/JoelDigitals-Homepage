﻿function Invoke-BackupSystem {
    param(
        [hashtable]$Config,
        [string]$TargetDestination = "",
        [switch]$Silent
    )

    $bkp = $Config.backup
    if (-not $bkp.enabled) { if (-not $Silent) { Write-JDSLog "WARN" "Backup is disabled" }; return }

    $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
    $allResults = @()

    $destinations = Get-BackupDestinations -Config $Config -Target $TargetDestination

    foreach ($dest in $destinations) {
        $backupRoot = $dest.path
        if (-not $backupRoot) { continue }

        $label = $dest.label

        if (-not (Test-Path $backupRoot)) {
            try {
                if ($dest.type -eq "network") {
                    $netPath = $backupRoot -replace '^\\\\', '\\'
                    if ($dest.username -and $dest.password) {
                        $netUseArgs = @("use", $netPath, $dest.password, "/user:$($dest.domain)\$($dest.username)")
                        & net.exe $netUseArgs 2>&1 | Out-Null
                    }
                }
                New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
            } catch {
                Write-JDSLog "WARN" "Cannot access backup destination $label ($backupRoot): $_"
                continue
            }
        }

        $freeSpace = (Get-PSDrive -Name ($backupRoot -replace ':', '') -ErrorAction SilentlyContinue).Free
        $minSpace = $bkp.monitoring.min_free_space_gb * 1GB
        if ($freeSpace -and $freeSpace -lt $minSpace) {
            Write-JDSLog "WARN" "Low disk space on ${label}: $([math]::Round($freeSpace/1GB, 1)) GB free (min: $($bkp.monitoring.min_free_space_gb) GB)"
            $alerts = @{ type = "Warning"; title = "Wenig Speicherplatz"; message = "Backup-Ziel $label hat nur $([math]::Round($freeSpace/1GB, 1)) GB frei" }
            Send-JDSAlert $Config $alerts
        }

        $backupDir = Join-Path $backupRoot "JDS-Backup_$timestamp"
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

        if (-not $Silent) { Write-JDSLog "INFO" "Backing up to: $label ($backupDir)" }

        $results = @()
        foreach ($source in $bkp.source_paths) {
            if (-not (Test-Path $source)) {
                Write-JDSLog "WARN" "Source not found: $source"
                continue
            }

            $sourceName = $source -replace '[\\:]', '_' -replace '^_+', ''
            $destPath = Join-Path $backupDir $sourceName

            try {
                $exclude = @('*.tmp', '*.log', 'pagefile.sys', 'hiberfil.sys', 'swapfile.sys',
                             'NTUSER.DAT', 'ntuser.dat*', '*.evtx', 'Thumbs.db')

                if ($bkp.compression) {
                    $tempPath = Join-Path $env:TEMP "jds_bkp_$([System.Guid]::NewGuid().ToString('N'))"
                    New-Item -ItemType Directory -Path $tempPath -Force | Out-Null
                    $tempDest = Join-Path $tempPath $sourceName

                    Copy-Item -Path $source -Destination $tempDest -Recurse -Force -Exclude $exclude -ErrorAction SilentlyContinue

                    $zipPath = "$destPath.zip"
                    Add-Type -AssemblyName System.IO.Compression.FileSystem
                    [System.IO.Compression.ZipFile]::CreateFromDirectory($tempDest, $zipPath, [System.IO.Compression.CompressionLevel]::Optimal, $false)

                    $finalPath = if ($dest.encrypted -or $bkp.encrypted) {
                        $encPath = "$zipPath.enc"
                        $contentBytes = [System.IO.File]::ReadAllBytes($zipPath)
                        $protected = [System.Security.Cryptography.ProtectedData]::Protect($contentBytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
                        [System.IO.File]::WriteAllBytes($encPath, $protected)
                        Remove-Item $zipPath -Force
                        $encPath
                    } else { $zipPath }

                    Remove-Item $tempPath -Recurse -Force -ErrorAction SilentlyContinue
                } else {
                    Copy-Item -Path $source -Destination $destPath -Recurse -Force -Exclude $exclude -ErrorAction SilentlyContinue
                    $finalPath = $destPath
                }

                $size = (Get-ChildItem -Path $finalPath -Recurse -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
                $sizeMB = [math]::Round(($size / 1MB), 2)

                $results += [PSCustomObject]@{
                    Source = $source
                    Destination = $finalPath
                    SizeMB = $sizeMB
                    Status = "Success"
                    Timestamp = Get-Date
                }
                if (-not $Silent) { Write-JDSLog "INFO" "  + $sourceName ($sizeMB MB)" }
            } catch {
                Write-JDSLog "ERROR" "Backup failed for $source`: $_"
                $results += [PSCustomObject]@{ Source = $source; Destination = $destPath; SizeMB = 0; Status = "Failed"; Timestamp = Get-Date; Error = "$_" }
            }
        }

        if ($bkp.enable_sql_backup -and $bkp.sql_server) {
            $sqlResults = Backup-SQLDatabases -Config $Config -BackupDir $backupDir
            $results += $sqlResults
        }

        $manifest = @{
            BackupID = [System.Guid]::NewGuid().ToString()
            Timestamp = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
            ServerName = $env:COMPUTERNAME
            JDSVersion = $Config.version
            DestinationLabel = $label
            DestinationPath = $backupRoot
            Results = $results
        }
        $manifest | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $backupDir "backup-manifest.json") -Force

        if ($bkp.verify_after_backup) {
            Test-BackupIntegrity -BackupDir $backupDir | Out-Null
        }

        $totalSize = ($results | Where-Object { $_.Status -eq "Success" } | Measure-Object -Property SizeMB -Sum).Sum
        $failed = ($results | Where-Object { $_.Status -eq "Failed" }).Count
        $success = ($results | Where-Object { $_.Status -eq "Success" }).Count

        if (-not $Silent) {
            Write-JDSLog "INFO" "Backup to ${label}: $success ok, $failed failed ($([math]::Round($totalSize, 2)) MB)"
        }

        $allResults += [PSCustomObject]@{
            Label = $label
            Path = $backupDir
            Results = $results
            TotalSizeMB = $totalSize
            SuccessCount = $success
            FailedCount = $failed
        }
    }

    Invoke-BackupRotation -Config $Config

    if ($allResults.Count -gt 0) {
        $totalSuccess = ($allResults | Measure-Object -Property SuccessCount -Sum).Sum
        $totalFailed = ($allResults | Measure-Object -Property FailedCount -Sum).Sum
        $totalSizeAll = ($allResults | Measure-Object -Property TotalSizeMB -Sum).Sum

        $alerts = @{
            type = if ($totalFailed -gt 0) { "Warning" } else { "Info" }
            title = "Backup abgeschlossen"
            message = "$totalSuccess erfolgreich, $totalFailed fehlgeschlagen - $([math]::Round($totalSizeAll, 2)) MB auf $($allResults.Count) Ziel(en)"
        }
        Send-JDSAlert $Config $alerts
    }

    Save-BackupHistory -Results $allResults -Config $Config

    return $allResults
}

function Get-BackupDestinations {
    param([hashtable]$Config, [string]$Target = "")

    $bkp = $Config.backup
    $allDests = @()

    if ($Target) {
        $allDests += @{ path = $Target; label = "Benutzerdefiniert"; type = "custom"; encrypted = $bkp.encrypted }
        return $allDests
    }

    $dests = $bkp.destinations
    if ($dests.primary.path) {
        $allDests += @{ path = $dests.primary.path; label = $dests.primary.label; type = $dests.primary.type; encrypted = $dests.primary.encrypted }
    }
    if ($dests.secondary.path) {
        $allDests += @{ path = $dests.secondary.path; label = $dests.secondary.label; type = $dests.secondary.type; encrypted = $dests.secondary.encrypted }
    }
    if ($dests.usb.path -and (Test-Path ($dests.usb.path -replace '\\[^\\]+$', ''))) {
        $allDests += @{ path = $dests.usb.path; label = $dests.usb.label; type = $dests.usb.type; encrypted = $dests.usb.encrypted }
    }
    if ($dests.custom.path) {
        $allDests += @{ path = $dests.custom.path; label = $dests.custom.label; type = $dests.custom.type; encrypted = $dests.custom.encrypted }
    }

    if ($allDests.Count -eq 0) {
        $allDests += @{ path = $bkp.destination; label = "Standard"; type = "custom"; encrypted = $bkp.encrypted }
    }

    return $allDests
}

function Invoke-BackupRotation {
    param([hashtable]$Config)

    $rot = $Config.backup.rotation
    if (-not $rot.enabled) { return }

    $destinations = Get-BackupDestinations -Config $Config
    $now = Get-Date

    foreach ($dest in $destinations) {
        $backupRoot = $dest.path
        if (-not (Test-Path $backupRoot)) { continue }

        $allBackups = Get-ChildItem -Path $backupRoot -Directory -Filter "JDS-Backup_*" | Sort-Object CreationTime -Descending

        $dailyKeep = $rot.daily_keep
        $weeklyKeep = $rot.weekly_keep
        $monthlyKeep = $rot.monthly_keep
        $yearlyKeep = $rot.yearly_keep

        $toKeep = @()
        $seenDays = @{}
        $seenWeeks = @{}
        $seenMonths = @{}
        $seenYears = @{}

        foreach ($b in $allBackups) {
            $dayKey = $b.CreationTime.ToString("yyyy-MM-dd")
            $weekKey = $b.CreationTime.ToString("yyyy-Www")
            $monthKey = $b.CreationTime.ToString("yyyy-MM")
            $yearKey = $b.CreationTime.ToString("yyyy")

            if ($seenYears.Count -lt $yearlyKeep -and -not $seenYears.ContainsKey($yearKey)) {
                $seenYears[$yearKey] = $true; $toKeep += $b; continue
            }
            if ($seenMonths.Count -lt $monthlyKeep -and -not $seenMonths.ContainsKey($monthKey)) {
                $seenMonths[$monthKey] = $true; $toKeep += $b; continue
            }
            if ($seenWeeks.Count -lt $weeklyKeep -and -not $seenWeeks.ContainsKey($weekKey)) {
                $seenWeeks[$weekKey] = $true; $toKeep += $b; continue
            }
            if ($seenDays.Count -lt $dailyKeep -and -not $seenDays.ContainsKey($dayKey)) {
                $seenDays[$dayKey] = $true; $toKeep += $b; continue
            }
        }

        $toDelete = $allBackups | Where-Object { $_.FullName -notin ($toKeep | ForEach-Object { $_.FullName }) }
        foreach ($b in $toDelete) {
            try {
                Remove-Item -Path $b.FullName -Recurse -Force -ErrorAction SilentlyContinue
                Write-JDSLog "INFO" "Rotation removed: $($b.Name)"
            } catch {}
        }

        $countTotal = $allBackups.Count
        $countRemoved = $toDelete.Count
        if ($countRemoved -gt 0) {
            Write-JDSLog "INFO" "Backup rotation on $($dest.label): $countRemoved removed, $($countTotal - $countRemoved) kept"
        }
    }
}

function Check-BackupHealth {
    param([hashtable]$Config)

    $bkp = $Config.backup
    $mon = $bkp.monitoring
    if (-not $mon.enabled) { return @{} }

    $issues = @()

    $destinations = Get-BackupDestinations -Config $Config
    foreach ($dest in $destinations) {
        $path = $dest.path
        if (-not (Test-Path $path)) {
            $issues += "Destination nicht erreichbar: $($dest.label) ($path)"
            if ($mon.alert_on_failure) {
                Send-JDSAlert $Config @{ type = "Warning"; title = "Backup-Ziel nicht erreichbar"; message = "$($dest.label): $path" }
            }
            continue
        }

        $freeSpace = (Get-PSDrive -Name ($path -replace ':', '') -ErrorAction SilentlyContinue).Free
        if ($freeSpace -and $freeSpace -lt ($mon.min_free_space_gb * 1GB)) {
            $freeGB = [math]::Round($freeSpace / 1GB, 1)
            $issues += "Wenig Speicherplatz auf $($dest.label): $freeGB GB frei"
            Send-JDSAlert $Config @{ type = "Warning"; title = "Backup-Speicherplatz niedrig"; message = "$($dest.label): $freeGB GB frei" }
        }

        $lastBackup = Get-ChildItem -Path $path -Directory -Filter "JDS-Backup_*" | Sort-Object CreationTime -Descending | Select-Object -First 1
        if (-not $lastBackup) {
            $issues += "Kein Backup auf $($dest.label) gefunden"
        } else {
            $hoursSince = ((Get-Date) - $lastBackup.CreationTime).TotalHours
            if ($hoursSince -gt 30) {
                $issues += "Letztes Backup auf $($dest.label) ist $([math]::Round($hoursSince))h her"
                if ($mon.alert_on_missed) {
                    Send-JDSAlert $Config @{ type = "Warning"; title = "Backup uberfallig"; message = "$($dest.label): $([math]::Round($hoursSince))h seit letztem Backup" }
                }
            }
        }
    }

    return @{ Issues = $issues; Healthy = ($issues.Count -eq 0) }
}

function Save-BackupHistory {
    param([array]$Results, [hashtable]$Config)

    $historyFile = "$PSScriptRoot\..\logs\backup-history.json"
    $entry = @{
        Timestamp = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        ServerName = $env:COMPUTERNAME
        Results = $Results
    }

    $history = @()
    if (Test-Path $historyFile) {
        try { $history = Get-Content $historyFile -Raw -Encoding UTF8 | ConvertFrom-Json } catch {}
    }
    $history += $entry
    if ($history.Count -gt 100) { $history = $history[-100..-1] }

    $history | ConvertTo-Json -Depth 10 | Set-Content $historyFile -Encoding UTF8 -Force
}

function Backup-SQLDatabases {
    param([hashtable]$Config, [string]$BackupDir)

    $results = @()
    $databases = $Config.backup.sql_databases
    if ($databases.Count -eq 0) { return $results }

    foreach ($db in $databases) {
        $dbFile = Join-Path $BackupDir "$db.bak"
        try {
            $query = "BACKUP DATABASE [$db] TO DISK = '$dbFile' WITH INIT, COMPRESSION, CHECKSUM"
            Invoke-SqlCmd -ServerInstance $Config.backup.sql_server -Query $query -ErrorAction SilentlyContinue | Out-Null
            if (Test-Path $dbFile) {
                $sizeMB = [math]::Round((Get-Item $dbFile).Length / 1MB, 2)
                $results += [PSCustomObject]@{ Source = "SQL:$db"; Destination = $dbFile; SizeMB = $sizeMB; Status = "Success"; Timestamp = Get-Date }
            }
        } catch {
            $results += [PSCustomObject]@{ Source = "SQL:$db"; SizeMB = 0; Status = "Failed"; Timestamp = Get-Date; Error = "$_" }
        }
    }
    return $results
}

function Restore-Backup {
    param([string]$BackupPath, [string]$RestorePath = $null)

    if (-not (Test-Path $BackupPath)) { Write-JDSLog "ERROR" "Backup path not found: $BackupPath"; return $false }

    try {
        $manifest = Get-ChildItem $BackupPath -Filter "backup-manifest.json" -Recurse | Select-Object -First 1
        if ($manifest) {
            $data = Get-Content $manifest.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            Write-JDSLog "INFO" "Restoring backup from $($data.Timestamp) (ID: $($data.BackupID))"
        }

        $items = Get-ChildItem $BackupPath
        foreach ($item in $items) {
            $restoreDest = if ($RestorePath) { $RestorePath } else { $env:TEMP }
            if ($item.Extension -eq '.enc') {
                $decPath = $item.FullName -replace '\.enc$', ''
                $content = [System.IO.File]::ReadAllBytes($item.FullName)
                $decrypted = [System.Security.Cryptography.ProtectedData]::Unprotect($content, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
                [System.IO.File]::WriteAllBytes($decPath, $decrypted)
                Add-Type -AssemblyName System.IO.Compression.FileSystem
                [System.IO.Compression.ZipFile]::ExtractToDirectory($decPath, $restoreDest)
                Remove-Item $decPath -Force
            } elseif ($item.Extension -eq '.zip') {
                Add-Type -AssemblyName System.IO.Compression.FileSystem
                [System.IO.Compression.ZipFile]::ExtractToDirectory($item.FullName, $restoreDest)
            } elseif ($item.Extension -eq '.bak') {
                Write-JDSLog "INFO" "SQL backup: $($item.Name) - manual restore via SQL Server"
            }
        }
        Write-JDSLog "INFO" "Restore completed to: $restoreDest"
        return $true
    } catch { Write-JDSLog "ERROR" "Restore failed: $_"; return $false }
}

function Test-BackupIntegrity {
    param([string]$BackupDir)

    try {
        $files = Get-ChildItem $BackupDir -Recurse -File
        foreach ($f in $files) {
            $hash = Get-FileHash $f.FullName -Algorithm SHA256
            Write-JDSLog "INFO" "Integrity OK: $($f.Name) -> $($hash.Hash.Substring(0, 16))..."
        }
        return $true
    } catch { Write-JDSLog "ERROR" "Integrity check failed: $_"; return $false }
}

function Invoke-BackupCleanup {
    param([hashtable]$Config)

    $retentionDays = $Config.backup.retention_days
    $cutoff = (Get-Date).AddDays(-$retentionDays)
    $count = 0

    $destinations = Get-BackupDestinations -Config $Config
    foreach ($dest in $destinations) {
        $path = $dest.path
        if (-not (Test-Path $path)) { continue }

        $old = Get-ChildItem $path -Directory -Filter "JDS-Backup_*" | Where-Object { $_.CreationTime -lt $cutoff }
        foreach ($b in $old) {
            Remove-Item $b.FullName -Recurse -Force -ErrorAction SilentlyContinue
            $count++
        }
    }
    if ($count -gt 0) { Write-JDSLog "INFO" "Cleanup: $count old backup(s) removed" }
}

function Invoke-BackupSchedule {
    param([hashtable]$Config)

    $bkp = $Config.backup
    $scheduleTime = $bkp.time
    Write-JDSLog "INFO" "Backup scheduler started (daily at $scheduleTime)..."

    while ($true) {
        $now = Get-Date
        $parts = $scheduleTime -split ':'
        $scheduled = Get-Date -Hour ([int]$parts[0]) -Minute ([int]$parts[1]) -Second 0

        if ($now.Hour -eq $scheduled.Hour -and $now.Minute -eq $scheduled.Minute) {
            Invoke-BackupSystem -Config $Config
            Start-Sleep -Seconds 90
        }
        Start-Sleep -Seconds 30
    }
}

function Invoke-BackupVersioning {
    param([hashtable]$Config, [string]$VersionLabel = "")
    $bkp = $Config.backup
    if (-not $bkp.enabled) { return $false }
    if (-not $bkp.rotation.enabled) { return $false }

    $snapshotTime = Get-Date
    $dateStamp = $snapshotTime.ToString('yyyy-MM-dd')
    $timeStamp = $snapshotTime.ToString('HHmmss')
    if ([string]::IsNullOrEmpty($VersionLabel)) { $versionName = "v_${dateStamp}_${timeStamp}" } else { $versionName = "v_${dateStamp}_${timeStamp}_${VersionLabel}" }

    $versionLogPath = "$($bkp.destinations.primary.path)\_versioning"
    if (-not (Test-Path $versionLogPath)) { New-Item -ItemType Directory -Path $versionLogPath -Force | Out-Null }

    $versionRecord = @{
        version = $versionName
        created = $snapshotTime.ToString('o')
        label = $VersionLabel
        source_paths = $bkp.source_paths
        destination = $bkp.destinations.primary.path
        encrypted = $bkp.encrypted
        compression = $bkp.compression
        retention_days = $bkp.retention_days
        computer = $env:COMPUTERNAME
        user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    }

    $versionFile = Join-Path $versionLogPath "versions.json"
    $existing = @()
    if (Test-Path $versionFile) {
        try { $existing = Get-Content $versionFile -Raw -Encoding UTF8 | ConvertFrom-Json } catch { }
    }
    $existing = @($existing) + $versionRecord
    $existing | ConvertTo-Json -Depth 10 | Set-Content $versionFile -Encoding UTF8 -Force

    $maxVersions = ($bkp.rotation.daily_keep + $bkp.rotation.weekly_keep + $bkp.rotation.monthly_keep + $bkp.rotation.yearly_keep) * 2
    if ($existing.Count -gt $maxVersions) {
        $sorted = $existing | Sort-Object { [DateTime]$_.created }
        $toRemove = $sorted[0..($existing.Count - $maxVersions - 1)]
        foreach ($old in $toRemove) {
            $oldVersionPath = Join-Path $bkp.destinations.primary.path $old.version
            if (Test-Path $oldVersionPath) { Remove-Item $oldVersionPath -Recurse -Force -ErrorAction SilentlyContinue }
        }
        $remaining = $existing | Where-Object { $toRemove -notcontains $_ }
        $remaining | ConvertTo-Json -Depth 10 | Set-Content $versionFile -Encoding UTF8 -Force
    }

    $snapshotPath = Join-Path $bkp.destinations.primary.path $versionName
    New-Item -ItemType Directory -Path $snapshotPath -Force | Out-Null
    $versionRecord | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $snapshotPath "_snapshot.json") -Encoding UTF8 -Force

    $sourceSummary = @()
    foreach ($src in $bkp.source_paths) {
        if (Test-Path $src) {
            $destPath = Join-Path $snapshotPath (Split-Path $src -Leaf)
            try {
                Copy-Item -Path $src -Destination $destPath -Recurse -Force -ErrorAction SilentlyContinue
                $sourceSummary += @{ source = $src; dest = $destPath; status = "ok" }
            } catch { $sourceSummary += @{ source = $src; status = "failed"; error = $_.Exception.Message } }
        } else { $sourceSummary += @{ source = $src; status = "not_found" } }
    }

    Write-JDSLog "INFO" "BACKUP-VERSION: $versionName erstellt mit $($sourceSummary.Count) Quellen"
    return @{ version = $versionName; snapshot_path = $snapshotPath; created = $snapshotTime; sources = $sourceSummary }
}

function Get-BackupVersions {
    param([hashtable]$Config, [int]$Limit = 20)
    $versionLogPath = "$($Config.backup.destinations.primary.path)\_versioning\versions.json"
    if (-not (Test-Path $versionLogPath)) { return @() }
    try {
        $versions = Get-Content $versionLogPath -Raw -Encoding UTF8 | ConvertFrom-Json
        return $versions | Sort-Object { [DateTime]$_.created } -Descending | Select-Object -First $Limit
    } catch { return @() }
}

function Restore-SnapshotVersion {
    param([hashtable]$Config, [string]$VersionName, [string]$RestorePath = "")
    $bkp = $Config.backup
    if (-not $bkp.enabled) { return $false }

    $snapshotPath = Join-Path $bkp.destinations.primary.path $VersionName
    if (-not (Test-Path $snapshotPath)) { Write-JDSLog "ERROR" "Snapshot nicht gefunden: $snapshotPath"; return $false }

    $snapshotMeta = Join-Path $snapshotPath "_snapshot.json"
    if (Test-Path $snapshotMeta) {
        try { $meta = Get-Content $snapshotMeta -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $meta = $null }
    }

    if ([string]::IsNullOrEmpty($RestorePath)) { $RestorePath = "$env:TEMP\JDS-Restore_$VersionName" }
    if (-not (Test-Path $RestorePath)) { New-Item -ItemType Directory -Path $RestorePath -Force | Out-Null }

    $items = Get-ChildItem $snapshotPath -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne "_snapshot.json" }
    $restoreCount = 0
    foreach ($item in $items) {
        $destPath = Join-Path $RestorePath $item.Name
        try {
            Copy-Item -Path $item.FullName -Destination $destPath -Recurse -Force -ErrorAction SilentlyContinue
            $restoreCount++
        } catch { Write-JDSLog "WARN" "Snapshot-Wiederherstellung fehlgeschlagen fuer $($item.Name): $_" }
    }

    Write-JDSLog "INFO" "SNAPSHOT-RESTORE: $VersionName -> $RestorePath ($restoreCount Eintraege)"
    return @{ restored = $restoreCount; path = $RestorePath; version = $VersionName; meta = $meta }
}


