# JDS Secure - Quick Start (English)

## Installation

```powershell
.\setup.ps1 -Easy
```

Or with graphical wizard:

```powershell
.\setup.ps1 -GUI
```

## Launch

```powershell
.\jds-secure.ps1 -Mode GUI          # Graphical interface (recommended)
.\jds-secure.ps1 -Mode Interactive  # Console menu
.\jds-secure.ps1 -Mode Service      # Background service (14 daemons)
.\jds-secure.ps1 -Mode QuickScan    # Quick security scan
```

## Quick Commands

| Action | Command |
|--------|---------|
| Full scan | `Invoke-FullScan` |
| Backup | `Invoke-BackupSystem` |
| Harden firewall | `Invoke-FirewallHardening` |
| GDPR breach report | `New-GDPRBreachNotification` |
| Virus scan | `Invoke-VirusScan -ScanType quick` |
| Security report | `Export-SecurityReport` |

## GDPR Obligations

- **Art. 33**: Breach notification via menu item 19
- **Art. 30**: Processing records via GDPR menu (option 4)
- **Art. 32**: TOM documentation via GDPR menu (option 5)
- **Art. 17**: Data erasure via data cleanup (option 2)

## System Requirements

- Windows 10/11 or Windows Server 2016+
- PowerShell 5.1+
- Administrator privileges for firewall/service installation

---

## Limitation of Liability

This software is provided "as is" without warranty of any kind. It assists
with security standards and GDPR compliance but does not constitute legal
advice. Professional consultation with a data protection officer and legal
counsel is required before production use. The author shall not be held
liable for any damages arising from its use.
